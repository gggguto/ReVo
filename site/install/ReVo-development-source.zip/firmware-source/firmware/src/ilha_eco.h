/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
void ilha_eco_init(void);
void ilha_eco_beam(const int32_t p[4]);
void ilha_eco_beam_visual(uint32_t out[8]);
void ilha_eco_resonance_sources(uint32_t mask);
void ilha_eco_play(uint32_t on);
void ilha_eco_param(uint32_t id,int32_t value);
void ilha_eco_wind(uint32_t id,int32_t value);
void ilha_eco_keys(uint32_t mask);
uint32_t ilha_eco_render(int32_t *out,uint32_t frames);
uint32_t ilha_eco_render_split(int32_t*,int32_t*,int32_t*,uint32_t,uint32_t);
uint32_t ilha_eco_render_fx(int32_t*,int32_t*,uint32_t,uint32_t);

void ilha_eco_clock(uint32_t on);
void ilha_eco_clock_reset(void);
void ilha_eco_clock_pulse(void);

uint32_t ilha_eco_wind_level(void);

void ilha_eco_seed_live(uint32_t seed);

void ilha_eco_visual(uint32_t events[3],uint32_t *ticks,uint32_t *step);

uint32_t ilha_eco_note_lights(void);
void ilha_eco_chord_name(char out[16]);

uint32_t ilha_eco_bed_phase(void);

uint32_t ilha_eco_bed_seed(void);
int32_t ilha_eco_bed_held(void);
uint32_t ilha_eco_sounding(void);

void ilha_eco_living(int32_t,int32_t,int32_t,int32_t,int32_t);
uint32_t ilha_eco_weather(void);

void ilha_eco_activity(uint32_t,uint32_t);
void ilha_eco_family_visual(uint32_t*,uint32_t*,uint32_t*);
void ilha_eco_family(uint32_t family,uint32_t tame,uint32_t cycle);

void ilha_eco_distance(uint32_t,int32_t,int32_t,int32_t,int32_t);
void ilha_eco_drift(int32_t,uint32_t,int32_t,int32_t);
void ilha_eco_resonance(int32_t,int32_t,int32_t,int32_t);
void ilha_eco_resonance_balance(int32_t,int32_t,int32_t);
void ilha_eco_resonance_visual(uint32_t*,uint32_t*,uint32_t*);
void ilha_eco_layers_visual(int32_t depth[3],int32_t pan[3],uint8_t trace[3][48],uint32_t *cursor,uint32_t *changes,uint32_t *env,uint32_t *events);

void ilha_eco_sends(const int32_t sends[6][2],uint32_t wind_fx);
uint32_t ilha_eco_render_sends(int32_t*,int32_t*,int32_t*,int32_t*,int32_t*,uint32_t,uint32_t);
void ilha_eco_pressure(uint32_t);
void ilha_eco_engine_diagnostics(uint32_t out[8]);

uint32_t ilha_eco_beat_mask(void);
