/* SPDX-License-Identifier: GPL-3.0-only
 * Wood/Strings adapted from the supplied offline FM studies; Glass/Metal are
 * bounded new designs. Times are e-folding constants, not time to silence.
 * Tables use Q12 ratios, Q15 gains and phase/radian conversion for Q15 sine. */
#ifndef REVO_RESONANCE_PARAMS_H
#define REVO_RESONANCE_PARAMS_H
#include <stdint.h>
typedef struct {int32_t cr,mr,gain,tau,index,itau,residual,phase;} rr_pair_t;
typedef struct {int32_t attack,gain;rr_pair_t pair[3];} rr_patch_t;
static const uint8_t rr_counts[4]={3,4,2,2};
static const rr_patch_t rr_patches[4][4]={
 {
  {550,24248,{{4096,11305,29491,60000,23990,9000,0,0},{11305,4096,10486,20000,33377,6000,0,0},{22200,34038,3932,5500,62582,2500,0,0}}},
  {550,24248,{{4096,5792,26870,115000,21904,18000,0,0},{11182,4096,14418,43000,23990,10000,0,0},{22446,33219,3277,8000,52152,3500,0,0}}},
  {550,24248,{{4096,5612,27853,205000,19818,25000,0,0},{11510,4096,15073,69000,21904,13000,0,0},{23634,32891,3932,11000,58410,4000,0,0}}},
 },
 {
  {1200,19661,{{4096,4096,27197,140000,36506,25000,1252,273426110},{8192,4096,8520,65000,26076,18000,0,683565276},{12288,8192,2949,25000,33377,7000,0,205069583}}},
  {1800,19661,{{4096,4096,26870,720000,51109,65000,3338,273426110},{8192,4096,7864,270000,22947,40000,834,683565276},{12288,8192,3277,85000,35463,12000,0,205069583}}},
  {2500,19661,{{4096,4096,28180,1050000,38592,140000,4589,273426110},{8192,4096,9830,450000,26076,70000,1460,683565276},{16384,4096,2949,130000,29205,22000,0,205069583}}},
  {900,19661,{{4096,4096,23593,1180000,77185,250000,7927,273426110},{8192,4096,9830,620000,45894,130000,3338,683565276},{20480,8192,4915,190000,41722,40000,417,205069583}}},
 },
 {
  {1000,21299,{{4096,5792,24576,550000,5215,25000,0,0},{11289,4096,7864,320000,7301,16000,0,0},{22135,8602,2949,150000,9387,9000,0,0}}},
  {1500,21299,{{4096,5792,25559,900000,9387,50000,0,0},{11289,4096,9175,550000,13559,30000,0,0},{22135,8602,3277,200000,16689,14000,0,0}}},
 },
 {
  {800,19661,{{4096,5792,23593,650000,22947,90000,1669,0},{9503,6627,9830,420000,27119,60000,2086,0},{19948,11100,3932,220000,31291,30000,0,0}}},
  {800,19661,{{4096,5792,23593,1200000,37549,180000,2503,0},{11919,6627,9830,750000,43808,120000,2921,0},{22241,11100,3932,350000,45894,50000,417,0}}},
 },
};
static int32_t rr_lerp(int32_t a,int32_t b,int32_t f){return a+(int32_t)((int64_t)(b-a)*f/100);}
static rr_patch_t rr_patch(uint32_t object,uint32_t material){
 uint32_t pos=material*(rr_counts[object]-1),at=pos/100,f=pos%100,next=at+1<rr_counts[object]?at+1:at;
 const rr_patch_t *a=&rr_patches[object][at],*b=&rr_patches[object][next];rr_patch_t p;
 p.attack=rr_lerp(a->attack,b->attack,f);p.gain=a->gain;
 for(int j=0;j<3;j++){
  const rr_pair_t *x=&a->pair[j],*y=&b->pair[j];rr_pair_t *z=&p.pair[j];
  z->cr=object==1?(f<50?x->cr:y->cr):rr_lerp(x->cr,y->cr,f);z->mr=object==1?(f<50?x->mr:y->mr):rr_lerp(x->mr,y->mr,f);
  z->gain=rr_lerp(x->gain,y->gain,f);z->tau=rr_lerp(x->tau,y->tau,f);z->index=rr_lerp(x->index,y->index,f);z->itau=rr_lerp(x->itau,y->itau,f);z->residual=rr_lerp(x->residual,y->residual,f);z->phase=x->phase;
 }return p;
}
static uint32_t rr_tau(uint32_t us,uint32_t decay,uint32_t part){
 uint32_t scale=part==0?25+decay*350/100:part==1?50+decay:30+decay/2;
 uint32_t result=us*scale/100;if(result<500)result=500;if(result>1737000)result=1737000;return result;
}
static uint32_t rr_decay_ms(uint32_t object,uint32_t material,uint32_t decay){rr_patch_t p=rr_patch(object,material);return rr_tau(p.pair[0].tau,decay,0)*69u/10000u;}
#endif
