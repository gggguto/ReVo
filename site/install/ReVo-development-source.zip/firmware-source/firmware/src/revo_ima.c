/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments.
 * IMA tables from SLOOP/Felucca; indexed cache adapter for ReVo.
 */
#include "revo_ima.h"
static uint32_t revo_ima_fills,revo_ima_decoded;
static const int16_t IMA_STEP[89] = {
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97,
    107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796,
    876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428,
    4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350,
    22385, 24623, 27086, 29794, 32767};
static const int8_t IMA_IDX[8] = {-1, -1, -1, -1, 2, 4, 6, 8};

static int16_t decode(uint32_t code,int32_t *pred,uint32_t *idx){
 int32_t s=IMA_STEP[*idx],d=s>>3;
 if(code&4)d+=s;if(code&2)d+=s>>1;if(code&1)d+=s>>2;
 *pred+=(code&8)?-d:d;
 if(*pred>32767)*pred=32767;if(*pred< -32768)*pred=-32768;
 int32_t next=(int32_t)*idx+IMA_IDX[code&7];
 *idx=(uint32_t)(next<0?0:next>88?88:next);return (int16_t)*pred;
}
static uint32_t nibble(const uint8_t *p,uint32_t n){return(p[n>>1]>>((n&1)*4))&15;}
int revo_ima_index(revo_ima_source *s,const uint8_t *data,uint32_t bytes,uint32_t frames,revo_ima_state *states,uint32_t capacity){
 if(!s||!data||!states||frames<4||frames>REVO_IMA_MAX_FRAMES||bytes!=(frames+1)/2||capacity<(frames+255)/256)return 0;
 int32_t pred=0;uint32_t idx=0;
 for(uint32_t n=0;n<frames;n++){
  if(!(n&255))states[n>>8]=(revo_ima_state){(int16_t)pred,(uint8_t)idx,0};
  decode(nibble(data,n),&pred,&idx);
 }
 *s=(revo_ima_source){data,frames,states};return 1;
}
int16_t revo_ima_at(const revo_ima_source *s,revo_ima_cache *c,uint32_t n){
 if(!s||!s->data||!s->states||!c||n>=s->frames)return 0;
 uint32_t block=n>>8;
 if(!c->valid||c->block!=block){
  int32_t pred=s->states[block].pred;uint32_t idx=s->states[block].idx;
  if(idx>88)return 0;
  uint32_t first=block*256,end=s->frames-first;if(end>256)end=256;
  for(uint32_t j=0;j<end;j++)c->pcm[j]=decode(nibble(s->data,first+j),&pred,&idx);
  revo_ima_fills++;revo_ima_decoded+=end+(first+end<s->frames);
  /* Decode one lookahead sample while predictor state is already warm. */
  c->pcm[end]=first+end<s->frames?decode(nibble(s->data,first+end),&pred,&idx):c->pcm[end-1];
  c->block=block;c->valid=1;
 }
 return c->pcm[n&255];
}

/* Read an interpolation pair while anchoring the cache on the first index.
 * Independent lookups at255/256 used to evict each other on every output frame.
 * Flock's last->first circular pair also must not replace the active block. */
void revo_ima_pair(const revo_ima_source *s,revo_ima_cache *c,uint32_t n,uint32_t next,int32_t *a,int32_t *b){
 *a=revo_ima_at(s,c,n);
 if(!s||!s->data||!s->states||!c||n>=s->frames||next>=s->frames){*b=0;return;}
 if(next==n)*b=*a;
 else if(next==n+1u&&c->valid&&c->block==(n>>8))*b=c->pcm[(n&255u)+1u];
 else if(!next){int32_t pred=s->states[0].pred;uint32_t idx=s->states[0].idx;*b=idx<=88?decode(nibble(s->data,0),&pred,&idx):0;}
 else *b=revo_ima_at(s,c,next);
}
