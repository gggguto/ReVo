/* SPDX-License-Identifier: GPL-3.0-only. Per-gesture AR crossfade, no heap. */
#pragma once
#include <stdint.h>
#define FRAG_ENV_FULL 16777216u
typedef struct {uint32_t gain,step,left,total,stage,attack,release,remainder,fraction;} revo_frag_env_t;
static uint32_t frag_env_frames(uint32_t ms){uint32_t n=ms*441u/10u;return n<64?64:n;}
static void frag_env_begin(revo_frag_env_t *e,uint32_t stage){
 uint32_t n=frag_env_frames(stage==1?e->attack:e->release),distance=stage==1?FRAG_ENV_FULL-e->gain:e->gain;
 e->stage=stage;e->left=e->total=n;e->step=distance/n;e->remainder=distance%n;e->fraction=0;
 if(!distance){e->stage=stage==1?2:0;e->left=0;}
}
static uint32_t frag_env_tick(revo_frag_env_t *e){
 if(e->stage==1||e->stage==3){
  uint32_t delta=e->step;e->fraction+=e->remainder;if(e->fraction>=e->total){e->fraction-=e->total;delta++;}
  if(!--e->left){if(e->stage==1){e->gain=FRAG_ENV_FULL;e->stage=2;}else {e->gain=0;e->stage=0;}}
  else if(e->stage==1)e->gain+=delta;else e->gain-=delta;
 }
 uint32_t x=e->gain>>9;return (uint32_t)((uint64_t)x*x/32768u*(98304u-2u*x)/32768u);
}
