/* SPDX-License-Identifier: GPL-3.0-only
 * ReVo bit/sample-rate crusher. Integer stereo state, no heap or external DSP.
 * Update params at block boundaries; render owns all state.
 */
#pragma once
#include <stdint.h>
typedef struct {int32_t held[2],wet;uint32_t remaining[2],period,quantum,amount;} revo_crush_t;
static void revo_crush_set(revo_crush_t *s,uint32_t amount){
 if(amount>127)amount=127;
 s->amount=amount;s->wet=(int32_t)(amount*32768u/127u);
 s->quantum=1u<<(amount*12u/127u);s->period=1u+amount*15u/127u;
 if(!amount){s->remaining[0]=s->remaining[1]=0;s->held[0]=s->held[1]=0;}
 for(uint32_t c=0;c<2;c++)if(s->remaining[c]>=s->period)s->remaining[c]=s->period-1;
}
static void revo_crush_pair(revo_crush_t *s,uint32_t bits,uint32_t rate){
 if(bits>100)bits=100;if(rate>100)rate=100;
 s->amount=(bits||rate)?127u:0u;s->wet=32768;s->quantum=1u<<(bits*12u/100u);s->period=1u+rate*31u/100u;
 for(uint32_t ch=0;ch<2;ch++)if(s->remaining[ch]>=s->period)s->remaining[ch]=0;
}
static int32_t revo_crush_sample(revo_crush_t *s,int32_t value,uint32_t ch){
 if(ch>1||!s->amount)return value;
 if(!s->remaining[ch]){
  int32_t x=value< -32768?-32768:value>32767?32767:value;
  s->held[ch]=(x/(int32_t)s->quantum)*(int32_t)s->quantum;
  s->remaining[ch]=s->period;
 }
 s->remaining[ch]--;
 if(s->amount==127)return s->held[ch];
 return value+(int32_t)(((int64_t)s->held[ch]-value)*s->wet/32768);
}
