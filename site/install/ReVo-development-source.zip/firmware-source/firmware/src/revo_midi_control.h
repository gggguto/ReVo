/* SPDX-License-Identifier: GPL-3.0-only. Main-thread fixed MIDI map; no HAL/audio/storage access. */
#pragma once
#include "ilha_controls.h"
#include "revo_fragment.h"
typedef struct {uint32_t held[2][2];} revo_midi_control_t;
static inline uint32_t revo_midi_source_ok(uint32_t selected,uint32_t source){return selected==3u||(selected&&selected==source);}
static inline uint32_t revo_midi_control_notes(const revo_midi_control_t *s){return s->held[0][0]|s->held[0][1]|s->held[1][0]|s->held[1][1];}
static inline uint32_t revo_midi_control_relevant(uint32_t packet){
 uint32_t cin=packet&15u,status=(packet>>8)&255u,ch=status&15u,type=status&240u,n=(packet>>16)&255u,v=packet>>24;
 if(n>127u||v>127u)return 0;
 if(ch<2u&&((cin==9u&&type==0x90u)||(cin==8u&&type==0x80u)))return n>=59u&&n<=72u;
 if(cin==11u&&type==0xb0u)return ch<2u?((n>=20u&&n<=24u)||n==123u):ch==2u&&n==20u;
 return 0;
}
static inline int32_t revo_midi_scale(uint32_t value,int32_t lo,int32_t hi){return lo+(int32_t)((value*(uint32_t)(hi-lo)+63u)/127u);}
/* Audio can update note ownership directly without touching the UI controls snapshot. */
static inline int revo_midi_note_apply(revo_midi_control_t *s,uint32_t packet){
 uint32_t source=((packet>>4)&15u)?2u:1u,cin=packet&15u,status=(packet>>8)&255u,ch=status&15u,type=status&240u,n=(packet>>16)&255u,v=packet>>24;
 if(n>127u||v>127u)return 0;
 if(ch<2u&&((cin==9u&&type==0x90u)||(cin==8u&&type==0x80u))){
  if(n<60u||n>72u)return 0;uint32_t action=fragment_action(n-60u),key=ch?14u:0u;
  for(uint32_t i=0;i<13u;i++)if(fragment_action((ch?14u:0u)+i)==action){key=(ch?14u:0u)+i;break;}
  if(type==0x90u&&v)s->held[source-1u][ch]|=1u<<key;else {
   /* Explicit load/compute/store avoids the target memory AND-NOT RMW form. */
   volatile uint32_t released=s->held[source-1u][ch]&~(1u<<key);s->held[source-1u][ch]=released;
  }
  return 1;
 }
 if(ch<2u&&cin==11u&&type==0xb0u&&n==123u){s->held[source-1u][ch]=0;return 1;}
 return 0;
}
/* Bioma uses the existing 27-key Wind keyboard, never extra audio voices.
 * Channel 1: Wind/global; 2..4: families; 5: Resonance; 6: FX; 7: Drift/Beam.
 * Continuous values scale from 0..127; enums are literal indices; switches use 64.
 */
static inline uint32_t revo_midi_bioma_relevant(uint32_t packet){
 uint32_t cin=packet&15u,status=(packet>>8)&255u,ch=status&15u,t=status&240u,n=(packet>>16)&255u,v=packet>>24;
 if(n>127u||v>127u)return 0;
 if(!ch&&((cin==9u&&t==0x90u)||(cin==8u&&t==0x80u)))return n==36u||(n>=53u&&n<=79u);
 if(cin!=11u||t!=0xb0u)return 0;
 if(!ch)return (n>=20u&&n<=32u)||n==123u;
 if(ch<=3u)return n>=20u&&n<=30u;
 if(ch==4u)return n>=20u&&n<=28u;
 if(ch==5u)return n>=20u&&n<=33u;
 return ch==6u&&n>=20u&&n<=27u;
}
static inline int revo_midi_bioma_note(revo_midi_control_t *s,uint32_t packet){
 uint32_t src=((packet>>4)&15u)?1u:0u,cin=packet&15u,status=(packet>>8)&255u,t=status&240u,n=(packet>>16)&255u,v=packet>>24;
 if((status&15u)||n>127u||v>127u)return 0;
 if((cin==9u&&t==0x90u)||(cin==8u&&t==0x80u)){
  if(n<53u||n>79u)return 0;uint32_t bit=1u<<(n-53u);
  if(t==0x90u&&v)s->held[src][0]|=bit;else {volatile uint32_t held=s->held[src][0]&~bit;s->held[src][0]=held;}return 1;
 }
 if(cin==11u&&t==0xb0u&&n==123u){s->held[src][0]=0;return 1;}return 0;
}
static inline uint32_t revo_midi_index(uint32_t v,uint32_t max){return v>max?max:v;}
static inline int revo_midi_bioma_apply(revo_midi_control_t *s,ilha_controls_t *c,uint32_t packet){
 uint32_t status=(packet>>8)&255u,ch=status&15u,t=status&240u,n=(packet>>16)&255u,v=packet>>24;
 if(!revo_midi_bioma_relevant(packet))return 0;
 if(revo_midi_bioma_note(s,packet)){c->midi_notes=revo_midi_control_notes(s);return 1;}
 if(!ch&&n==36u&&(t==0x90u||t==0x80u)){
  if(t!=0x90u||!v)return 0;c->playing=!c->playing;if(!c->playing)c->drift[3]=0;return 1;
 }
 if(t!=0xb0u)return 0;int32_t pct=revo_midi_scale(v,0,100);
 if(!ch){switch(n){
  case 20:c->eco_density=pct;break;case 21:c->eco_global[3]=pct;break;
  case 22:c->wind[0]=pct;break;case 23:c->wind[1]=(int32_t)revo_midi_index(v,7);break;
  case 24:c->wind_env[0]=revo_midi_scale(v,10,10000);break;case 25:c->wind_env[1]=revo_midi_scale(v,20,20000);break;
  case 26:c->wind_fx=v>=64u;break;case 27:c->eco_level[3]=pct;break;
  case 28:c->response[0]=pct;break;case 29:c->response[1]=pct;break;
  case 30:c->harmony[0]=(int32_t)revo_midi_index(v,2);break;
  case 31:c->harmony[3]=(int32_t)revo_midi_index(v,3);break;
  case 32:if(c->midi_source)return 0;c->eco_global[1]=revo_midi_scale(v,40,240);break;
  default:return 0;}return 1;
 }
 if(ch<=3u){uint32_t f=ch-1u;switch(n){
  case 20:c->eco_level[f]=pct;break;
  case 21:c->eco_register[f==1?2:f==2?1:0]=pct;break;
  case 22:c->family_activity[f]=(uint32_t)pct;break;
  case 23:c->family_cycle[f]=revo_midi_index(v,ilha_eco_cycle_count()-1u);break;
  case 24:c->family_tame[f]=v>=64u;break;
  case 25:case 26:c->eco_sends[f][n-25u]=pct;break;
  case 27:case 28:case 29:c->distance[f][n-27u]=pct;break;
  case 30:c->distance[f][3]=v>=64u;break;default:return 0;}return 1;
 }
 if(ch==4u){switch(n){
  case 20:case 21:case 22:c->resonance[n-20u]=pct;break;
  case 23:c->resonance[3]=v>=64u;break;case 24:c->resonance_balance[0]=pct;break;
  case 25:c->resonance_balance[1]=(int32_t)revo_midi_index(v,3);break;
  case 26:c->resonance_sources=revo_midi_index(v,7);break;
  case 27:case 28:c->eco_sends[3][n-27u]=pct;break;default:return 0;}return 1;
 }
 if(ch==5u){switch(n){
  case 20:c->glitch[0]=pct;break;case 21:c->glitch[1]=revo_midi_scale(v,10,300);break;
  case 22:c->glitch[2]=revo_midi_scale(v,1,16);break;case 23:c->glitch[3]=pct;break;
  case 24:c->glitch_sync=v>=64u;break;case 25:c->echo[0]=pct;break;
  case 26:c->echo[1]=revo_midi_scale(v,10,1000);break;case 27:c->echo[2]=revo_midi_scale(v,0,90);break;
  case 28:c->echo[3]=pct;break;case 29:c->space[0]=v<=64u?-100+(int32_t)((v*100u+32u)/64u):(int32_t)(((v-64u)*100u+31u)/63u);break;
  case 30:c->space[1]=pct;break;case 31:c->space[2]=pct;break;case 32:c->space[3]=pct;break;
  case 33:c->ice=v>=64u;break;default:return 0;}return 1;
 }
 if(ch==6u){switch(n){
  case 20:c->drift[0]=pct;break;case 21:c->drift[1]=(int32_t)revo_midi_index(v,6);break;
  case 22:c->drift[2]=(int32_t)revo_midi_index(v,12);break;case 23:c->drift[3]=v>=64u;break;
  case 24:c->beam[0]=pct;break;case 25:c->beam[1]=(int32_t)(v<1u?1u:revo_midi_index(v,16));break;
  case 26:c->beam[2]=(int32_t)revo_midi_index(v,5);break;case 27:c->beam[3]=v>=64u;break;default:return 0;}return 1;
 }return 0;
}
static inline int revo_midi_control_apply(revo_midi_control_t *s,ilha_controls_t *c,uint32_t packet){
 uint32_t source=((packet>>4)&15u)?2u:1u,cin=packet&15u,status=(packet>>8)&255u,ch=status&15u,type=status&240u,n=(packet>>16)&255u,v=packet>>24;
 if(!revo_midi_source_ok(c->midi_control_source,source)||n>127u||v>127u)return 0;
 if(c->machine==ILHA_ECO)return revo_midi_bioma_apply(s,c,packet);
 if(c->machine!=ILHA_DUAL)return 0;
 if(ch<2u&&(cin==9u||cin==8u)&&(type==0x90u||type==0x80u)&&n==59u){if(type!=0x90u||!v)return 0;c->dual_run[ch]=!c->dual_run[ch];c->playing=(uint8_t)!!(c->dual_run[0]|c->dual_run[1]);return 1;}
 if(revo_midi_note_apply(s,packet)){c->midi_notes=revo_midi_control_notes(s);return 1;}
 if(cin!=11u||type!=0xb0u)return 0;
 if(ch==2u&&n==20u){c->dual_gain=revo_midi_scale(v,0,12);return 1;}
 if(ch>1u)return 0;
 ilha_loop_t *h=&c->heads[ch];
 if(n==20u)h->start=revo_midi_scale(v,0,99);
 else if(n==21u)ilha_loop_size(h,revo_midi_scale(v,1,100));
 else if(n==22u)h->speed=v<=64u?-200+(int32_t)((v*200u+32u)/64u):(int32_t)(((v-64u)*200u+31u)/63u);
 else if(n==23u)h->level=revo_midi_scale(v,0,100);
 else if(n==24u)h->pan=v<=64u?-100+(int32_t)((v*100u+32u)/64u):(int32_t)(((v-64u)*100u+31u)/63u);
 else return 0;
 return 1;
}
