/* SPDX-License-Identifier: GPL-3.0-only; ILHA sample container v1, no HAL or flash. */
#include "ilha_sample.h"
static uint32_t u32(const uint8_t *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static uint32_t crc_step(uint32_t c,const uint8_t *p,uint32_t n){
 static const uint32_t t[16]={0,0x1db71064u,0x3b6e20c8u,0x26d930acu,0x76dc4190u,0x6b6b51f4u,0x4db26158u,0x5005713cu,0xedb88320u,0xf00f9344u,0xd6d6a3e8u,0xcb61b38cu,0x9b64c2b0u,0x86d3d2d4u,0xa00ae278u,0xbdbdf21cu};
 for(uint32_t i=0;i<n;i++){c^=p[i];c=(c>>4)^t[c&15];c=(c>>4)^t[c&15];}return c;
}
uint32_t ilha_sample_crc(const uint8_t *p,uint32_t n){return crc_step(0xffffffffu,p,n)^0xffffffffu;}
void ilha_sample_init(ilha_sample_t *s,int16_t *pcm,uint32_t cap){*s=(ilha_sample_t){.pcm=pcm,.capacity=cap};}
int ilha_sample_begin(ilha_sample_t *s,const uint8_t *h,uint32_t size,uint32_t quiet){
 const char magic[8]={'I','L','H','A','W','A','V','1'};
 if(!s||!h||size!=64||!quiet||!s->pcm||s->loading)return 0;
 for(uint32_t i=0;i<8;i++)if(h[i]!=(uint8_t)magic[i])return 0;
 uint32_t frames=u32(h+16);
 uint32_t encoding=u32(h+8), rate=u32(h+12), bytes;
 if(encoding==1){if(rate!=44100||frames<4||frames>ILHA_SAMPLE_CAP||frames>s->capacity)return 0;bytes=frames*2;}
 else if(encoding==2){if(rate!=22050||frames<4||frames>ILHA_COMPRESSED_MAX_FRAMES)return 0;bytes=(frames+1)/2;if(bytes>s->capacity*2)return 0;}
 else return 0;
 if(u32(h+56)||u32(h+60)!=ilha_sample_crc(h,60)||h[55])return 0;
 s->encoding=encoding;s->bytes=bytes;
 for(uint32_t i=24;i<55;i++)if(h[i]&&(h[i]<32||h[i]>126))return 0;
 s->frames=frames;s->expected=u32(h+20);s->received=0;s->crc=0xffffffffu;s->loading=1;s->valid=0;
 for(uint32_t i=0;i<32;i++)s->name[i]=(char)h[24+i];return 1;
}
int ilha_sample_write(ilha_sample_t *s,uint32_t offset,const uint8_t *data,uint32_t n){
 if(!s||!s->loading||!data||!n||(s->encoding==1&&(n&1))||offset!=s->received||offset>s->bytes||n>s->bytes-offset)return 0;
 if(s->encoding==2){uint8_t *dest=(uint8_t *)s->pcm;for(uint32_t i=0;i<n;i++)dest[offset+i]=data[i];}
 else for(uint32_t i=0;i<n;i+=2){uint32_t v=(uint32_t)data[i]|(uint32_t)data[i+1]<<8;s->pcm[(offset+i)/2]=(int16_t)(v>=32768?(int32_t)v-65536:(int32_t)v);}
 s->crc=crc_step(s->crc,data,n);s->received+=n;return 1;
}
int ilha_sample_finish(ilha_sample_t *s){
 if(!s||!s->loading||s->received!=s->bytes)return 0;
 s->loading=0;s->valid=((s->crc^0xffffffffu)==s->expected);return s->valid;
}
void ilha_sample_abort(ilha_sample_t *s){if(s&&s->loading){s->loading=0;s->valid=0;}}
