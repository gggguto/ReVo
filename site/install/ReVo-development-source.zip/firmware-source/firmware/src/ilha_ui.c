/* SPDX-License-Identifier: GPL-3.0-only; hardware independent 240x240 UI. */
#include "ilha_ui.h"
#include "revo_harmony.h"
#include "revo_fragment.h"
#include "revo_sync.h"
#include "revo_motion.h"
#include "ilha_island.h"
#define WHITE 0xffffu
#define GRAY 0x8410u
#define RED 0xfaa7u
#define BLUE 0x4e7cu
#define YELLOW 0xd650u
static const char *families[]={"BIRDS","INSECTS","WATER","WATER BED","WIND"};
static const uint16_t family_colours[]={RED,YELLOW,BLUE,WHITE,WHITE};
static void copy(char *d,const char *s){uint32_t i=0;for(;i<31&&s[i];i++)d[i]=s[i];d[i]=0;}
static void fragment_ui_label(const ilha_controls_t *c,uint32_t bank,uint32_t key,char out[32]){
 uint32_t held=c->notes&fragment_mask(bank),rev=1u<<(bank?15:1);copy(out,fragment_label(fragment_action(key)));
 if(held&rev){if(!(held&~rev)&&!c->dual_run[bank])copy(out,"Reverse ready");else if(held&~rev){uint32_t n=0;while(out[n])n++;copy(out+n," Rev");}}
}
static void number(char *s,int32_t n){uint32_t pos=0,v;if(n<0){s[pos++]='-';v=(uint32_t)(-(int64_t)n);}else v=(uint32_t)n;char tmp[11];uint32_t len=0;do{tmp[len++]=(char)('0'+v%10);v/=10;}while(v);while(len)s[pos++]=tmp[--len];s[pos]=0;}
static void value_text(char *s,int32_t n,uint32_t speed){if(!speed){number(s,n);uint32_t i=0;while(s[i])i++;s[i++]='%';s[i]=0;return;}uint32_t i=0,v=n<0?(uint32_t)-n:(uint32_t)n;if(n<0)s[i++]='-';s[i++]=(char)('0'+v/100);s[i++]='.';s[i++]=(char)('0'+v/10%10);s[i++]=(char)('0'+v%10);s[i++]='x';s[i]=0;}
static int32_t knob_value(const ilha_controls_t *c,uint32_t k){if(c->machine==ILHA_ECO&&c->page==ILHA_HOME&&k==3)return c->eco_density;if(c->page==ILHA_LOOP_SHAPE)return k<3?c->loop_shape[c->loop][k]:0;if(c->machine==ILHA_DUAL&&c->page==ILHA_WAVE&&c->sync_panel)return (int32_t)c->sync[c->loop][k];if(c->page==ILHA_VFORMATION)return (int32_t)c->vformation[c->loop][k==0?2:k==1?3:k==2?1:0];if(c->page==ILHA_LANDING)return k==0?(int32_t)c->landing_position[c->loop]:k==1?(int32_t)c->landing_point[c->loop]:k==3?(int32_t)c->landing_mode[c->loop]:0;if(c->page==ILHA_DISTANCE)return c->distance[c->eco_family%3][k];if(c->machine==ILHA_ECO&&c->page==ILHA_WEATHER)return c->beam[k];if(c->page==ILHA_DRIFT)return c->drift[k];if(c->page==ILHA_RESONANCE)return c->resonance_page==2?(k==0?(int32_t)c->resonance_source_cursor:k<3?c->eco_sends[3][k-1]:0):c->resonance_page?(k<3?c->resonance_balance[k]:0):c->resonance[k];if(c->page==ILHA_FRAGMENT_ENV)return c->fragment_env[c->loop][k&1];if(c->machine==ILHA_DUAL&&c->page==ILHA_GLO)return k==0?c->dual_gain:k<3?c->heads[k-1].pan:(int32_t)c->dual_bpm;if(c->page==ILHA_LFO&&c->machine==ILHA_ECO)return k==0?c->eco_level[3]:c->bed_lfo[k==1?1:k==2?0:2];if(c->page==ILHA_LFO){const ilha_lfo_t *l=&c->lfos[c->lfo_selected&1u];return k==0?l->depth:k==1?l->rate:k==2?l->route:l->dest;}if(c->page==ILHA_SETTINGS)return (int32_t)(k==0?c->midi_source:k==1?c->midi_control_source:0);if(c->page==ILHA_WANDER)return c->wander[c->loop][k==0&&c->wander[c->loop][3]?4:k];if(c->page==ILHA_WEATHER)return c->weather[k&1];if(c->page==ILHA_RESPONSE)return c->response[k&1];if(c->page==ILHA_FX)return c->fx_page==1?c->echo[k]:c->fx_page==2?c->space[k]:c->glitch[k];if(c->machine==ILHA_ECO&&c->page==ILHA_GLO)return k==0?c->eco_density:k==1?c->eco_global[3]:k==2?(int32_t)c->eco_seed:c->eco_global[1];if(c->machine==ILHA_ECO&&c->page==ILHA_EDIT&&c->eco_activity_page)return k==0?(int32_t)c->family_activity[c->eco_family%3]:k<3?c->eco_sends[c->eco_family%3][k-1]:0;if(c->machine==ILHA_ECO&&c->page==ILHA_EDIT)return k==0?c->eco_level[c->eco_family]:k==1?c->eco_register[c->eco_family==1?2:c->eco_family==2?1:0]:k==2?(int32_t)c->family_cycle[c->eco_family]:(int32_t)c->family_tame[c->eco_family];if(c->machine==ILHA_ECO&&c->page==ILHA_WIND)return k<2?c->wind[k]:k==3?(int32_t)c->wind_fx:0;if(c->machine==ILHA_ECO)return c->eco_level[k];const ilha_loop_t *h=&c->heads[c->loop];return k==0?h->start:k==1?h->size:k==2?h->speed:h->level;}
int ilha_ui_keys(ilha_ui_t *u,ilha_controls_t *c,uint32_t notes,uint32_t select_down){
 notes&=0x7ffffffu;uint32_t physical=notes,old_run=c->dual_run[0]|(c->dual_run[1]<<1);uint32_t old=c->notes,old_a=c->latched[0],old_b=c->latched[1];
 if(c->machine==ILHA_DUAL){
  u->transport_blocked&=notes;
  if(u->play_down&&!u->transport_open&&((notes&~u->transport_keys)&((1u<<0)|(1u<<14)))){u->transport_open=1;c->latched[0]=c->latched[1]=0;}
  if(u->transport_open){uint32_t hit=notes&~u->transport_keys;for(uint32_t k=0;k<2;k++)if(hit&(1u<<(k?14:0)))c->dual_run[k]^=1u;c->playing=(uint8_t)!!(c->dual_run[0]|c->dual_run[1]);u->transport_keys=notes;u->transport_blocked|=notes;notes=0;}
  else if(u->play_down){u->transport_blocked|=notes;notes=0;}else notes&=~u->transport_blocked;
 }
 uint32_t home=c->machine==ILHA_DUAL&&c->page==ILHA_HOME&&!u->transport_open;
 if(select_down&&!u->sel_down){u->sel_home=(uint8_t)home;u->sel_used=0;}
 if(!home)u->sel_home=0;
 if(home&&select_down&&u->sel_home){
  uint32_t pressed=notes&~u->raw_previous;
  /* Also allow holding a key first, then SEL: both orders form the chord. */
  if(!u->sel_down)pressed|=notes;
  for(uint32_t bank=0;bank<2;bank++){uint32_t keys=pressed&fragment_mask(bank);if(keys){for(uint32_t key=0;key<27;key++)if(keys&(1u<<key))c->latched[bank]=1u<<key;u->sel_used=1;}}
 }
 if(!select_down&&u->sel_down&&u->sel_home&&!u->sel_used)c->latched[0]=c->latched[1]=0;
 if(c->machine!=ILHA_DUAL)c->latched[0]=c->latched[1]=0;
 c->local_notes=u->transport_open?0:notes|c->latched[0]|c->latched[1];c->notes=u->transport_open?0:c->local_notes|c->midi_notes;u->raw_previous=physical;u->sel_down=(uint8_t)!!select_down;
 return old_run!=(c->dual_run[0]|(c->dual_run[1]<<1))||old!=c->notes||old_a!=c->latched[0]||old_b!=c->latched[1];
}
void ilha_ui_init(ilha_ui_t *u){*u=(ilha_ui_t){.home_at=0};}
void ilha_ui_home(ilha_ui_t *u,ilha_controls_t *c,uint32_t down,uint32_t now){if(down&&!u->home_down){u->home_down=1;u->home_long=0;u->home_at=now;}else if(!down&&u->home_down){u->home_down=0;if(!u->home_long)ilha_controls_home(c,(uint32_t)(now-u->home_at)>=800);u->hud=0;}}
void ilha_ui_play(ilha_ui_t *u,ilha_controls_t *c,uint32_t down,uint32_t now){
 if(c->machine!=ILHA_DUAL){if(down)ilha_ui_button(u,c,IU_PLAY,now);return;}
 if(down&&!u->play_down){u->play_down=1;u->play_at=now;u->transport_keys=u->raw_previous;}
 else if(!down&&u->play_down){uint32_t held=u->transport_open||(uint32_t)(now-u->play_at)>=400;u->play_down=u->transport_open=0;u->transport_blocked|=u->raw_previous;if(!held)ilha_ui_button(u,c,IU_PLAY,now);}
}
void ilha_ui_tick(ilha_ui_t *u,ilha_controls_t *c,uint32_t now){if(u->v_notice&&(uint32_t)(now-u->v_notice_at)>=4000u)u->v_notice=0;if(c->machine==ILHA_DUAL&&u->play_down&&!u->transport_open&&(uint32_t)(now-u->play_at)>=400){u->transport_open=1;u->transport_blocked|=u->raw_previous;u->transport_keys=u->raw_previous;c->local_notes=c->notes=c->latched[0]=c->latched[1]=0;u->hud=0;}if(c->machine==ILHA_DUAL){for(uint32_t bank=0;bank<2;bank++){uint32_t mask=fragment_mask(bank),held=c->notes&mask,rev=1u<<(bank?15:1);if(held&~rev)held&=~rev;uint32_t pressed=held&~u->previous_notes;if(pressed){for(uint32_t key=0;key<27;key++)if(pressed&(1u<<key))u->performance_key[bank]=key;}else if(held&&!(held&(1u<<u->performance_key[bank]))){for(uint32_t key=0;key<27;key++)if(held&(1u<<key))u->performance_key[bank]=key;}}}u->previous_notes=c->notes;uint32_t dt=now-u->tick_at;u->tick_at=now;if(u->tick_valid&&(c->playing||(c->machine==ILHA_ECO&&(c->notes||u->wind))))u->motion_ms+=dt>100?100:dt;if(u->tick_valid&&c->playing){uint32_t decay=dt>100?100:dt;for(uint32_t k=0;k<3;k++){u->eco_pulse[k]=u->eco_pulse[k]>decay?u->eco_pulse[k]-decay:0;u->eco_grid_pulse[k]=u->eco_grid_pulse[k]>decay?u->eco_grid_pulse[k]-decay:0;}u->eco_beat=u->eco_beat>decay?u->eco_beat-decay:0;}u->tick_valid=1;if(!u->play_down&&u->home_down&&!u->home_long&&(uint32_t)(now-u->home_at)>=800){u->home_long=1;u->hud=0;ilha_controls_home(c,1);}if(u->hud&&(uint32_t)(now-u->hud_at)>=2000)u->hud=0;}
void ilha_ui_ecosystem(ilha_ui_t *u,const ilha_controls_t *c,const uint32_t events[3],uint32_t ticks,uint32_t step){
 if(c->machine!=ILHA_ECO){u->eco_valid=0;for(uint32_t k=0;k<3;k++)u->eco_pulse[k]=0;u->eco_beat=0;return;}
 for(uint32_t k=0;k<3;k++){if(u->eco_valid&&c->playing&&events[k]!=u->eco_events[k])u->eco_pulse[k]=k==0?600:k==1?300:650;u->eco_events[k]=events[k];}
 if(u->eco_valid&&c->playing&&ticks!=u->eco_ticks)u->eco_beat=150;
 u->eco_ticks=ticks;u->eco_step=step;u->eco_valid=1;
}
int ilha_ui_button(ilha_ui_t *u,ilha_controls_t *c,uint32_t b,uint32_t now){(void)now;uint32_t page;
 if((u->transport_open||u->play_down)&&b!=IU_PLAY)return 0;
 if(b==IU_ARP){if(c->machine==ILHA_DUAL&&c->page==ILHA_WANDER){uint32_t limit=(uint32_t)(100-c->heads[c->loop].size)*65536u/100u,at=(uint32_t)c->heads[c->loop].start*65536u/100u;c->landing_position[c->loop]=at>limit?limit:at;}u->hud=0;return ilha_controls_page(c,c->machine==ILHA_DUAL?(c->page==ILHA_WANDER?ILHA_LANDING:c->page==ILHA_LANDING?ILHA_VFORMATION:ILHA_WANDER):c->page==ILHA_RESPONSE?ILHA_DISTANCE:ILHA_RESPONSE);}
 if(b==IU_SEQ){u->hud=0;return ilha_controls_page(c,c->machine==ILHA_ECO?(c->page==ILHA_DRIFT?ILHA_WEATHER:ILHA_DRIFT):ILHA_MOTION);}
 if(b==IU_ENV&&c->machine==ILHA_DUAL){u->hud=0;return ilha_controls_page(c,c->page==ILHA_LOOP_SHAPE?ILHA_FRAGMENT_ENV:ILHA_LOOP_SHAPE);}
 if(b==IU_ENV&&c->machine==ILHA_ECO){u->hud=0;c->resonance_page=c->page==ILHA_RESONANCE?(c->resonance_page+1)%3:0;return ilha_controls_page(c,ILHA_RESONANCE);}
 if(b==IU_REC&&c->machine==ILHA_DUAL){u->motion_action=u->motion_state==1?1:0;c->motion_command=1;c->motion_revision++;c->page=ILHA_MOTION;u->hud=0;return 1;}
 if(b==IU_CONFIRM&&c->machine==ILHA_ECO&&c->page==ILHA_EDIT){c->eco_activity_page^=1u;u->hud=0;return 1;}
 if(b==IU_CONFIRM&&c->machine==ILHA_ECO&&c->page==ILHA_LFO){c->ocean_setup=0;u->hud=0;return 0;}
 if(b==IU_CONFIRM&&c->page==ILHA_LANDING){uint32_t q=c->loop,p=c->landing_point[q]&7u;ilha_landing_bank_t *bank=&c->landing[q][c->sample_slot[q]&3u];if(u->landing_action)bank->mask&=~(1u<<p);else {bank->point[p]=(uint16_t)c->landing_position[q];bank->mask|=1u<<p;}c->landing_revision++;c->landing_pending=1;u->hud=0;return 1;}
 if(b==IU_CONFIRM&&c->page==ILHA_VFORMATION){u->v_notice=0;return 1;}
 if(b==IU_CONFIRM&&c->page==ILHA_MOTION){c->motion_command=u->motion_action==0?1:u->motion_action==1?2:3;if(u->motion_action==2)u->motion_action=0;c->motion_revision++;return 1;}
 if(b==IU_CONFIRM&&c->machine==ILHA_ECO&&c->page==ILHA_RESONANCE&&c->resonance_page==2){c->resonance_sources^=1u<<(c->resonance_source_cursor%3);u->hud=0;return 1;}

 if(b==IU_CONFIRM&&c->page==ILHA_FX){if(!c->fx_page){c->glitch_sync^=1u;u->hud=0;return 1;}if(c->fx_page!=2)return 0;c->ice^=1u;u->hud=0;return 1;}
 if(b==IU_FX){if(c->page==ILHA_FX)c->fx_page=(c->fx_page+1u)%3u;else c->fx_page=0;u->hud=0;return ilha_controls_page(c,ILHA_FX);}
 if(b==IU_GLO&&c->machine==ILHA_DUAL&&c->page==ILHA_GLO){c->dual_glo_page=0;u->hud=0;return 1;}
 if(b==IU_EDIT&&c->machine==ILHA_ECO&&c->page==ILHA_EDIT){c->eco_activity_page^=1u;u->hud=0;return 1;}
 if(b==IU_EDIT&&c->machine==ILHA_DUAL&&(c->page==ILHA_WAVE||c->page==ILHA_EDIT)){c->sync_panel^=1u;u->hud=0;u->message[0]=0;return 1;}
 if(b==IU_CONFIRM&&c->machine==ILHA_ECO&&(c->page==ILHA_WIND||(c->page==ILHA_EDIT&&c->eco_family==4))){if(c->harmony_page)c->harmony_page=(c->harmony_page+1)%3;u->hud=0;return 1;}
 if(b==IU_LFO&&c->machine==ILHA_DUAL&&c->page==ILHA_LFO){c->lfo_selected^=1u;u->hud=0;return 1;}
 if(b==IU_CONFIRM&&c->machine==ILHA_DUAL&&c->page==ILHA_LFO){c->lfos[c->lfo_selected&1u].enabled^=1;u->hud=0;return 1;}
 
 if(b==IU_CONFIRM&&c->machine==ILHA_ECO&&(c->page==ILHA_GLO||c->page==ILHA_HOME)){uint32_t seed=c->eco_seed+now+0x9e3779b9u;seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;uint32_t next=seed%999u;if(next>=c->eco_seed)next++;c->eco_seed=next;u->hud=0;return 1;}

 if(b==IU_PLAY){if(c->machine==ILHA_DUAL){uint32_t run=!(c->dual_run[0]|c->dual_run[1]);c->dual_run[0]=c->dual_run[1]=run;c->playing=(uint8_t)run;}else c->playing=!c->playing;if(!c->playing){if(c->machine==ILHA_ECO)c->drift[3]=0;c->local_notes&=~(c->latched[0]|c->latched[1]);c->notes&=~(c->latched[0]|c->latched[1]);c->latched[0]=c->latched[1]=0;}return 1;}
#if REVO_BIOMA_ONLY
 if(b==IU_CONFIRM&&c->page==ILHA_MENU){const uint8_t pages[2]={ILHA_SETTINGS,ILHA_INFO};return ilha_controls_page(c,pages[u->menu%2]);}
 if(c->page==ILHA_MACHINE){c->page=ILHA_HOME;c->machine=ILHA_ECO;return 1;}
#endif
 if(b==IU_CONFIRM&&c->page==ILHA_MACHINE){c->machine=u->machine_choice;u->eco_valid=0;c->playing=0;c->dual_run[0]=c->dual_run[1]=0;c->sync_panel=0;u->transport_open=u->play_down=0;c->local_notes=c->notes=0;c->latched[0]=c->latched[1]=0;c->page=ILHA_HOME;u->hud=0;return 1;}
 if(b==IU_CONFIRM&&c->page==ILHA_MENU){const uint8_t pages[3]={ILHA_MACHINE,ILHA_SETTINGS,ILHA_INFO};const uint8_t dual_menu[3]={ILHA_MACHINE,ILHA_SETTINGS,ILHA_INFO};u->machine_choice=c->machine;return ilha_controls_page(c,c->machine==ILHA_DUAL?dual_menu[u->menu%3]:pages[u->menu%3]);}
 if(b==IU_EDIT)page=ILHA_EDIT;else if(b==IU_FX)page=ILHA_FX;else if(b==IU_SAMPLE)page=ILHA_SAMPLE;else if(b==IU_LFO)page=ILHA_LFO;else if(b==IU_GLO)page=ILHA_GLO;else if(b==IU_SAVE)page=ILHA_SAVE;else if(b==IU_PRESETS)page=ILHA_PRESETS;else return 0;
 u->hud=0;u->message[0]=0;return ilha_controls_page(c,page);
}
void ilha_ui_select(ilha_ui_t *u,ilha_controls_t *c,int32_t step){
 if(!step||u->transport_open||u->play_down)return;if(c->page==ILHA_LANDING){u->landing_action=(uint8_t)((u->landing_action+step%2+2)%2);return;}if(c->page==ILHA_MOTION){u->motion_action=(uint8_t)((u->motion_action+step%3+3)%3);return;}if(c->page==ILHA_MACHINE){u->machine_choice=step>0?ILHA_ECO:ILHA_DUAL;return;}
 if(c->page==ILHA_MENU){int32_t count=REVO_BIOMA_ONLY?2:3;int32_t v=(int32_t)u->menu+step%count;u->menu=(uint8_t)((v%count+count)%count);return;}
 /* SELECT stays within the open section. Action menus retain selection. */
 if(c->page==ILHA_FX){c->fx_page=(c->fx_page+step%3+3)%3;u->hud=0;return;}
 if(c->machine==ILHA_ECO&&c->page==ILHA_EDIT){ilha_ui_algorithm(u,c,step);return;}
 if(c->machine==ILHA_ECO&&c->page==ILHA_RESONANCE){c->resonance_page=(c->resonance_page+step%3+3)%3;u->hud=0;return;}
 if(c->machine==ILHA_ECO&&c->page==ILHA_WIND){c->harmony_page=(c->harmony_page+step%3+3)%3;u->hud=0;return;}
 if(c->machine==ILHA_ECO&&(c->page==ILHA_RESPONSE||c->page==ILHA_DISTANCE)){if(step%2)ilha_controls_page(c,c->page==ILHA_RESPONSE?ILHA_DISTANCE:ILHA_RESPONSE);u->hud=0;return;}
 if(c->machine==ILHA_ECO&&(c->page==ILHA_DRIFT||c->page==ILHA_WEATHER)){if(step%2)ilha_controls_page(c,c->page==ILHA_DRIFT?ILHA_WEATHER:ILHA_DRIFT);u->hud=0;return;}
 if(c->machine==ILHA_ECO&&c->page!=ILHA_HOME)return;
 const uint8_t dual[]={ILHA_HOME,ILHA_WAVE,ILHA_SAMPLE,ILHA_FX,ILHA_LFO,ILHA_GLO,ILHA_SETTINGS};
 const uint8_t eco[]={ILHA_HOME,ILHA_EDIT,ILHA_FX,ILHA_WIND,ILHA_LFO,ILHA_RESPONSE,ILHA_DISTANCE,ILHA_DRIFT,ILHA_RESONANCE,ILHA_GLO,ILHA_SETTINGS};
 uint32_t count=c->machine==ILHA_DUAL?7u:11u;const uint8_t *pages=c->machine==ILHA_DUAL?dual:eco;uint32_t at=0;
 for(uint32_t i=0;i<count;i++)if(c->page==pages[i])at=i;
 uint32_t moves=(step<0?0u-(uint32_t)step:(uint32_t)step)%count;
 ilha_controls_page(c,pages[(at+(step<0?count-moves:moves))%count]);u->hud=0;
}
void ilha_ui_algorithm(ilha_ui_t *u,ilha_controls_t *c,int32_t step){
 if(!step||u->transport_open||u->play_down)return;
 if(c->machine==ILHA_DUAL&&c->page==ILHA_FX){c->fx_route=(c->fx_route+step%3+3)%3;u->hud=0;}
 else if(c->machine==ILHA_DUAL&&c->page==ILHA_LFO){ilha_lfo_t *l=&c->lfos[c->lfo_selected&1u];l->shape=(l->shape+step%6+6)%6;u->hud=5;copy(u->message,"SHAPE");}
 else if(c->machine==ILHA_ECO&&c->page==ILHA_DISTANCE){c->eco_family=(c->eco_family+step%3+3)%3;u->hud=0;}
 else if(c->machine==ILHA_ECO){uint32_t previous=c->page;if(previous!=ILHA_EDIT)c->eco_activity_page=0;c->harmony_page=0;c->page=ILHA_EDIT;if(previous!=ILHA_HOME)c->eco_family=(c->eco_family+step%3+3)%3;u->hud=0;u->message[0]=0;}
 else ilha_controls_select_loop(c,step>0?1:0);
}
/* Accelerate continuous controls only. Slow/reversed/context-changed turns stay precise. */
static int knob_continuous(const ilha_controls_t *c,uint32_t k){
 if(c->machine==ILHA_DUAL&&c->page==ILHA_WAVE&&c->sync_panel)return 0;
 if(c->page==ILHA_FX&&!c->fx_page&&k==2)return 0;
 if(c->machine==ILHA_DUAL&&c->page==ILHA_GLO&&k==0)return 0;
 if(c->page==ILHA_VFORMATION)return k==1;
 if(c->page==ILHA_LANDING)return k==0;
 if(c->page==ILHA_WANDER&&(k>=2||(k==0&&c->wander[c->loop][3])))return 0;
 if(k>3||c->page==ILHA_SAMPLE||c->page==ILHA_SETTINGS)return 0;
 if(c->machine==ILHA_DUAL&&c->page==ILHA_LFO)return k<2;
 if(c->machine==ILHA_ECO){
  if((c->page==ILHA_WIND||(c->page==ILHA_EDIT&&c->eco_family==4))&&c->harmony_page==1)return 0;
  if(c->page==ILHA_RESONANCE)return c->resonance_page==2?(k==1||k==2):c->resonance_page?k==0:k<3;
  if(c->page==ILHA_DISTANCE)return k<3;
  if(c->page==ILHA_WEATHER)return k==0;
  if(c->page==ILHA_DRIFT)return k==0;
  if(c->page==ILHA_LFO)return k<3;
  if(c->page==ILHA_EDIT)return c->eco_activity_page?k<3:k<2;
  if(c->page==ILHA_WIND||(c->page==ILHA_EDIT&&c->eco_family==4))return k==0||c->harmony_page==2;
  if(c->page==ILHA_GLO)return k!=2;
 }
 return 1;
}
void ilha_ui_knob(ilha_ui_t *u,ilha_controls_t *c,uint32_t k,int32_t steps,uint32_t now){
 if(k>3||!steps||u->transport_open||u->play_down)return;uint32_t context=c->page|(c->machine<<8)|(c->loop<<9)|(c->eco_family<<10)|(c->harmony_page<<13)|(c->fx_page<<23)|(c->eco_glo_page<<16)|(c->dual_glo_page<<17)|(c->lfo_selected<<18)|(c->page==ILHA_WANDER?(uint32_t)c->wander[c->loop][3]<<20:0)|(c->sync_panel<<22)|(c->resonance_page<<25)|(c->eco_activity_page<<27)|(c->ocean_setup<<28);
 int direction=steps>0?1:-1;uint32_t elapsed=now-u->knob_at[k],factor=1;
 if(knob_continuous(c,k)&&u->knob_seen[k]&&u->knob_context[k]==context&&u->knob_dir[k]==direction){uint32_t magnitude=(uint32_t)(steps<0?-(int64_t)steps:steps);uint32_t interval=elapsed/(magnitude?magnitude:1);if(elapsed<350){if(interval<25)factor=8;else if(interval<65)factor=4;else if(interval<130)factor=2;}
  if(c->page==ILHA_FRAGMENT_ENV&&factor>1)factor*=2;}
 u->knob_seen[k]=1;u->knob_at[k]=now;u->knob_context[k]=context;u->knob_dir[k]=(int8_t)direction;
 if(steps>4096)steps=4096;if(steps< -4096)steps=-4096;
 uint32_t old_link=c->vformation[c->loop][0];
 if(ilha_controls_knob(c,k,steps*(int32_t)factor)){if(c->page==ILHA_VFORMATION&&k==3&&!old_link&&c->vformation[c->loop][0]){u->v_notice=1;u->v_notice_loop=c->loop;u->v_notice_at=now;}u->hud=(uint8_t)(k+1);u->hud_at=now;u->hud_value=knob_value(c,k);copy(u->message,ilha_controls_label(c,k));}
}
static void text(const ilha_draw_t *d,int x,int y,const char *s,uint16_t col){d->text(d->ctx,x,y,s,col);}
static void large(const ilha_draw_t *d,int x,int y,const char *s,uint16_t col){if(d->large)d->large(d->ctx,x,y,s,col);else text(d,x,y,s,col);}
static void center(const ilha_draw_t *d,int y,const char *s,uint16_t col){uint32_t n=0;while(s[n])n++;text(d,(240-(int)n*8)/2,y,s,col);}
static void box(const ilha_draw_t *d,int x,int y,int w,int h,uint16_t col){d->line(d->ctx,x,y,x+w-1,y,col);d->line(d->ctx,x,y,x,y+h-1,col);d->line(d->ctx,x+w-1,y,x+w-1,y+h-1,col);d->line(d->ctx,x,y+h-1,x+w-1,y+h-1,col);}
/* FX-only meters. Loops retain their existing numerical presentation. */
static void meter(const ilha_draw_t *d,int y,int32_t value,int32_t lo,int32_t hi,uint16_t colour){
 if(value<lo)value=lo;if(value>hi)value=hi;
 d->rect(d->ctx,8,y,224,3,GRAY);int w=(value-lo)*224/(hi-lo);
 if(lo<0){int zero=(-lo)*224/(hi-lo),left=w<zero?w:zero,width=w<zero?zero-w:w-zero;if(width)d->rect(d->ctx,8+left,y,width,3,colour);d->line(d->ctx,8+zero,y-2,8+zero,y+4,WHITE);}
 else if(w)d->rect(d->ctx,8,y,w,3,colour);
}
/* Deterministic threshold field: stable dots, monotonic density, no DSP RNG. */
static uint32_t noise_rank(int x,int y){uint32_t h=(uint32_t)x*0x45d9f3bu^(uint32_t)y*0x27d4eb2du;h^=h>>16;h*=0x45d9f3bu;return (h^(h>>16))&255u;}
static void noise_box(const ilha_draw_t *d,int level){
 d->rect(d->ctx,8,160,224,38,0);box(d,8,160,224,38,GRAY);
 if(level<=0)return;if(level>=100){d->rect(d->ctx,9,161,222,36,WHITE);return;}
 uint32_t threshold=(uint32_t)level*256u/100u;
 for(int y=0;y<36;y++){int start=-1;for(int x=0;x<=222;x++){int on=x<222&&noise_rank(x,y)<threshold;if(on&&start<0)start=x;if(!on&&start>=0){d->rect(d->ctx,9+start,161+y,x-start,1,WHITE);start=-1;}}}
}
static uint16_t fade_colour(uint16_t colour,uint32_t pulse,uint32_t duration,int level){uint32_t gain=pulse*(uint32_t)level/duration;return (uint16_t)((((colour>>11)*gain/100)<<11)|((((colour>>5)&63)*gain/100)<<5)|((colour&31)*gain/100));}
static void rate_text(char *buf,int32_t rate){number(buf,rate/1000);uint32_t n=0;while(buf[n])n++;buf[n++]='.';buf[n++]=(char)('0'+rate/100%10);buf[n++]=(char)('0'+rate/10%10);buf[n++]=' ';buf[n++]='H';buf[n++]='Z';buf[n]=0;}
/* 64-entry sine curve follows the approved oscillator; display math only. */
void ilha_ui_scope(ilha_ui_t *u,const ilha_controls_t *c,uint32_t phase,uint32_t seed,int32_t held){
 static const int16_t sine[65]={0,3212,6393,9512,12539,15446,18204,20787,23170,25329,27245,28898,30273,31356,32137,32609,32767,32609,32137,31356,30273,28898,27245,25329,23170,20787,18204,15446,12539,9512,6393,3212,0,-3212,-6393,-9512,-12539,-15446,-18204,-20787,-23170,-25329,-27245,-28898,-30273,-31356,-32137,-32609,-32767,-32609,-32137,-31356,-30273,-28898,-27245,-25329,-23170,-20787,-18204,-15446,-12539,-9512,-6393,-3212,0};
 uint32_t selected=c->lfo_selected&1u;const ilha_lfo_t *l=&c->lfos[selected];
 if(!c->playing&&l->enabled){uint64_t cycles=(uint64_t)u->tick_at*l->rate;phase=(uint32_t)((cycles%1000000u)*4294967296ULL/1000000u);seed=(uint32_t)(cycles/1000000u)+0x9e3779b9u;seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;held=(int32_t)(seed>>16)-32768;}
 if(l->enabled||!(u->scope_valid&(1u<<selected))){u->scope_phase[selected]=phase;u->scope_seed[selected]=seed;u->scope_held[selected]=held;u->scope_valid|=1u<<selected;}
 else{phase=u->scope_phase[selected];seed=u->scope_seed[selected];held=u->scope_held[selected];}
 uint32_t stride=l->shape==2?178956970u:89478485u;
 for(uint32_t i=0;i<96;i++){
  int32_t v;
  if(l->shape==5)v=revo_drift(phase,held,(int32_t)(seed>>16)-32768);
  else if(l->shape==2)v=held;
  else if(l->shape==3)v=(int32_t)(phase>>16)-32768;
  else if(l->shape==4)v=32767-(int32_t)(phase>>16);
  else if(l->shape==1){int32_t x=(int32_t)(phase>>16);v=x<16384?x*2:x<49152?65536-x*2:x*2-131072;}
  else{uint32_t k=phase>>26,f=(phase>>10)&65535;int32_t delta=(sine[k+1]-sine[k])*(int32_t)f;v=sine[k]+(int32_t)((delta+(delta<0?65535:0))>>16);}
  u->scope[i]=(int8_t)(v*l->depth*34/(32768*100));
  uint32_t old=phase;phase+=stride;
  if(phase<old){if(l->shape==5)held=(int32_t)(seed>>16)-32768;seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;if(l->shape!=5)held=(int32_t)(seed>>16)-32768;}
 }
}
static void fx_bar(const ilha_draw_t *d,int x,int y,int32_t value,uint32_t bipolar){
 const int w=104,h=10;value=value< -100?-100:value>100?100:value;
 d->rect(d->ctx,x,y,w,h,0);box(d,x,y,w,h,GRAY);
 if(bipolar){int mid=x+w/2,fill=(value<0?-value:value)*(w-2)/200;if(fill)d->rect(d->ctx,value<0?mid-fill:mid,y+1,fill,h-2,WHITE);d->line(d->ctx,mid,y-2,mid,y+h+1,WHITE);}
 else{int fill=(value<0?0:value)*(w-2)/100;if(fill)d->rect(d->ctx,x+1,y+1,fill,h-2,WHITE);}
}
static void fx_circle(const ilha_draw_t *d,int cx,int cy,int value,int bipolar,uint16_t colour){
 const int radius=19;int magnitude=value<0?-value:value;if(magnitude>100)magnitude=100;
 int fill=radius*2*magnitude/100,limit=radius-fill;
 for(int y=-radius;y<=radius;y++){
  int x=0;while((x+1)*(x+1)+y*y<=radius*radius)x++;
  if(!bipolar){if(y>limit||magnitude==100)d->rect(d->ctx,cx-x,cy+y,x*2+1,1,colour);}
  else if(magnitude){int width=x*magnitude/100;if(width){if(value<0)d->rect(d->ctx,cx-width,cy+y,width,1,colour);else d->rect(d->ctx,cx+1,cy+y,width,1,colour);}}
  d->rect(d->ctx,cx-x,cy+y,1,1,GRAY);d->rect(d->ctx,cx+x,cy+y,1,1,GRAY);
 }
 if(bipolar&&!value)d->line(d->ctx,cx,cy-5,cx,cy+5,colour);
}
/* Small fixed polygon, filled in scanlines; no bitmap asset or audio changes. */
static void fx_burst(const ilha_draw_t *d,int cx,int cy,int amount){
 static const int8_t shape[14][2]={{-3,-31},{4,-12},{30,-27},{13,-4},{23,8},{8,6},{18,30},{1,15},{-16,29},{-13,10},{-33,16},{-14,-2},{-30,-18},{-8,-15}};
 int size=20+(amount<0?0:amount>100?100:amount)*80/100;
 int px[14],py[14];for(int i=0;i<14;i++){px[i]=cx+shape[i][0]*size/100;py[i]=cy+shape[i][1]*size/100;}
 if(!amount){for(int i=0;i<14;i++)d->line(d->ctx,px[i],py[i],px[(i+1)%14],py[(i+1)%14],GRAY);return;}
 for(int y=cy-32;y<=cy+31;y++){
  int hits[14],n=0;
  for(int i=0,j=13;i<14;j=i++)if((py[i]<=y&&py[j]>y)||(py[j]<=y&&py[i]>y))hits[n++]=px[i]+(y-py[i])*(px[j]-px[i])/(py[j]-py[i]);
  for(int i=1;i<n;i++){int v=hits[i],j=i;while(j&&hits[j-1]>v){hits[j]=hits[j-1];j--;}hits[j]=v;}
  for(int i=0;i+1<n;i+=2)if(hits[i+1]>=hits[i])d->rect(d->ctx,hits[i],y,hits[i+1]-hits[i]+1,1,RED);
 }
}
static void fx_reverb_row(const ilha_draw_t *d,int y,int amount,const char *label){
 int x=44,w=178,h=20,fill=(w-2)*amount/100;if(fill<0)fill=0;if(fill>w-2)fill=w-2;
 box(d,x,y,w,h,GRAY);if(fill)d->rect(d->ctx,x+1,y+1,fill,h-2,BLUE);
 /* Keep every value visible; labels invert over the blue fill. */
 for(int i=0;label[i];i++){char ch[2]={label[i],0};int tx=x+5+i*8;text(d,tx,y+2,ch,tx+4<x+1+fill?0:WHITE);}
}
static void creature(const ilha_draw_t *d,int cx,int y,uint32_t kind,uint32_t talking,uint32_t tame,int scale){
 static const uint16_t sprites[3][12]={
  {0x0000,0x0038,0x007c,0x00fc,0x39fe,0x7ffc,0xfff8,0x7ff0,0x3fe0,0x0fc0,0x0840,0x1080},
  {0x0840,0x0480,0x03c0,0x07e0,0x03f0,0x7ff8,0xfffc,0x3ff8,0x0660,0x0c30,0x1818,0x300c},
  {0x3c3c,0x7e7e,0x7ffe,0xffff,0x7ffe,0x3ffc,0x1ff8,0x3ffc,0x7ffe,0xe007,0xc003,0x6006}};
 uint16_t colour=kind==0?RED:kind==1?YELLOW:BLUE;int bounce=talking?-2:0;
 if(!tame){
  for(int i=0;i<3;i++){int x=cx-11+i*11,top=y-9-(i==1?3:0);d->line(d->ctx,x-2,top,x+1,top+3,colour);d->line(d->ctx,x+1,top+3,x-1,top+3,colour);d->line(d->ctx,x-1,top+3,x+2,top+6,colour);}
 }

 for(int row=0;row<12;row++)for(int bit=0;bit<16;bit++)if(sprites[kind][row]&(1u<<(15-bit))){
  uint16_t mask=(uint16_t)(1u<<(15-bit));
  int edge=row==0||row==11||bit==0||bit==15||!(sprites[kind][row-1]&mask)||!(sprites[kind][row+1]&mask)||!(sprites[kind][row]&(mask<<1))||!(sprites[kind][row]&(mask>>1));
  if(edge||(kind==0&&row==7&&bit>5&&bit<10)||(kind==1&&row==6&&bit>5&&bit<11)||(kind==2&&row==7&&bit>5&&bit<10))d->rect(d->ctx,cx-8*scale+bit*scale,y+row*scale+bounce,scale,scale,colour);
 }
 if(kind==2){d->rect(d->ctx,cx-4*scale,y+scale+bounce,scale,scale,WHITE);d->rect(d->ctx,cx+4*scale,y+scale+bounce,scale,scale,WHITE);}else d->rect(d->ctx,cx+(kind==0?4:1)*scale,y+3*scale+bounce,scale,scale,WHITE);
}
static void weather_cloud(const ilha_draw_t *d,int ox,int oy,int divisor){
 static const int px[]={0,0,3,8,12,12,16,22,30,36,40,44,49,54,59,66,72,76,79,83,85,85,82,77,69,64,57,51,45,39,32,26,19,12,6,2,0};
 static const int py[]={24,20,16,14,14,10,5,2,2,5,10,13,13,9,6,6,9,14,18,20,24,28,31,33,33,30,31,33,33,30,32,33,33,31,30,27,24};
 for(int k=1;k<37;k++)d->line(d->ctx,ox+px[k-1]/divisor,oy+py[k-1]/divisor,ox+px[k]/divisor,oy+py[k]/divisor,WHITE);
 d->line(d->ctx,ox+19/divisor,oy+17/divisor,ox+17/divisor,oy+22/divisor,WHITE);
 d->line(d->ctx,ox+17/divisor,oy+22/divisor,ox+24/divisor,oy+25/divisor,WHITE);
 d->line(d->ctx,ox+49/divisor,oy+18/divisor,ox+53/divisor,oy+23/divisor,WHITE);
 d->line(d->ctx,ox+53/divisor,oy+23/divisor,ox+61/divisor,oy+23/divisor,WHITE);
}
static void living_value(const ilha_draw_t *d,int x,int y,const char *label,int value,uint16_t colour){
 char b[24];text(d,x,y,label,GRAY);value_text(b,value,0);text(d,x,y+18,b,WHITE);box(d,x,y+39,100,5,GRAY);if(value)d->rect(d->ctx,x+1,y+40,value*98/100,3,colour);
}
static void loop_footer(const ilha_draw_t *d,uint32_t coloured){
 static const char *labels[]={"1 Start","2 Size","3 Spd","4 Lvl"};static const int x[]={8,72,136,192};static const uint16_t colours[]={RED,BLUE,WHITE,GRAY};
 for(uint32_t k=0;k<4;k++)text(d,x[k],218,labels[k],coloured?colours[k]:GRAY);
}
static void rotary(const ilha_draw_t *d,int cx,int cy,int radius,int at,int from,uint16_t colour){
 static const int16_t px[129]={-2896,-3001,-3102,-3198,-3290,-3378,-3461,-3539,-3612,-3681,-3745,-3803,-3857,-3905,-3948,-3985,-4017,-4044,-4065,-4081,-4091,-4096,-4095,-4088,-4076,-4059,-4036,-4007,-3973,-3934,-3889,-3839,-3784,-3724,-3659,-3588,-3513,-3433,-3349,-3260,-3166,-3068,-2967,-2861,-2751,-2637,-2520,-2399,-2276,-2149,-2019,-1886,-1751,-1614,-1474,-1332,-1189,-1044,-897,-750,-601,-451,-301,-151,0,151,301,451,601,750,897,1044,1189,1332,1474,1614,1751,1886,2019,2149,2276,2399,2520,2637,2751,2861,2967,3068,3166,3260,3349,3433,3513,3588,3659,3724,3784,3839,3889,3934,3973,4007,4036,4059,4076,4088,4095,4096,4091,4081,4065,4044,4017,3985,3948,3905,3857,3803,3745,3681,3612,3539,3461,3378,3290,3198,3102,3001,2896},py[129]={2896,2788,2675,2559,2440,2317,2191,2062,1931,1797,1660,1521,1380,1237,1092,946,799,651,501,351,201,50,-101,-251,-401,-551,-700,-848,-995,-1141,-1285,-1427,-1567,-1706,-1842,-1975,-2106,-2234,-2359,-2480,-2598,-2713,-2824,-2932,-3035,-3134,-3229,-3320,-3406,-3487,-3564,-3636,-3703,-3765,-3822,-3873,-3920,-3961,-3996,-4027,-4052,-4071,-4085,-4093,-4096,-4093,-4085,-4071,-4052,-4027,-3996,-3961,-3920,-3873,-3822,-3765,-3703,-3636,-3564,-3487,-3406,-3320,-3229,-3134,-3035,-2932,-2824,-2713,-2598,-2480,-2359,-2234,-2106,-1975,-1842,-1706,-1567,-1427,-1285,-1141,-995,-848,-700,-551,-401,-251,-101,50,201,351,501,651,799,946,1092,1237,1380,1521,1660,1797,1931,2062,2191,2317,2440,2559,2675,2788,2896};
 if(at<0)at=0;if(at>128)at=128;int lo=at<from?at:from,hi=at>from?at:from,extent=radius+9;
 for(int y=-extent;y<=extent;y++){
  int run=0,begin=0;uint16_t ink=0;
  for(int x=-extent;x<=extent+1;x++){
   int r2=x*x+y*y,kind=0;
   if(x<=extent&&r2<=radius*radius&&r2>=(radius-2)*(radius-2))kind=1;
   if(x<=extent&&at!=from&&r2>=(radius+6)*(radius+6)&&r2<=(radius+9)*(radius+9)){
    int a=px[lo]*y-py[lo]*x,b=x*py[hi]-y*px[hi];
    if(hi-lo<=85?(a>=0&&b>=0):(a>=0||b>=0))kind=2;
   }
   uint16_t next=kind==1?WHITE:colour;
   if(run&&(!kind||next!=ink)){d->rect(d->ctx,cx+begin,cy+y,x-begin,1,ink);run=0;}
   if(kind&&!run){run=1;begin=x;ink=next;}
  }
 }
 int tx=cx+px[at]*(radius-5)/4096,ty=cy+py[at]*(radius-5)/4096;
 for(int o=-1;o<=1;o++){d->line(d->ctx,cx+o,cy,tx+o,ty,colour);d->line(d->ctx,cx,cy+o,tx,ty+o,colour);}
 d->line(d->ctx,cx,cy-radius-14,cx,cy-radius-11,WHITE);
}
static void time_text(char *b,int32_t ms){
 if(ms<1000){number(b,ms);uint32_t i=0;while(b[i])i++;b[i++]=' ';b[i++]='m';b[i++]='s';b[i]=0;}
 else{number(b,ms/1000);uint32_t i=0;while(b[i])i++;b[i++]='.';b[i++]=(char)('0'+ms/100%10);b[i++]=(char)('0'+ms/10%10);b[i++]=' ';b[i++]='s';b[i]=0;}
}
static int env_knob_angle(uint32_t ms,uint32_t maximum){int n=0;while(n<128&&(uint32_t)(n+1)*(n+1)*maximum<=ms*16384u)n++;return n;}
#include "revo_resonance_params.h"
static void flock_value_bar(const ilha_draw_t *d,int x,int y,int value,int maximum,uint16_t colour){
 int extent=value*50/maximum;
 for(int segment=0;segment<10;segment++){int filled=extent-segment*5;d->rect(d->ctx,x+segment*5,y,3,10,GRAY);if(filled>3)filled=3;if(filled>0)d->rect(d->ctx,x+segment*5,y,filled,10,colour);}
}
#include "ilha_eco_ui.inc"
#include "ilha_dual_ui.inc"
#include "ilha_glitch_ui.inc"
#include "ilha_vformation_ui.inc"
static void ilha_ui_render_page(const ilha_ui_t *u,const ilha_controls_t *c,const char *sample,uint32_t frames,const int16_t wave[120],uint32_t now,const ilha_draw_t *d){
 static const char *names[ILHA_PAGES]={"ISLAND","WAVE","SAMPLE","EDIT","FX","LFO","WIND","GLO","SAVE","PRESETS","SETTINGS","MENU","MACHINE","INFO","Fragments","Flock","Motion","Beam","Response","Fragments","Distance","Drift","Resonance","Landing","V Format","Loop Shape"};
 uint16_t accent=c->machine==ILHA_ECO?(c->page==ILHA_EDIT?family_colours[c->eco_family]:c->page==ILHA_HOME&&u->hud&&u->hud<=4?family_colours[u->hud-1]:WHITE):(c->page==ILHA_LFO?c->lfo_selected:c->loop)?BLUE:RED;char buf[24];
 const char *heading=c->page==ILHA_HOME?(c->machine==ILHA_DUAL?"Atolls":"BIOMA"):(c->page==ILHA_WAVE?"Edit":names[c->page]);
 if(c->machine==ILHA_ECO&&c->harmony_page&&(c->page==ILHA_WIND||(c->page==ILHA_EDIT&&c->eco_family==4)))heading=c->harmony_page==2?"Envelope":"Harmony";
 if(c->machine==ILHA_ECO&&c->page==ILHA_LFO)heading="Ocean Tide";

 if(c->page==ILHA_FX)heading=c->fx_page==1?"Echo":c->fx_page==2?"Space":"Glitch";if(c->page==ILHA_SAMPLE)heading="Samples";
 large(d,8,0,heading,WHITE);if(c->machine==ILHA_DUAL)dual_states(u,c,d);else text(d,184,9,c->playing?"PLAY":"STOP",WHITE);
 if(c->machine==ILHA_ECO){if(c->page==ILHA_HOME)text(d,8,30,"Island",GRAY);}
 else if(c->page==ILHA_HOME){text(d,8,30,c->loop?"Loop B":"Loop A",accent);text(d,64,30,"Island",accent);}
 else if(c->page==ILHA_LOOP_SHAPE)text(d,8,30,c->loop?"Loop B / Fades + Filter":"Loop A / Fades + Filter",accent);
 else if(c->page==ILHA_FRAGMENT_ENV)text(d,8,30,c->loop?"Loop B / Envelope AR":"Loop A / Envelope AR",accent);
 else if(c->page==ILHA_WAVE||c->page==ILHA_EDIT)dual_edit_subtitle(c,d);
 else if(c->page==ILHA_WANDER)text(d,8,30,c->loop?"Loop B":"Loop A",accent);
 else if(c->page==ILHA_LANDING){copy(buf,c->loop?"Loop B / point ":"Loop A / point ");uint32_t n=0;while(buf[n])n++;number(buf+n,(int32_t)c->landing_point[c->loop]+1);text(d,8,30,buf,accent);}
 else if(c->page==ILHA_GLO)text(d,8,30,"Pan / Clock / Gain",GRAY);

 if(c->machine==ILHA_ECO&&eco_page(u,c,now,d))return;
 if(c->machine==ILHA_ECO&&c->page==ILHA_HOME){
  char octave_label[]="Wind Oct +0";int oct=c->wind_octave;
  octave_label[9]=oct<0?'-':'+';octave_label[10]=(char)('0'+(oct<0?-oct:oct));
  d->rect(d->ctx,8,30,144,16,0);text(d,8,30,octave_label,GRAY);
 }
 if(c->page==ILHA_HOME){
  const uint16_t colours[4]={0,0x52aa,0xad55,WHITE};
  int bend=0; /* Static island; creatures carry the event animation. */
  int level=c->machine==ILHA_DUAL?c->heads[c->loop].level:(int)(u->wind*100u/32768u);
  for(uint32_t y=0;y<135;y++){int row_y=c->machine==ILHA_DUAL?58+(int)y*11/10:(int)y+45;int row_h=c->machine==ILHA_DUAL?58+(int)(y+1)*11/10-row_y:1;if(d->clip_h&&(row_y+row_h<=d->clip_y||row_y>=d->clip_y+d->clip_h))continue;uint32_t x=0;for(uint32_t off=ilha_island_rows[y];off<ilha_island_rows[y+1];off++){uint32_t v=ilha_island_rle[off],len=(v>>2)+1;if(v&3){int dx=(int)x+(y<83?bend*level*(83-(int)y)/32000:0);if(c->machine==ILHA_DUAL){int xx=(dx-120)*11/10+120,yy=58+(int)y*11/10;d->rect(d->ctx,xx,yy,((int)(x+len)-120)*11/10+120-xx,58+(int)(y+1)*11/10-yy,colours[v&3]);}else d->rect(d->ctx,dx,(int)y+45,(int)len,1,colours[v&3]);}x+=len;}}
  if(c->machine==ILHA_DUAL)for(uint32_t i=0;i<9;i++){int travel=c->playing?(int)((now/35)*(uint32_t)(c->heads[c->loop].speed<0?-c->heads[c->loop].speed:c->heads[c->loop].speed)/100%100):0;if(c->heads[c->loop].speed<0)travel=170-travel;int width=40+c->heads[c->loop].size*120/100;int x=120-width/2+(int)((i*23+travel)%(uint32_t)width),y=78+(int)(i*17%36);d->line(d->ctx,x,y,x+3,y+3,accent);d->line(d->ctx,x+3,y+3,x+6,y,accent);}
  if(c->machine==ILHA_ECO){
   uint32_t t=u->motion_ms;
   uint32_t variation=(uint32_t)c->eco_global[3];
   if(c->eco_level[0])for(uint32_t i=0;i<4;i++){uint16_t colour=fade_colour(RED,u->eco_pulse[0],600,c->eco_level[0]);int x=35+(int)((i*31+t/(25+(uint32_t)c->eco_register[0]/2))%170),y=61+(int)((i*13+u->eco_events[0]*variation/25)%32),flap=2+(int)(u->eco_pulse[0]/100%3);d->line(d->ctx,x,y,x+6,y+flap,colour);d->line(d->ctx,x+6,y+flap,x+12,y,colour);}
   if(c->eco_level[1]&&u->eco_pulse[1])for(uint32_t i=0;i<4;i++){int x=86+(int)((i*17+t/95+u->eco_events[1]*variation/20)%58),y=106+(int)((i*7+t/170)%8);uint16_t colour=fade_colour(YELLOW,u->eco_pulse[1],300,c->eco_level[1]);for(int dot=0;dot<3;dot++)d->rect(d->ctx,x+dot*5,y-dot*3,3,2,colour);}
   if(c->eco_level[2]&&u->eco_pulse[2])for(uint32_t i=0;i<3;i++){int r=4+(int)((650-u->eco_pulse[2])*(16-(uint32_t)c->eco_register[1]/10)/650),x=40+(int)((i*48+u->eco_events[2]*variation/25)%165),y=159+(int)(i%2)*9;uint16_t colour=fade_colour(BLUE,u->eco_pulse[2],650,c->eco_level[2]);d->line(d->ctx,x-r,y,x+r,y,colour);d->line(d->ctx,x-r,y+1,x+r,y+1,colour);d->line(d->ctx,x-r/2,y+4,x+r/2,y+4,colour);}
   int bed=c->eco_level[3];
   for(int y=179;y<189;y+=2)for(int x=25;x<215;x+=3)if(noise_rank(x+(int)(t/150%256),y)<(uint32_t)bed)d->rect(d->ctx,x,y,1,1,WHITE);


  }
  if(c->machine==ILHA_ECO)text(d,8,195,"SEL: Random Seed",GRAY);text(d,8,218,c->machine==ILHA_DUAL?"PRESET: Samples  EDIT  FX":"EDIT  FX  SELECT: PAGES",GRAY);
 }else if(c->page==ILHA_WAVE||(c->machine==ILHA_DUAL&&c->page==ILHA_EDIT)){
  if(c->sync_panel){dual_sync_panel(u,c,wave,d);return;}

  d->line(d->ctx,0,142,239,142,GRAY);for(uint32_t i=0;i<120;i++){int h=(int)((int32_t)wave[i]*56/32768);if(h<0)h=-h;d->line(d->ctx,(int)i*2,142-h,(int)i*2,142+h,GRAY);}
  for(uint32_t k=0;k<2;k++){if(c->sample_slot[0]!=c->sample_slot[1]&&k!=c->loop)continue;int x=c->heads[k].start*240/100,end=x+c->heads[k].size*240/100;if(end>239)end=239;box(d,x,76,end-x+1,131,k?BLUE:RED);}
  for(uint32_t k=0;k<2;k++){if(c->sample_slot[0]!=c->sample_slot[1]&&k!=c->loop)continue;int x=(int)(u->position[k]*239u/65536u);d->line(d->ctx,x,70,x,207,k?BLUE:RED);d->rect(d->ctx,x>0?x-1:0,68,3,4,WHITE);}
  if(u->hud&&u->hud<=4&&(uint32_t)(now-u->hud_at)<2000){value_text(buf,u->hud_value,u->hud==3);text(d,8,218,u->message,GRAY);text(d,152,218,buf,WHITE);}else loop_footer(d,0);
 }else if(c->machine==ILHA_DUAL&&c->page==ILHA_GLO){
  /* Gain bar, two pans and the original large clock, following the mockup. */
  for(int j=0;j<6;j++)d->rect(d->ctx,10,122-j*10,9,3,j*2<c->dual_gain?WHITE:GRAY);
  box(d,28,68,14,60,WHITE);int fill=c->dual_gain*56/12;if(fill)d->rect(d->ctx,30,126-fill,10,fill,WHITE);
  text(d,8,139,"1 Gain",WHITE);
  for(uint32_t k=0;k<2;k++){int cx=110+(int)k*79;rotary(d,cx,103,18,(c->heads[k].pan+100)*128/200,64,k?BLUE:RED);text(d,cx-28,139,k?"3 Pan B":"2 Pan A",WHITE);}
  if(u->hud>=1&&u->hud<=3&&(uint32_t)(now-u->hud_at)<1500){
   if(u->hud!=1){value_text(buf,c->heads[u->hud-2].pan,0);text(d,u->hud==2?86:165,160,buf,GRAY);}
  }
  text(d,8,187,"4 BPM",WHITE);text(d,8,218,"Fragments clock",GRAY);
  if(c->midi_source){if(d->key)d->key(d->ctx,136,174,"EXT",WHITE);else large(d,136,174,"EXT",WHITE);text(d,184,221,c->midi_source==1?"USB":"TRS",GRAY);if(!u->clock_locked)text(d,8,202,"Waiting",GRAY);}
  else{number(buf,(int32_t)c->dual_bpm);uint32_t n=0;while(buf[n])n++;if(d->key)d->key(d->ctx,232-(int)n*32,174,buf,WHITE);else large(d,184,185,buf,WHITE);}
 }else if(c->page==ILHA_LFO&&c->machine==ILHA_DUAL){
  const ilha_lfo_t *l=&c->lfos[c->lfo_selected&1u];
  text(d,8,30,c->lfo_selected?"LFO 2":"LFO 1",accent);
  box(d,8,53,224,111,GRAY);
  for(int x=14;x<228;x+=8)d->line(d->ctx,x,119,x+2,119,GRAY);
  for(uint32_t i=1;i<96;i++){
   int x=14+(int)(i-1)*212/95,a=14+(int)i*212/95,prev=119-u->scope[i-1]*37/34,next=119-u->scope[i]*37/34;uint16_t colour=l->enabled?accent:GRAY;
   if(l->shape==2){d->line(d->ctx,x,prev,a,prev,colour);d->line(d->ctx,a,prev,a,next,colour);}else d->line(d->ctx,x,prev,a,next,colour);
  }
  d->rect(d->ctx,12,117-u->scope[0]*37/34,4,4,WHITE);
  text(d,8,170,"3 Route",GRAY);text(d,152,170,"4 Target",GRAY);
  const char *targets[4]={"SPEED","LEVEL","PAN","START"},*routes[4]={"","A","B","A+B"};
  text(d,8,190,routes[l->route],accent);text(d,152,190,targets[l->dest],WHITE);
  text(d,8,218,"ALGO: shape",GRAY);text(d,l->enabled?176:168,218,l->enabled?"SEL: ON":"SEL: OFF",GRAY);
  text(d,16,58,l->shape==0?"Sine":l->shape==1?"Triangle":l->shape==2?"Sample & Hold":l->shape==3?"Saw Up":l->shape==4?"Saw Down":"Drift",GRAY);
  if(u->hud&&(uint32_t)(now-u->hud_at)<2000){
   char label[24];uint32_t n=0;
   if(u->hud==1){value_text(buf,l->depth,0);}
   else if(u->hud==2)rate_text(buf,l->rate);
   else copy(buf,u->hud==3?routes[l->route]:u->hud==4?targets[l->dest]:l->shape==0?"SINE":l->shape==1?"TRIANGLE":l->shape==2?"S&H":l->shape==3?"SAW UP":l->shape==4?"SAW DOWN":"DRIFT");
   const char *name=u->hud==5?"SHAPE":ilha_controls_label(c,u->hud-1);
   for(;name[n]&&n<12;n++)label[n]=name[n];label[n++]=' ';
   for(uint32_t i=0;buf[i]&&n<23;i++)label[n++]=buf[i];label[n]=0;
   d->rect(d->ctx,12,56,216,18,0);text(d,16,58,label,WHITE);
  }
 }else if(c->page==ILHA_VFORMATION){formation_page(u,c,now,d);
 }else if(c->page==ILHA_LANDING){
  uint32_t q=c->loop,sel=c->landing_point[q]&7u;const ilha_landing_bank_t *bank=&c->landing[q][c->sample_slot[q]&3u];
  for(int x=0;x<120;x++){int height=wave?(int)((int64_t)wave[x]*32/32768):0;d->line(d->ctx,8+x*224/120,125-height,8+x*224/120,125+height,WHITE);}
  for(uint32_t p=0;p<8;p++)if(bank->mask&(1u<<p)){int x=8+(int)((uint32_t)bank->point[p]*223u/65536u);d->line(d->ctx,x,86,x,91,p==sel?accent:GRAY);}
  int x=8+(int)(c->landing_position[q]*223u/65536u),width=c->heads[q].size*224/100;if(width<2)width=2;if(width>224)width=224;if(x>232-width)x=232-width;
  box(d,x,92,width,68,accent);d->rect(d->ctx,x-1,91,3,3,WHITE);
  for(uint32_t p=0;p<8;p++){int bx=8+(int)p*28;uint16_t fill=p==sel?accent:bank->mask&(1u<<p)?GRAY:0;if(fill)d->rect(d->ctx,bx,167,24,19,fill);box(d,bx,167,24,19,p==sel?WHITE:GRAY);number(buf,(int32_t)p+1);text(d,bx+8,168,buf,fill?0:WHITE);}
  for(uint32_t a=0;a<2;a++){int bx=38+(int)a*90;box(d,bx,192,78,20,u->landing_action==a?WHITE:GRAY);if(u->landing_action==a)d->rect(d->ctx,bx+1,193,76,18,WHITE);text(d,bx+ (a?19:23),194,a?"Erase":"Save",u->landing_action==a?0:GRAY);}
  text(d,8,68,"1 Position",WHITE);text(d,144,68,"2 Point",WHITE);
  const char *mode=c->landing_mode[q]==2?"4 Order":c->landing_mode[q]==1?"4 Points":"4 Free";text(d,8,224,"ARP > V Format",GRAY);uint32_t mode_len=0;while(mode[mode_len])mode_len++;text(d,232-(int)mode_len*8,224,mode,GRAY);
  if(c->landing_pending)text(d,8,49,c->landing_pending==2?"MEMORY ERROR":"MEMORY PENDING",GRAY);
 }else if(c->page==ILHA_WANDER){
  uint32_t landing_mode=c->landing_mode[c->loop];const ilha_landing_bank_t *bank=&c->landing[c->loop][c->sample_slot[c->loop]&3u];
  uint32_t pitch_mode=c->wander[c->loop][3];
  number(buf,(int32_t)u->flock_turns[c->loop]);uint32_t n=0;while(buf[n])n++;buf[n++]=' ';buf[n++]='/';buf[n++]=' ';number(buf+n,c->wander[c->loop][2]);while(buf[n])n++;copy(buf+n," LOOPS");while(buf[n])n++;text(d,232-(int)n*8,30,buf,WHITE);
  int at=32+(int)(u->wander_pos[c->loop]*176u/65536u),old=32+(int)(u->flock_previous[c->loop]*176u/65536u);
  int motion=pitch_mode?c->wander[c->loop][4]*100/12:c->wander[c->loop][0];if(pitch_mode)at=old=120;
  if(c->vformation[c->loop][0])text(d,8,49,"V LINK / AUTO OFF",GRAY);else if(landing_mode)text(d,8,49,landing_mode==2?"ORDER":"POINTS",GRAY);
  if(landing_mode&&!bank->mask)center(d,149,"NO POINTS",GRAY);
  if(pitch_mode){number(buf,u->flock_pitch[c->loop]);uint32_t n=0;while(buf[n])n++;buf[n++]=' ';buf[n++]='s';buf[n++]='t';buf[n]=0;uint32_t len=0;while(buf[len])len++;text(d,232-(int)len*8,49,buf,accent);}
  for(int n=0;n<12;n++){int x=12+(n*43+(int)(now/90)*(1+motion/25))%216,y=53+(n*23)%110;d->line(d->ctx,x,y,x+1+motion/25,y,GRAY);}
  for(int b=0;b<3;b++){
   int dx=(b-1)*18,y=121+(b==1?-22:0),previous_y=y;if(pitch_mode){y-=u->flock_pitch[c->loop]*3;previous_y-=u->flock_previous_pitch[c->loop]*3;}
   int flap=(now/220)%2?4:-4;
   for(int stroke=0;stroke<2;stroke++){
    d->line(d->ctx,old+dx-6,previous_y-4+stroke,old+dx,previous_y+stroke,GRAY);d->line(d->ctx,old+dx,previous_y+stroke,old+dx+6,previous_y-4+stroke,GRAY);
    d->line(d->ctx,at+dx-6,y+flap+stroke,at+dx,y+stroke,accent);d->line(d->ctx,at+dx,y+stroke,at+dx+6,y+flap+stroke,accent);
   }
  }
  d->line(d->ctx,12,170,228,170,WHITE);d->rect(d->ctx,at-1,168,3,5,accent);
  const char *labels[]={"1 Flight","2 Chance","3 Repeats"};
  for(int k=0;k<3;k++)text(d,11+k*77,182,labels[k],(c->vformation[c->loop][0]&&k!=0)||(k==0&&landing_mode)?GRAY:WHITE);
  for(int k=0;k<2;k++){
   int value=c->wander[c->loop][k==0&&pitch_mode?4:k],maximum=k==0&&pitch_mode?12:100;
   flock_value_bar(d,20+k*77,205,value,maximum,(c->vformation[c->loop][0]&&k!=0)||(k==0&&landing_mode)?GRAY:accent);
  }
  number(buf,c->wander[c->loop][2]);uint32_t digits=0;while(buf[digits])digits++;text(d,198-(int)digits*4,204,buf,WHITE);
  if(u->hud>=1&&u->hud<=2&&((u->knob_context[u->hud-1]>>9)&1u)==c->loop&&(uint32_t)(now-u->hud_at)<1600){
   uint32_t knob=u->hud-1;char label[24];copy(label,knob?"CHANCE ":"FLIGHT ");uint32_t len=0;while(label[len])len++;
   int value=c->wander[c->loop][knob==0&&pitch_mode?4:knob];if(knob==0&&pitch_mode){number(label+len,value);while(label[len])len++;label[len++]=' ';label[len++]='s';label[len++]='t';label[len]=0;}else value_text(label+len,value,0);
   d->rect(d->ctx,48,105,144,28,0);box(d,48,105,144,28,accent);uint32_t width=0;while(label[width])width++;text(d,120-(int)width*4,111,label,WHITE);
  }
  text(d,8,223,"ARP > Landing",GRAY);text(d,pitch_mode?176:152,223,pitch_mode?"4 PITCH":"4 POSITION",GRAY);
 }else if(c->page==ILHA_MOTION){
  uint32_t recorded=u->motion_count&&u->motion_target==c->loop;const uint16_t cols[]={RED,BLUE,WHITE,GRAY};
  text(d,8,30,c->loop?"Loop B /":"Loop A /",accent);text(d,80,30,recorded?"Recorded":"Editing",accent);
  if(u->motion_count&&u->motion_target!=c->loop)text(d,8,49,u->motion_target?"Clip belongs to B":"Clip belongs to A",GRAY);
  if(u->motion_state==1||recorded){for(int y=-3;y<=3;y++)for(int x=-3;x<=3;x++)if(x*x+y*y<=9)d->rect(d->ctx,220+x,38+y,1,1,RED);}
  const int bx[]={8,12,228,232,232,228,184,181,59,56,12,8,8},by[]={69,65,65,69,181,185,185,182,182,185,185,181,69};
  for(int x=18;x<226;x+=20)d->line(d->ctx,x,173,x,176,GRAY);
  if(recorded){
   for(uint32_t k=0;k<4;k++)for(uint32_t i=1;i<64;i++){
    int x=16+(int)(i-1)*208/63,xx=16+(int)i*208/63,y=87+(int)k*23-u->motion_trace[k][i-1]*17/100,yy=87+(int)k*23-u->motion_trace[k][i]*17/100;
    d->line(d->ctx,x,y,xx,y,cols[k]);d->line(d->ctx,xx,y,xx,yy,cols[k]);
   }
   int cursor=16+(int)(u->motion_cursor*208u/(u->motion_count?u->motion_count:1));if(cursor>224)cursor=224;d->line(d->ctx,cursor,73,cursor,170,WHITE);
  }else{center(d,109,"No motion yet",GRAY);center(d,128,"Rec to Draw",WHITE);}
  for(uint32_t k=0;k<3;k++){
   int x=60+(int)k*42,cx=x+18;uint16_t ink=k==u->motion_action?0:GRAY;
   if(k==u->motion_action)d->rect(d->ctx,x,183,36,25,WHITE);else {d->line(d->ctx,x,183,x,207,GRAY);d->line(d->ctx,x+35,183,x+35,207,GRAY);d->line(d->ctx,x,207,x+35,207,GRAY);}
   if(k==0){if(u->motion_state==1)d->rect(d->ctx,cx-5,190,10,10,ink);else for(int y=-5;y<=5;y++)for(int xx=-5;xx<=5;xx++)if(xx*xx+y*y<=25)d->rect(d->ctx,cx+xx,195+y,1,1,ink);}
   else if(k==1){if(u->motion_state==2){d->rect(d->ctx,cx-5,189,3,13,ink);d->rect(d->ctx,cx+3,189,3,13,ink);}else for(int xx=0;xx<10;xx++)d->line(d->ctx,cx-4+xx,189+xx/2,cx-4+xx,201-xx/2,ink);}
   else{box(d,cx-5,192,11,11,ink);d->line(d->ctx,cx-7,189,cx+7,189,ink);d->line(d->ctx,cx-2,187,cx+2,187,ink);d->line(d->ctx,cx-2,194,cx-2,200,ink);d->line(d->ctx,cx+2,194,cx+2,200,ink);}
  }
  /* Foreground frame hides button top edges, like a recessed transport strip. */
  for(int i=1;i<13;i++)d->line(d->ctx,bx[i-1],by[i-1],bx[i],by[i],accent);
  loop_footer(d,1);
 }else if(c->page==ILHA_WEATHER){
  int intensity=(int)u->weather_intensity;
  box(d,0,48,240,133,WHITE);
  text(d,8,53,c->weather[2]?"SEL / On":"SEL / Off",WHITE);
  if(intensity<65){
   int sx=60,sy=137;
   for(int y=-26;y<=0;y++)for(int x=-26;x<=26;x++)if(x*x+y*y<=676)d->rect(d->ctx,sx+x,sy+y,1,1,WHITE);
   const int dx[8]={0,14,20,14,0,-14,-20,-14},dy[8]={-20,-14,0,14,20,14,0,-14};
   int pulse=intensity<25?(int)((now/130)%6):2;if(pulse>3)pulse=6-pulse;
   for(int k=0;k<8;k++){if(dy[k]>0)continue;int scale=22+pulse;d->line(d->ctx,sx+dx[k]*15/10,sy+dy[k]*15/10,sx+dx[k]*scale/10,sy+dy[k]*scale/10,WHITE);}
  }
  if(intensity>25)weather_cloud(d,128,79,1);
  if(intensity>70)weather_cloud(d,60,84,2);
  if(intensity>45)for(int i=0;i<3+(intensity-45)/14;i++){int x=138+i*12,y=119+(int)((now/65+i*7)%16);d->line(d->ctx,x,y,x-3,y+5,WHITE);}
  if(intensity>75&&now/400%4==0){d->line(d->ctx,85,101,75,114,WHITE);d->line(d->ctx,75,114,86,114,WHITE);d->line(d->ctx,86,114,75,132,WHITE);}
  for(int row=0;row<2;row++){
   int last=142+row*9;int phase=(int)((now/180+row*8)%16);
   for(int x=8;x<=231;x++){int p=(x+phase)%16,tri=p<8?p:16-p;int y=140+row*9+tri/2;if(x>8)d->line(d->ctx,x-1,last,x,y,WHITE);last=y;}
  }
  text(d,8,158,"Calm",BLUE);text(d,192,158,"Storm",RED);
  d->line(d->ctx,10,176,229,176,GRAY);int marker=10+intensity*219/100;d->rect(d->ctx,marker-1,174,3,5,WHITE);
  living_value(d,8,188,"1 Intensity",c->weather[0],WHITE);living_value(d,128,188,"2 Movement",c->weather[1],WHITE);
 }else if(c->page==ILHA_FX){
  glitch_page(u,c,now,d);
 }else if(c->page==ILHA_INFO){
  large(d,8,52,"ReVo 1.0",WHITE);text(d,8,92,"Generative Soundscapes",GRAY);
  text(d,8,116,"Original machines",WHITE);text(d,8,134,"Bioma / Atolls",WHITE);
  text(d,8,158,"Concept, sound & design",WHITE);text(d,8,176,"gggguto",WHITE);
  text(d,8,201,"Built on Felucca / SLOOP",WHITE);text(d,8,222,"Licenses: ReVo website",GRAY);
 }else if(c->page==ILHA_SETTINGS){
  text(d,8,65,"1 MIDI CLOCK",GRAY);const char *options[3]={"OFF","USB","TRS"};for(uint32_t i=0;i<3;i++){int x=8+(int)i*76;if(c->midi_source==i)d->rect(d->ctx,x,88,72,27,WHITE);else box(d,x,88,72,27,GRAY);text(d,x+24,93,options[i],c->midi_source==i?0:GRAY);}
  {text(d,8,130,"2 MIDI CONTROL",GRAY);const char *ports[]={"OFF","USB","TRS","BOTH"};for(uint32_t i=0;i<4;i++){int x=8+(int)i*56;if(c->midi_control_source==i)d->rect(d->ctx,x,151,52,24,WHITE);else box(d,x,151,52,24,GRAY);text(d,x+(i==3?10:14),155,ports[i],c->midi_control_source==i?0:GRAY);}text(d,8,211,c->machine==ILHA_DUAL?"Notes 59-72 / CC 20-24":"Wind CH1 / CC CH1-7",GRAY);}
 }else if(c->page==ILHA_SAMPLE){
  for(uint32_t k=0;k<2;k++){int y=44+(int)k*81;uint16_t col=k?BLUE:RED;box(d,8,y,224,65,col);text(d,16,y+7,k?"2 Loop B":"1 Loop A",col);number(buf,(int32_t)c->sample_slot[k]+1);text(d,208,y+7,buf,WHITE);text(d,16,y+33,u->sample_names[k][0]?u->sample_names[k]:"Built-in / current",WHITE);}
  text(d,8,218,"PRESET > Fragments",GRAY);
 }else if(c->page==ILHA_LOOP_SHAPE){
  const int32_t *v=c->loop_shape[c->loop];int left=16+v[0]*208/100,right=224-v[1]*208/100;
  d->line(d->ctx,16,128,224,128,GRAY);d->line(d->ctx,16,128,left,64,accent);d->line(d->ctx,left,64,right,64,accent);d->line(d->ctx,right,64,224,128,accent);
  text(d,8,143,"1 Fade In",WHITE);text(d,88,143,"2 Fade Out",WHITE);text(d,174,143,"3 Filter",WHITE);
  for(uint32_t k=0;k<2;k++){int cx=42+(int)k*78;int angle=env_knob_angle((uint32_t)v[k],50);rotary(d,cx,183,14,k?128-angle:angle,k?128:0,accent);number(buf,v[k]);uint32_t n=0;while(buf[n])n++;buf[n++]='%';buf[n]=0;text(d,cx-(int)n*4,203,buf,accent);}
  rotary(d,204,183,14,(v[2]+100)*128/200,64,accent);
  text(d,8,223,"ENV > Fragments",GRAY);
 }else if(c->page==ILHA_FRAGMENT_ENV){
  int attack=c->fragment_env[c->loop][0],release=c->fragment_env[c->loop][1],ax=20+attack*32/2000,hx=106,rx=112+release*110/5000;
  box(d,8,52,224,86,GRAY);d->line(d->ctx,16,128,224,128,GRAY);
  int last=128;for(int x=16;x<=ax;x++){int t=(x-16)*32768/(ax-16),ease=(int)((int64_t)t*t/32768*(98304-2*t)/32768),y=128-ease*62/32768;if(x>16)d->line(d->ctx,x-1,last,x,y,accent);last=y;}
  d->line(d->ctx,ax,66,hx,66,accent);last=66;
  for(int x=hx+1;x<=rx;x++){int t=(x-hx)*32768/(rx-hx),ease=(int)((int64_t)t*t/32768*(98304-2*t)/32768),y=66+ease*62/32768;d->line(d->ctx,x-1,last,x,y,accent);last=y;}
  for(int y=68;y<128;y+=5)d->rect(d->ctx,hx,y,1,1,GRAY);
  uint32_t stage=u->fragment_stage[c->loop],progress=u->fragment_progress[c->loop];
  if(stage){int x=stage==1?16+(int)(progress*(uint32_t)(ax-16)/65536u):stage==2?(ax+hx)/2:hx+(int)(progress*(uint32_t)(rx-hx)/65536u);int v=(int)u->fragment_gain[c->loop],ease=(int)((int64_t)v*v/32768*(98304-2*v)/32768),y=128-ease*62/32768;d->rect(d->ctx,x-1,y-1,3,3,WHITE);}
  text(d,30,143,"1 Attack",WHITE);text(d,142,143,"2 Release",WHITE);
  rotary(d,62,185,14,env_knob_angle((uint32_t)attack,2000),0,accent);rotary(d,178,185,14,env_knob_angle((uint32_t)release,5000),0,accent);
  time_text(buf,attack);uint32_t n=0;while(buf[n])n++;text(d,62-(int)n*4,205,buf,accent);time_text(buf,release);n=0;while(buf[n])n++;text(d,178-(int)n*4,205,buf,accent);
  text(d,8,223,"ALGO: loop",GRAY);text(d,136,223,"PRESET: next",GRAY);
 }else if(c->page==ILHA_FRAGMENT){
  text(d,8,44,"Loop A",RED);text(d,176,44,"Loop B",BLUE);
  uint32_t white=0;for(uint32_t key=0;key<27;key++){
   uint32_t pc=(key+5)%12,is_white=pc!=1&&pc!=3&&pc!=6&&pc!=8&&pc!=10;
   uint16_t colour=key<13?RED:BLUE;int held=!!(c->notes&(1u<<key));
   if(is_white){int x=8+(int)white*14;box(d,x,69,13,49,colour);if(held)d->rect(d->ctx,x+1,70,11,47,colour);white++;}
   else {int x=8+(int)white*14-4;d->rect(d->ctx,x,69,8,28,key==13?WHITE:held?colour:GRAY);}
  }
  center(d,124,"Lit F#: split / no sound",GRAY);
  text(d,8,152,"White: shorter repeats",WHITE);text(d,8,171,"Black: Rev Half Double",GRAY);text(d,8,190,"then two triplet speeds",GRAY);
  for(uint32_t bank=0;bank<2;bank++)if(c->notes&fragment_mask(bank)){
   uint32_t key=u->performance_key[bank];char label[32];fragment_ui_label(c,bank,key,label);int length=0;while(label[length])length++;
   int x=8+(int)bank*116;d->rect(d->ctx,x,40,108,25,0);box(d,x,40,108,25,bank?BLUE:RED);text(d,x+54-length*4,45,label,WHITE);
  }
  text(d,8,218,"PRESET > Fragmnts Envelop",GRAY);
 }else if(c->page==ILHA_MENU){const char *eco_items[3]={REVO_BIOMA_ONLY?"Settings":"Machine",REVO_BIOMA_ONLY?"Info":"Settings","Info"};const char *dual_items[3]={"Machine","Settings","Info"};uint32_t count=REVO_BIOMA_ONLY?2:3;const char **items=c->machine==ILHA_DUAL?dual_items:eco_items;for(uint32_t k=0;k<count;k++){if(k==u->menu%count)d->rect(d->ctx,8,55+(int)k*30,224,24,WHITE);text(d,24,59+(int)k*30,items[k],k==u->menu%count?0:GRAY);}text(d,8,218,"Select: choose  SEL: OK",GRAY);
 }else if(c->page==ILHA_MACHINE){text(d,8,85,u->machine_choice==ILHA_DUAL?"> Atolls":"  Atolls",WHITE);text(d,8,125,u->machine_choice==ILHA_ECO?"> BIOMA":"  BIOMA",WHITE);text(d,8,185,"SEL: CONFIRM / STOP AUDIO",GRAY);
 }else{center(d,90,"IN DEVELOPMENT",WHITE);center(d,125,"HOME: BACK TO ISLAND",GRAY);}
 if(c->machine==ILHA_DUAL&&c->page==ILHA_HOME&&!(u->hud&&(uint32_t)(now-u->hud_at)<2000)){
  for(uint32_t bank=0;bank<2;bank++)if(c->notes&fragment_mask(bank)){
   uint32_t key=u->performance_key[bank];char label[32];fragment_ui_label(c,bank,key,label);int length=0;while(label[length])length++;
   text(d,bank?152:8,50,(c->latched[bank]&(1u<<key))?(bank?"B Latch":"A Latch"):(bank?"B Fragment":"A Fragment"),bank?BLUE:RED);text(d,bank?232-length*8:8,68,label,WHITE);
  }
 }
 if(c->machine==ILHA_ECO&&c->page==ILHA_HOME&&c->harmony[0]&&u->chord_name[0]&&!(u->hud&&u->hud<=4&&(uint32_t)(now-u->hud_at)<2000)){
  center(d,55,u->chord_name,WHITE);return;
 }
 if(u->hud&&c->page==ILHA_HOME&&(uint32_t)(now-u->hud_at)<2000){
  char label[24];uint32_t n=0;value_text(buf,u->hud_value,c->machine==ILHA_DUAL&&u->hud==3);
  for(;n<14&&u->message[n];n++)label[n]=u->message[n];label[n++]=' ';
  for(uint32_t i=0;buf[i]&&n<23;i++)label[n++]=buf[i];label[n]=0;
  d->rect(d->ctx,24,45,192,36,0);box(d,24,45,192,36,accent);center(d,55,label,WHITE);
 }
}

static void layer_bar_hud(const ilha_ui_t *u,const ilha_controls_t *c,uint32_t now,const ilha_draw_t *d){
 if(!u->hud||u->hud>4||(uint32_t)(now-u->hud_at)>=1600)return;
 uint32_t k=u->hud-1;int show=(c->machine==ILHA_ECO&&((c->page==ILHA_RESONANCE&&!c->resonance_page&&k<3)||(c->page==ILHA_DISTANCE&&k<3)||(c->page==ILHA_DRIFT&&k==0)||(c->page==ILHA_WEATHER&&k==0)||(c->page==ILHA_RESPONSE&&k<2)));
 if(c->machine==ILHA_DUAL&&c->page==ILHA_GLO&&k==0)show=1;
 if(c->machine==ILHA_ECO&&((c->page==ILHA_EDIT&&c->eco_activity_page&&(k==1||k==2))||(c->page==ILHA_RESONANCE&&c->resonance_page==2&&(k==1||k==2))))show=1;
 if(!show)return;char value[24],label[40];uint16_t col=c->page==ILHA_RESONANCE?YELLOW:c->page==ILHA_DISTANCE?family_colours[c->eco_family%3]:WHITE;
 if(c->machine==ILHA_DUAL){value[0]='+';number(value+1,c->dual_gain);uint32_t n=0;while(value[n])n++;copy(value+n," dB");}
 else if(c->page==ILHA_RESONANCE&&!c->resonance_page&&k==2)time_text(value,(int32_t)rr_decay_ms((uint32_t)c->resonance_balance[1],(uint32_t)c->resonance[1],(uint32_t)c->resonance[2]));
 else if(c->page==ILHA_WEATHER&&k==1){number(value,c->beam[1]);uint32_t n=0;while(value[n])n++;copy(value+n," events");}
 else if(c->page==ILHA_WEATHER&&k==2){static const char *spaces[]={"1/16","1/8","1/4","1/2","1 bar","2 bars"};copy(value,spaces[c->beam[2]]);}
 else if(c->page==ILHA_DRIFT&&k==1)copy(value,ilha_drift_period_label((uint32_t)c->drift[1]));
 else if(c->page==ILHA_DRIFT&&k==2){number(value,c->drift[2]);uint32_t n=0;while(value[n])n++;value[n++]=' ';value[n++]='s';value[n++]='t';value[n]=0;}
 else value_text(value,u->hud_value,0);
 uint32_t n=0;for(uint32_t i=0;u->message[i]&&n<22;i++)label[n++]=u->message[i];label[n++]=' ';for(uint32_t i=0;value[i]&&n<39;i++)label[n++]=value[i];label[n]=0;
 d->rect(d->ctx,40,96,160,32,0);box(d,40,96,160,32,col);center(d,104,label,WHITE);
}

void ilha_ui_render(const ilha_ui_t *u,const ilha_controls_t *c,const char *sample,uint32_t frames,const int16_t wave[120],uint32_t now,const ilha_draw_t *d){
 ilha_ui_render_page(u,c,sample,frames,wave,now,d);
 layer_bar_hud(u,c,now,d);
 if(c->machine==ILHA_DUAL&&u->transport_open)dual_transport_panel(u,c,now,d);else if(c->machine==ILHA_DUAL)formation_notice(u,now,d);
}

void ilha_ui_preset(ilha_ui_t *u,ilha_controls_t *c,int32_t step,uint32_t now){if(u->transport_open||u->play_down)return;
 if(c->machine==ILHA_ECO){if(c->page==ILHA_WIND)c->harmony_page=(c->harmony_page+step%3+3)%3;else {c->page=ILHA_WIND;c->harmony_page=0;}u->hud=0;}
 else {c->sync_panel=0;if(step){const uint8_t pages[3]={ILHA_SAMPLE,ILHA_FRAGMENT,ILHA_FRAGMENT_ENV};int at=c->page==ILHA_SAMPLE?0:c->page==ILHA_FRAGMENT?1:c->page==ILHA_FRAGMENT_ENV?2:-1;if(at<0)c->page=ILHA_SAMPLE;else c->page=pages[(at+step%3+3)%3];}u->hud=0;}
 (void)now;
}
