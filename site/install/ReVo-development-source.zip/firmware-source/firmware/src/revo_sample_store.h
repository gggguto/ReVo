/* SPDX-License-Identifier: GPL-3.0-only
 * FSMP layout and header-last storage adapted from SLOOP/Felucca
 * Copyright (C) 2026 Leo Kuroshita, Hügelton Instruments.
 * One 80 KiB slot; offsets are relative. Call only with audio held or before audio starts.
 */
#pragma once
#include <stdint.h>
#define REVO_STORE_SIZE 81920u
#define REVO_STORE_DATA 512u
#define REVO_STORE_MAX_BYTES (REVO_STORE_SIZE-REVO_STORE_DATA)
#define REVO_STORE_MAX_FRAMES (REVO_STORE_MAX_BYTES*2u)
typedef struct {int(*read)(uint32_t,void*,uint32_t);int(*erase)(uint32_t);int(*write)(uint32_t,const uint8_t*,uint32_t);} revo_store_io;
/* 1 valid load, 0 no compatible sample, -1 I/O/CRC failure. */
int revo_store_load(const revo_store_io*,uint8_t header[64],uint8_t *pcm,uint32_t capacity);
/* 0 success; header magic is committed last, readback is mandatory. */
int revo_store_save(const revo_store_io*,const uint8_t header[64],const uint8_t *pcm);
int revo_store_clear(const revo_store_io*);
