/* SPDX-License-Identifier: GPL-3.0-only. Audio-owned, bounded control recording. */
#pragma once
#define REVO_MOTION_CAP 256u
static struct {int16_t points[REVO_MOTION_CAP][4];uint32_t state,count,cursor,target,clock,seen;ilha_loop_t last;} revo_motion;
static void revo_motion_command(const ilha_controls_t *c){
 if(revo_motion.seen==c->motion_revision)return;revo_motion.seen=c->motion_revision;
 if(c->motion_command==1){
  if(revo_motion.state==1){revo_motion.state=revo_motion.count>1?2:0;revo_motion.cursor=0;revo_motion.clock=44100;}
  else{revo_motion.state=1;revo_motion.count=revo_motion.cursor=0;revo_motion.target=c->loop;revo_motion.clock=44100;}
 }else if(c->motion_command==2){revo_motion.state=revo_motion.state==2?0:revo_motion.count>1?2:0;revo_motion.cursor=0;revo_motion.clock=44100;}
 else if(c->motion_command==3){revo_motion.state=revo_motion.count=revo_motion.cursor=0;}
}
static uint32_t revo_motion_tick(const ilha_controls_t *c,uint32_t n,ilha_loop_t *out){
 if(c->machine!=ILHA_DUAL){revo_motion.state=0;revo_motion.seen=c->motion_revision;return 0;}
 revo_motion_command(c);
 if(!revo_motion.state||(revo_motion.state==2&&!c->dual_run[revo_motion.target&1u]))return 0;
 revo_motion.clock+=n*32u;if(revo_motion.clock<44100u)return 0;revo_motion.clock-=44100u;
 uint32_t target=revo_motion.target&1u;
 if(revo_motion.state==1){
  uint32_t at=revo_motion.count;const ilha_loop_t *h=&c->heads[target];
  revo_motion.points[at][0]=(int16_t)h->start;revo_motion.points[at][1]=(int16_t)h->size;revo_motion.points[at][2]=(int16_t)h->speed;revo_motion.points[at][3]=(int16_t)h->level;
  revo_motion.last=*h;
  if(++revo_motion.count==REVO_MOTION_CAP){revo_motion.state=2;revo_motion.cursor=0;revo_motion.clock=44100;}
  return 0;
 }
 const int16_t *p=revo_motion.points[revo_motion.cursor];*out=c->heads[target];out->start=p[0];out->size=p[1];out->speed=p[2];out->level=p[3];
 revo_motion.last=*out;revo_motion.cursor=(revo_motion.cursor+1)%revo_motion.count;return 1;
}
