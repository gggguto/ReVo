#include "revo_variant.h"
#if REVO_BIOMA_ONLY
#include "ilha_dual.h"
#include "ilha_dual_disabled.inc"
#else
/* SPDX-License-Identifier: GPL-3.0-only
 * Candidate bridge for SLOOP audio_block (CTL=32), not enabled in firmware.
 * One 128-frame render is consumed over four callbacks, preserving LFO cadence.
 * Edits/play/stop reach the DSP at the next internal block: <=128 frames.
 * Main/audio synchronization is the caller's responsibility on hardware.
 */
#include "ilha_dual.h"
#include "dual_loop_q15.c"
static uint32_t ilha_offset=128,ilha_beats;
uint32_t ilha_dual_beat_mask(void){return ilha_beats;}
static int32_t *ilha_block;
void ilha_dual_shape(uint32_t k,int32_t a,int32_t b,int32_t f){dl_shape(k,a,b,f);}
void ilha_dual_recover(void){dl_recover();ilha_offset=128;}
void ilha_dual_diagnostics(uint32_t out[8]){out[0]=revo_ima_fills;out[1]=revo_ima_decoded;for(uint32_t q=0;q<2;q++){out[2+q]=decoder_last[q];out[4+q]=decoder_max[q];}out[6]=out[7]=0;}
void ilha_dual_init(void){dl_init();ilha_offset=128;ilha_block=output;}
int16_t *ilha_dual_pcm(void){return dl_buffer();}
void ilha_dual_commit(uint32_t n){dl_commit(n);ilha_offset=128;}
void ilha_dual_play(uint32_t on){dl_play(on);}
void ilha_dual_wander(uint32_t k,int32_t amount,int32_t chance){dl_wander(k,amount,chance);}
void ilha_dual_landing(uint32_t k,uint32_t mode,uint32_t mask,const uint16_t *p){dl_landing(k,mode,mask,p);}
void ilha_dual_vformation(uint32_t k,uint32_t link,uint32_t every,uint32_t action,uint32_t chance){dl_vformation(k,link,every,action,chance);}
void ilha_dual_vformation_motion(uint32_t k,uint32_t on){dl_vformation_motion(k,on);}
void ilha_dual_vformation_visual(uint32_t k,uint32_t *turns,uint32_t *events,uint32_t *status){if(k>1)return;*turns=formation[k].turns;*events=formation[k].events;*status=formation[k].status;}
void ilha_dual_flock(uint32_t k,uint32_t repeats){dl_wander_repeats(k,repeats);}
void ilha_dual_flock_mode(uint32_t k,uint32_t mode,uint32_t range){dl_flock_mode(k,mode,range);}
void ilha_dual_flock_pitch(uint32_t k,int32_t *pitch,int32_t *previous){if(k>1)return;*pitch=wander[k].pitch;*previous=wander[k].previous_pitch;}
void ilha_dual_flock_visual(uint32_t k,uint32_t *turns,uint32_t *previous){if(k>1)return;*turns=wander[k].turns;uint32_t n=head_count(k);*previous=n?(uint32_t)((uint64_t)wander[k].previous*65536u/n):0;}
void ilha_dual_fragment(uint32_t notes,uint32_t loop,uint32_t bpm){dl_fragment(notes,loop,bpm);}
void ilha_dual_head(uint32_t k,int32_t a,int32_t n,int32_t speed,int32_t gain,int32_t pan){dl_head(k,a,n,speed,gain,pan);}
void ilha_dual_lfo(uint32_t k,int32_t shape,int32_t rate,int32_t amount,int32_t mask,int32_t dest){dl_lfo(k,shape,rate,amount,mask,dest);}
void ilha_dual_fx_route(uint32_t route){dl_fx_route(route);}
uint32_t ilha_dual_render_fx(int32_t *out,int32_t *bypass,uint32_t n){
 if(!out||!n||n>32)return 0;ilha_beats=0;
 for(uint32_t i=0;i<n;i++){
  if(ilha_offset==128){ilha_block=dl_render();ilha_offset=0;}
  if(dl_beat_mask[ilha_offset>>5]&(1u<<(ilha_offset&31u)))ilha_beats|=1u<<i;
  for(uint32_t c=0;c<2;c++){uint32_t at=2*ilha_offset+c;out[2*i+c]=ilha_block[at];if(bypass){bypass[2*i+c]=fx_bypass[at];out[2*i+c]-=fx_bypass[at];}}ilha_offset++;
 }
 return 1;
}

uint32_t ilha_dual_render(int32_t *out,uint32_t n){return ilha_dual_render_fx(out,0,n);}
uint32_t ilha_dual_phase(uint32_t k){return k<2?lfo[k].phase:0;}
uint32_t ilha_dual_seed(uint32_t k){return k<2?lfo[k].seed:1;}
int32_t ilha_dual_held(uint32_t k){return k<2?(lfo[k].shape==5?lfo[k].drift_from:lfo[k].held):0;}
uint32_t ilha_dual_position(uint32_t k){return dl_position(k);}

int ilha_dual_commit_ima(uint32_t n){int ok=dl_commit_ima(n);ilha_offset=128;return ok;}
int16_t ilha_dual_sample_at(uint32_t n){return dl_sample_at(n);}

int ilha_dual_second_source(const uint8_t*p,uint32_t bytes,uint32_t frames){int ok=dl_second_source(p,bytes,frames);ilha_offset=128;return ok;}

int16_t ilha_dual_head_sample_at(uint32_t k,uint32_t n){return dl_head_sample_at(k,n);}

uint32_t ilha_dual_window(uint32_t k){uint32_t n=k<2?head_count(k):0;return n?(uint32_t)((uint64_t)head[k].read_start*65536u/n):0;}

/* Audio must be held. Unchanged slot identities retain their transport/gesture state. */
int ilha_dual_replace_sources(uint32_t frames,const uint8_t *b,uint32_t bytes,uint32_t bframes,uint32_t keep){
 head_t saved[2]={head[0],head[1]};fragment_t gestures[2]={fragments[0],fragments[1]};revo_frag_env_t envs[2]={fragment_env[0],fragment_env[1]};
 dl_transport_t saved_transport[2]={transport[0],transport[1]};int32_t was_playing=playing,was_envelope=envelope;wander_t saved_wander[2]={wander[0],wander[1]};landing_t saved_landing[2]={landing[0],landing[1]};uint32_t reverse[2]={formation[0].reverse,formation[1].reverse};
 if(!dl_commit_ima(frames)||!dl_second_source(b,bytes,bframes))return 0;
 for(uint32_t k=0;k<2;k++)if(keep&(1u<<k)){head[k]=saved[k];fragments[k]=gestures[k];fragment_env[k]=envs[k];wander[k]=saved_wander[k];landing[k]=saved_landing[k];formation[k].reverse=reverse[k];}
 for(uint32_t k=0;k<2;k++){transport[k]=saved_transport[k];if(!(keep&(1u<<k))){transport[k].done=0;transport[k].restart=128;transport[k].previous=0;}}
 playing=was_playing;envelope=was_envelope;ilha_offset=128;return 1;
}

void ilha_dual_fragment_env(uint32_t k,uint32_t a,uint32_t r){dl_fragment_env(k,a,r);}
void ilha_dual_fragment_clear(void){dl_fragment_clear();}
void ilha_dual_env_visual(uint32_t k,uint32_t *gain,uint32_t *stage,uint32_t *progress){
 if(k>1)return;const revo_frag_env_t *e=&fragment_env[k];*gain=e->gain>>9;*stage=e->stage;*progress=e->total?((e->total-e->left)*1024u/e->total)*64u:0;
}

void ilha_dual_play_head(uint32_t k,uint32_t on){dl_play_head(k,on);}
void ilha_dual_sync(uint32_t k,uint32_t s,uint32_t d,uint32_t b,uint32_t l){dl_sync(k,s,d,b,l);}
void ilha_dual_clock(uint32_t ext,uint32_t bpm){dl_clock(ext,bpm);}
void ilha_dual_clock_reset(void){dl_clock_reset();}
void ilha_dual_clock_pulse(void){dl_clock_pulse();}
uint32_t ilha_dual_transport_state(uint32_t k){return dl_transport_state(k);}

#endif
