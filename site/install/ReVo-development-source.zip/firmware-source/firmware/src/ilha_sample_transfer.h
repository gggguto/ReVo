/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
/* Single-core main/audio-IRQ API. No USB handler or persistent storage yet.
 * MAIN: pause -> poll paused -> begin/write/finish or abort -> resume.
 * pause() is nonblocking; never spin on main waiting for an IRQ-disabled ACK.
 * paused() reports actual audio-owned quiescence, not STOP/UI state.
 * Do not resume during loading; no thread may write PCM after releasing hold.
 * Invalid header preserves old data; accepted payload reuses PCM (no rollback).
 * Poll/cancel disconnected transfers in the future transport layer. */
int ilha_audio_sample_pause(void);
int ilha_audio_sample_paused(void);
int ilha_audio_sample_resume(void);
int ilha_audio_sample_begin(const uint8_t *header,uint32_t size,uint32_t quiet);
int ilha_audio_sample_write(uint32_t offset,const uint8_t *data,uint32_t n);
int ilha_audio_sample_finish(void);
void ilha_audio_sample_abort(void);
