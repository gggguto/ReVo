/* SPDX-License-Identifier: GPL-3.0-only
 * Portable experimental DSP. No HAL, heap, storage, MIDI or update code.
 * One mono PCM source, two independent Q16 playheads; 44.1 kHz stereo.
 * Browser prototype: PCM storage is not yet budgeted/integrated on FM-1.
 */
#include <stdint.h>
#include "revo_ima.c"
#include "revo_fragment.h"
#include "revo_sync.h"
#include "revo_fragment_env.h"
#include "revo_motion.h"
#define DL_CAP 65536u
#define DL_BLOCK 128u
#define DL_FADE 882 /* 20 ms transport ramp */
#if defined(ILHA_FM1_TARGET)
#define ILHA_PCM_SECTION __attribute__((section(".pool")))
#else
#define ILHA_PCM_SECTION
#endif
static int16_t sample[DL_CAP] ILHA_PCM_SECTION;
static uint32_t dl_beat_frame,dl_beat_mask[4];
static uint32_t count, compressed,decoder_last[2],decoder_max[2];
static revo_ima_state ima_states[REVO_IMA_CHECKPOINTS];
static revo_ima_source ima_source;
static revo_ima_cache ima_cache[8];
static revo_ima_source extra_source;
static revo_ima_state extra_states[REVO_IMA_CHECKPOINTS];
static const revo_ima_source *head_source[2];
static uint32_t head_count(uint32_t k){return head_source[k]?head_source[k]->frames:count;}
/* Caller holds audio and keeps data immutable for the entire playback lifetime.
 * Intended backend is validated XIP flash, not a second PCM allocation. */
int dl_second_source(const uint8_t *data,uint32_t bytes,uint32_t frames){
 if(!data){head_source[1]=0;ima_cache[2].valid=ima_cache[3].valid=ima_cache[6].valid=ima_cache[7].valid=0;return 1;}
 if(!revo_ima_index(&extra_source,data,bytes,frames,extra_states,REVO_IMA_CHECKPOINTS))return 0;
 head_source[1]=&extra_source;ima_cache[2].valid=ima_cache[3].valid=ima_cache[6].valid=ima_cache[7].valid=0;return 1;
}
static int32_t output[DL_BLOCK * 2],fx_bypass[DL_BLOCK * 2];
static uint32_t fx_route_mask=3;
static int32_t fx_bypass_gain[2];
static int64_t fx_bypass_x[2],fx_bypass_y[2];
void dl_fx_route(uint32_t route){fx_route_mask=route==0?1:route==1?2:3;}
typedef struct {
    uint64_t phase;
    uint32_t start, length, overlap, period, read_start,base_length,base_overlap,base_period;
    int32_t speed, gain, pan;
    int64_t smooth;
} head_t;
static int32_t clamp(int32_t,int32_t,int32_t);
static head_t head[2];
typedef struct {int32_t amount,chance,offset;uint32_t seed,changes,repeats,turns,previous,mode,range;int32_t pitch,previous_pitch;} wander_t;
static wander_t wander[2];
typedef struct {uint32_t link,every,action,chance,turns,seed,events,status,reverse,skip,manual,motion;} vformation_t;
static vformation_t formation[2];static uint32_t cycle_pending;
static uint32_t dl_complete(uint32_t k,uint32_t clock);

typedef struct {uint32_t mode,mask;uint16_t point[8];int32_t current;} landing_t;
static landing_t landing[2];
void dl_landing(uint32_t k,uint32_t mode,uint32_t mask,const uint16_t *points){
 if(k>1)return;landing_t *l=&landing[k];mode=mode>2?2:mode;mask&=255u;
 if(mode!=l->mode)l->current=-1;l->mode=mode;l->mask=mask;
 for(uint32_t i=0;i<8;i++)l->point[i]=points?points[i]:0;
}
static void flock_destination(uint32_t k){head_t *h=&head[k];int64_t limit=(int64_t)head_count(k)-h->length;if(limit<0)limit=0;int64_t at=(int64_t)h->start+wander[k].offset;h->read_start=(uint32_t)(at<0?0:at>limit?limit:at);}

/* Semitone ratios -24..+24, Q16. Constant tables avoid audio-rate pow/division. */
static const uint32_t flock_ratios[49]={16384,17358,18390,19484,20643,21870,23170,24548,26008,27554,29193,30929,32768,34716,36781,38968,41285,43740,46341,49097,52016,55109,58386,61858,65536,69433,73562,77936,82570,87480,92682,98193,104032,110218,116772,123715,131072,138866,147123,155872,165140,174960,185364,196386,208064,220436,233544,247431,262144};
static uint32_t flock_ratio(uint32_t k){return flock_ratios[24+wander[k].pitch];}
static void flock_geometry(uint32_t k){
 head_t *h=&head[k];uint32_t ratio=flock_ratio(k);
 h->period=(uint32_t)(((uint64_t)h->base_period*ratio+32768u)>>16);if(h->base_period&&!h->period)h->period=1;
 h->overlap=(uint32_t)(((uint64_t)h->base_overlap*ratio+32768u)>>16);h->length=h->period+h->overlap;
}
void dl_flock_mode(uint32_t k,uint32_t mode,uint32_t range){
 if(k>1)return;mode=!!mode;if(range>12)range=12;
 if(wander[k].mode!=mode||(mode&&!range&&wander[k].pitch)){
  wander[k].mode=mode;wander[k].pitch=wander[k].previous_pitch=0;wander[k].offset=0;wander[k].turns=0;wander[k].previous=head[k].start;flock_geometry(k);head[k].phase=0;
 }
 wander[k].range=range;
}

void dl_wander_repeats(uint32_t k,uint32_t n){if(k>1)return;if(n<1)n=1;if(n>32)n=32;/* Keep playback phase and completed turns; evaluate the new limit only at a wrap. */wander[k].repeats=n;}
void dl_wander(uint32_t k,int32_t amount,int32_t chance){if(k>1)return;wander[k].amount=clamp(amount,0,100);wander[k].chance=clamp(chance,0,100);if(!amount&&!landing[k].mode)wander[k].offset=0;}
static void wander_turn(uint32_t k){
 if(formation[k].link)return;
 if(!landing[k].mode&&!(wander[k].mode?wander[k].range:(uint32_t)wander[k].amount))return;
 if(++wander[k].turns<(wander[k].repeats?wander[k].repeats:1))return;wander[k].turns=0;
 if(!wander[k].chance)return;
 uint32_t x=wander[k].seed? wander[k].seed:0x1a53u+k*1009u;x^=x<<13;x^=x>>17;x^=x<<5;wander[k].seed=x;
 if(x%100u>=(uint32_t)wander[k].chance)return;
 x^=x<<13;x^=x>>17;x^=x<<5;wander[k].seed=x;
 if(landing[k].mode){
  landing_t *l=&landing[k];uint32_t mask=l->mask;if(!mask)return;
  uint32_t selected=0;
  if(l->mode==2){for(uint32_t i=1;i<=8;i++){uint32_t p=(uint32_t)(l->current+(int32_t)i)&7u;if(mask&(1u<<p)){selected=p;break;}}}
  else {uint32_t choices=mask;if(l->current>=0&&(choices&~(1u<<l->current)))choices&=~(1u<<l->current);uint32_t count=0;for(uint32_t i=0;i<8;i++)if(choices&(1u<<i))count++;uint32_t pick=x%count;for(uint32_t i=0;i<8;i++)if(choices&(1u<<i)){if(!pick--){selected=i;break;}}}
  l->current=(int32_t)selected;wander[k].previous=head[k].read_start;
  uint32_t at=(uint32_t)((uint64_t)l->point[selected]*head_count(k)/65536u);
  wander[k].offset=(int32_t)at-(int32_t)head[k].start;flock_destination(k);wander[k].changes++;return;
 }
 if(wander[k].mode){
  int32_t range=(int32_t)wander[k].range,target=(int32_t)(x%(uint32_t)(2*range+1))-range;
  if(target==wander[k].pitch)target=target<range?target+1:-range;
  wander[k].previous_pitch=wander[k].pitch;wander[k].pitch=target;wander[k].offset=0;flock_geometry(k);wander[k].changes++;return;
 }
 int32_t limit=(int32_t)head_count(k)-(int32_t)head[k].length;if(limit<0)limit=0;
 wander[k].previous=(uint32_t)head[k].read_start;
 wander[k].offset=(int32_t)((int64_t)((int32_t)(x&65535u)-32768)*limit*wander[k].amount/(32768LL*100));flock_destination(k);wander[k].changes++;
}

typedef struct {uint32_t notes,key,action,on,period,elapsed,reverse;uint64_t phase,anchor;} fragment_t;
static fragment_t fragments[2];
static revo_frag_env_t fragment_env[2];
static int32_t fragment_running;
static int32_t playing,envelope;
#include "revo_loop_shape.inc"
#include "revo_dual_transport.inc"
/* Clock-synced heads publish opportunities only from clock divisions.
 * This shared event feeds Flock and the other loop's V Format. */
static uint32_t dl_complete(uint32_t k,uint32_t clock){if(k>1||(!!clock!=!!transport[k].sync))return 0;if(!clock&&formation[k].skip){formation[k].skip=0;return 0;}cycle_pending|=1u<<k;return 1;}
#include "revo_vformation.inc"
void dl_fragment_env(uint32_t k,uint32_t attack,uint32_t release){
 if(k>1)return;revo_frag_env_t *e=&fragment_env[k];if(attack>2000)attack=2000;if(release>5000)release=5000;
 uint32_t changed=(e->stage==1&&e->attack!=attack)||(e->stage==3&&e->release!=release);
 e->attack=attack;e->release=release;if(changed)frag_env_begin(e,e->stage);
}
void dl_fragment_clear(void){for(uint32_t k=0;k<2;k++){fragments[k].on=fragments[k].notes=0;fragment_env[k].gain=fragment_env[k].stage=fragment_env[k].left=0;}}

void dl_fragment(uint32_t notes,uint32_t selected,uint32_t bpm){
 (void)selected;
 for(uint32_t k=0;k<2;k++){
  fragment_t *f=&fragments[k];revo_frag_env_t *e=&fragment_env[k];uint32_t held=notes&fragment_mask(k),reverse=held&(1u<<(k?15:1)),others=held&~(1u<<(k?15:1));
  f->reverse=!!reverse;
  if(others)held=others;else if(reverse&&!transport[k].on)held=0;
  uint32_t pressed=held&~f->notes,key=f->key;
  if(!held){if(f->notes&&f->on)frag_env_begin(e,3);f->notes=0;f->period=fragment_frames(f->action,bpm);continue;}
  if(pressed){for(uint32_t i=0;i<27;i++)if(pressed&(1u<<i))key=i;}
  else if(!(held&(1u<<key))){for(uint32_t i=0;i<27;i++)if(held&(1u<<i))key=i;}
  if(!f->on||key!=f->key){f->key=key;f->action=fragment_action(key);f->phase=f->anchor=head[k].phase;f->elapsed=0;}
  if(!f->notes)frag_env_begin(e,1);
  f->notes=held;f->on=1;f->period=fragment_frames(f->action,bpm);
 }
}
static uint64_t fragment_wrap(int64_t p,uint32_t period){
 int64_t wrap=(int64_t)period<<16;if(!wrap)return 0;
 while(p<0)p+=wrap;while(p>=wrap)p-=wrap;return (uint64_t)p;
}

static int64_t dc_y[2], dc_x[2];
static int64_t shift0(int64_t v,uint32_t n) { return (v+(v<0?((INT64_C(1)<<n)-1):0))>>n; }
static int32_t clamp(int32_t n, int32_t lo, int32_t hi) { return n < lo ? lo : n > hi ? hi : n; }
/* Two control-rate LFOs. Phase continues across edits and pauses at Stop.
 * Shape 0 sine, 1 triangle, 2 sample/hold; mask 1=A, 2=B, 3=both.
 * Dest 0=speed, 1=level, 2=pan, 3=start (block-rate window shift).
 * Signed depth in Q15; control targets ramp over each 128-frame block.
 */
typedef struct { uint32_t phase, step, seed; int32_t shape, amount, mask, dest, held, value, drift_from; } lfo_t;
static lfo_t lfo[2];
static int64_t mod_offset[2][4];
static int32_t effective[2][4];
static const int16_t lfo_sine[65]={0,3212,6393,9512,12539,15446,18204,20787,23170,25329,27245,28898,30273,31356,32137,32609,32767,32609,32137,31356,30273,28898,27245,25329,23170,20787,18204,15446,12539,9512,6393,3212,0,-3212,-6393,-9512,-12539,-15446,-18204,-20787,-23170,-25329,-27245,-28898,-30273,-31356,-32137,-32609,-32767,-32609,-32137,-31356,-30273,-28898,-27245,-25329,-23170,-20787,-18204,-15446,-12539,-9512,-6393,-3212,0};
static uint32_t lfo_rand(uint32_t x) { x^=x<<13; x^=x>>17; x^=x<<5; return x; }
static int32_t lfo_wave(lfo_t *f) {
    if (f->shape==5)return revo_drift(f->phase,f->drift_from,f->held);
    if (f->shape==2) return f->held;
    if (f->shape==3)return (int32_t)(f->phase>>16)-32768;
    if (f->shape==4)return 32767-(int32_t)(f->phase>>16);
    if (f->shape==1) {
        int32_t x=(int32_t)(f->phase>>16);
        return x<16384 ? x*2 : x<49152 ? 65536-x*2 : x*2-131072;
    }
    uint32_t i=f->phase>>26, frac=(f->phase>>10)&65535;
    int32_t a=lfo_sine[i], b=lfo_sine[i+1];
    return a+shift0((int64_t)(b-a)*frac,16);
}
void dl_lfo(uint32_t k,int32_t shape,int32_t rate_mhz,int32_t amount,int32_t mask,int32_t dest) {
    if (k>1) return;
    lfo_t *f=&lfo[k];if(shape==5&&f->shape!=5){f->drift_from=f->value;f->seed=lfo_rand(f->seed);f->held=(int32_t)(f->seed>>16)-32768;f->phase=0;} f->shape=clamp(shape,0,5); f->amount=clamp(amount,-32768,32768);
    f->mask=clamp(mask,0,3); f->dest=clamp(dest,0,3);
    f->step=(uint64_t)clamp(rate_mhz,20,10000)*4294967296ULL/44100000ULL;
}
int32_t dl_lfo_value(uint32_t k) { return k<2?lfo[k].value:0; }
int32_t dl_effective(uint32_t k,uint32_t dest) { return k<2&&dest<4?effective[k][dest]:0; }
static void lfo_targets(int64_t target[2][4],int64_t delta[2][4]) {
    for(uint32_t n=0;n<2;n++) {
        lfo_t *f=&lfo[n];
        if (f->mask&&(playing||fragments[0].on||fragments[1].on)) {
            uint32_t old=f->phase; f->phase+=f->step*DL_BLOCK;
            if(f->phase<old) { f->drift_from=f->held;f->seed=lfo_rand(f->seed);f->held=(int32_t)(f->seed>>16)-32768; }
        }
        f->value=lfo_wave(f);
        int32_t v=shift0((int64_t)f->value*f->amount,15);
        if(f->dest==0)v*=2;
        for(uint32_t k=0;k<2;k++)if(f->mask&(1<<k))target[k][f->dest]+=(int64_t)v*65536;
    }
    for(uint32_t k=0;k<2;k++)for(uint32_t d=0;d<3;d++)delta[k][d]=shift0(target[k][d]-mod_offset[k][d],7);
}
int16_t *dl_buffer(void) { return sample; }
uint32_t dl_capacity(void) { return DL_CAP; }
uint32_t dl_frames(void) { return DL_BLOCK; }
uint32_t dl_rate(void) { return 44100; }
void dl_recover(void){
 dl_fragment_clear();for(uint32_t k=0;k<2;k++){dl_play_head(k,0);transport[k].ramp=transport[k].restart=transport[k].done=0;head[k]=(head_t){.start=UINT32_MAX};formation[k].reverse=formation[k].turns=formation[k].manual=0;wander[k].offset=0;for(uint32_t j=0;j<4;j++)mod_offset[k][j]=effective[k][j]=0;loop_shape[k].low[0]=loop_shape[k].low[1]=0;loop_shape[k].mix=0;loop_shape[k].period=UINT32_MAX;}
 for(uint32_t c=0;c<8;c++)ima_cache[c].valid=0;for(uint32_t c=0;c<2;c++)dc_x[c]=dc_y[c]=fx_bypass_x[c]=fx_bypass_y[c]=0;cycle_pending=0;dl_clock_reset();
}
void dl_init(void) {
 revo_ima_fills=revo_ima_decoded=0;for(uint32_t i=0;i<2;i++)decoder_last[i]=decoder_max[i]=0;
 for(uint32_t k=0;k<2;k++)loop_shape[k]=(dl_shape_t){0};
 fx_route_mask=3;for(uint32_t c=0;c<2;c++){fx_bypass_gain[c]=0;fx_bypass_x[c]=fx_bypass_y[c]=0;}
    for(uint32_t k=0;k<2;k++)formation[k]=(vformation_t){.every=4,.chance=100,.seed=0x71f0123u+k*113u};cycle_pending=0;for(uint32_t k=0;k<2;k++)landing[k]=(landing_t){.current=-1};count = playing = envelope = compressed = fragment_running = 0;grid_external=0;grid_bpm=100;dl_clock_reset();for(uint32_t k=0;k<2;k++)transport[k]=(dl_transport_t){.division=2};for(uint32_t k=0;k<2;k++)fragment_env[k]=(revo_frag_env_t){0};for(uint32_t k=0;k<2;k++){wander[k].amount=0;wander[k].chance=50;wander[k].offset=0;wander[k].changes=0;wander[k].repeats=1;wander[k].turns=0;wander[k].previous=0;wander[k].mode=0;wander[k].range=3;wander[k].pitch=wander[k].previous_pitch=0;wander[k].seed=0x1a53u+k*1009u;}fragments[0].on=fragments[0].notes=fragments[1].on=fragments[1].notes=0;head_source[0]=head_source[1]=0;
    dc_y[0]=dc_y[1]=dc_x[0]=dc_x[1]=0;fx_bypass_x[0]=fx_bypass_x[1]=fx_bypass_y[0]=fx_bypass_y[1]=0;
    for (uint32_t i=0;i<2;i++) {
        head[i]=(head_t){.speed=65536,.gain=32768,.pan=i?16384:-16384};
        lfo[i]=(lfo_t){.seed=0x12345678u+i,.held=i?16384:-16384};
        for(uint32_t d=0;d<3;d++)mod_offset[i][d]=effective[i][d]=0;
        dl_lfo(i,0,500,0,0,0);
    }
}
/* Rebuild geometry only on position/size edits. Rate/level/pan preserve phase. */
void dl_head(uint32_t k, int32_t start, int32_t span, int32_t speed, int32_t gain, int32_t pan) {
    if (k>1) return;
    head_t *h=&head[k];
    uint32_t count=head_count(k);
    uint32_t a=count ? (uint64_t)clamp(start,0,65535)*(count-1)/65536 : 0;
    uint32_t n=count ? (uint64_t)clamp(span,1,65536)*count/65536 : 0;
    if (n<4) n=4;
    if (n>count-a) n=count-a;
    uint32_t x=n/4; if (x>256) x=256;
    uint32_t period=n-x;
    if(a!=h->start||n!=h->base_length||speed!=h->speed){formation[k].manual=DL_BLOCK;if(a!=h->start||n!=h->base_length)formation[k].skip=0;else if((speed<0)!=(h->speed<0))formation[k].skip=1;if(speed!=h->speed)formation[k].reverse=0;}
    if (a!=h->start || n!=h->base_length) {
        h->phase=0;wander[k].turns=0;wander[k].offset=0;if(fragments[k].on){fragments[k].phase=fragments[k].anchor=0;fragments[k].elapsed=0;}
        h->start=a; h->read_start=a; h->base_length=n; h->base_overlap=x; h->base_period=period;wander[k].pitch=0;flock_geometry(k);
    }
    h->speed=clamp(speed,-131072,131072); /* -2x .. freeze .. +2x */
    h->gain=clamp(gain,0,32768); h->pan=clamp(pan,-32768,32768);
}
/* The adapter must stop rendering before replacing the shared PCM buffer. */
void dl_commit(uint32_t n) {
    head_source[0]=head_source[1]=0;dl_fragment_clear();
    for(uint32_t k=0;k<2;k++){wander[k].offset=0;landing[k]=(landing_t){.current=-1};formation[k].turns=formation[k].reverse=formation[k].skip=0;}cycle_pending=0;
    compressed=0;
    count=n>DL_CAP?DL_CAP:n;
    playing=envelope=0;for(uint32_t k=0;k<2;k++){transport[k].on=transport[k].requested=transport[k].wait=transport[k].ramp=transport[k].done=transport[k].clock_seen=0;}
    dc_y[0]=dc_y[1]=dc_x[0]=dc_x[1]=0;fx_bypass_x[0]=fx_bypass_x[1]=fx_bypass_y[0]=fx_bypass_y[1]=0;
    for (uint32_t k=0;k<2;k++) {
        head[k].length=head[k].base_length=0; head[k].smooth=0;
        dl_head(k,k?16384:0,49152,k?49152:65536,32768,k?16384:-16384);
    }
}
int dl_commit_ima(uint32_t n) {
    dl_commit(0);
    if(!revo_ima_index(&ima_source,(const uint8_t *)sample,(n+1)/2,n,ima_states,REVO_IMA_CHECKPOINTS))return 0;
    for(uint32_t k=0;k<8;k++)ima_cache[k].valid=0;
    compressed=1;count=n;
    for(uint32_t k=0;k<2;k++)dl_head(k,k?16384:0,49152,65536,32768,k?16384:-16384);
    return 1;
}
int16_t dl_sample_at(uint32_t n) {
    if(n>=count)return 0;
    return compressed?revo_ima_at(&ima_source,&ima_cache[0],n):sample[n];
}
void dl_play(uint32_t on) {dl_play_head(0,on);dl_play_head(1,on);playing=!!on;fragment_running=playing;}
uint32_t dl_position(uint32_t k) {
    if(k>1)return 0;
    uint32_t count=head_count(k);if(!count)return 0;
    uint32_t at=head[k].read_start+(uint32_t)((fragments[k].on?fragments[k].phase:head[k].phase)>>16);if(wander[k].mode)while(at>=count)at-=count;
    return (uint32_t)((uint64_t)at*65536u/count);
}
static int32_t read_at(head_t *h, uint64_t p,uint32_t cache_bank) {
    uint32_t k=(uint32_t)(h-head);
    const revo_ima_source *source=head_source[k]?head_source[k]:&ima_source;
    uint32_t encoded=head_source[k]!=0||compressed;
    uint32_t i=(uint32_t)(p>>16), f=p&65535;
    uint32_t j=i+1<h->length?i+1:i;
    uint32_t slot=cache_bank+(uint32_t)(h-head)*2+(p>=((uint64_t)h->period<<16));
    uint32_t ia=h->read_start+i,ib=h->read_start+j;
    if(wander[k].mode){uint32_t n=head_count(k);if(!n)return 0;while(ia>=n)ia-=n;while(ib>=n)ib-=n;}
    int32_t a,b;
    if(encoded)revo_ima_pair(source,&ima_cache[slot],ia,ib,&a,&b);
    else {a=sample[ia];b=sample[ib];}
    return a+shift0((int64_t)(b-a)*f,16);
}
int32_t *dl_render(void) {
 for(uint32_t k=0;k<4;k++)dl_beat_mask[k]=0;
 uint32_t fills_before=revo_ima_fills,decoded_before=revo_ima_decoded;
    int64_t target_mod[2][4]={{0}}, delta_mod[2][4];
    lfo_targets(target_mod,delta_mod);
    /* START moves the window once per control block, preserving size and phase.
     * Decoder seeks remain bounded; discontinuities are an intentional texture. */
    for(uint32_t k=0;k<2;k++){
        uint32_t count=head_count(k);if(!count){head[k].read_start=0;effective[k][3]=0;continue;}
        int64_t limit=count>=head[k].length?count-head[k].length:0;
        if(wander[k].mode){int64_t span=count>=head[k].base_length?count-head[k].base_length:0;int64_t at=(int64_t)head[k].start+(target_mod[k][3]/65536)*span/32768;head[k].read_start=(uint32_t)(at<0?0:at>=(int64_t)count?count-1:at);effective[k][3]=(int32_t)head[k].read_start;continue;}
        int64_t offset=(target_mod[k][3]/65536)*limit/32768;
        int64_t at=(int64_t)head[k].start+offset+wander[k].offset;
        head[k].read_start=(uint32_t)(at<0?0:at>limit?limit:at);
        effective[k][3]=(int32_t)head[k].read_start;
    }

    for(uint32_t k=0;k<2;k++)shape_geometry(k);
    for (uint32_t i=0;i<DL_BLOCK;i++) {
        int64_t l=0,r=0,bypass_l=0,bypass_r=0;
        for(uint32_t k=0;k<2;k++){int32_t target=(fx_route_mask&(1u<<k))?0:32768;fx_bypass_gain[k]+=clamp(target-fx_bypass_gain[k],-128,128);}
        dl_beat_frame=i;cycle_pending=0;dl_transport_frame();
        for (uint32_t k=0;k<2;k++) {
            head_t *h=&head[k];
            for(uint32_t d=0;d<3;d++)mod_offset[k][d]+=delta_mod[k][d];
            effective[k][0]=clamp(h->speed+(int32_t)shift0(mod_offset[k][0],16),-131072,131072);
            if(wander[k].mode)effective[k][0]=(int32_t)shift0((int64_t)effective[k][0]*flock_ratio(k),16);
            if(formation[k].reverse)effective[k][0]=-effective[k][0];
            effective[k][1]=clamp(h->gain+(int32_t)shift0(mod_offset[k][1],16),0,32768);
            effective[k][2]=clamp(h->pan+(int32_t)shift0(mod_offset[k][2],16),-32768,32768);
            if (head_count(k)<4 || !h->period) continue;
            fragment_t *f=&fragments[k];revo_frag_env_t *e=&fragment_env[k];
            uint32_t weight=f->on?frag_env_tick(e):0;
            if(f->on&&!e->stage&&!f->notes)f->on=0;
            uint32_t frag=f->on;dl_transport_t *t=&transport[k];uint32_t gate=t->sync&&t->between;
            uint64_t read_phase=frag?fragment_wrap((int64_t)f->phase,h->period):h->phase;
            int32_t s=read_at(h,read_phase,0);
            uint64_t cross=gate?0:(uint64_t)h->overlap<<16;
            if (cross && read_phase<cross) {
                int32_t tail=read_at(h,read_phase+((uint64_t)h->period<<16),0);
                s=tail+(int32_t)shift0((int64_t)(s-tail)*(int64_t)read_phase,16)/(int32_t)h->overlap;
            }
            if(frag&&(f->action<8||f->action>=11)){
                uint32_t edge=f->elapsed<64?f->elapsed:f->period-f->elapsed<64?f->period-f->elapsed:64;
                s=(int32_t)((int64_t)s*edge/64);
            }
            int32_t normal=s;
            if(frag&&weight<32768u){
                normal=read_at(h,h->phase,4);
                if(cross&&h->phase<cross){int32_t tail=read_at(h,h->phase+((uint64_t)h->period<<16),4);normal=tail+(int32_t)shift0((int64_t)(normal-tail)*(int64_t)h->phase,16)/(int32_t)h->overlap;}
            }
            int32_t direction=effective[k][0];if(frag&&f->reverse)direction=-direction;
            s=shape_edges(k,s,read_phase,direction);
            normal=shape_edges(k,normal,h->phase,effective[k][0]);
            normal=(int32_t)((int64_t)normal*t->ramp/DL_FADE);
            s=frag?(int32_t)(((int64_t)normal*(32768-weight)+(int64_t)s*weight)/32768):normal;
            s=shape_filter(k,s);
            int64_t target=shift0((int64_t)s*effective[k][1],15);
            if(t->restart&&!frag){target=((int64_t)t->previous*t->restart+target*(128-t->restart))/128;t->restart--;}
            h->smooth+=shift0(target*65536-h->smooth,7); /* ~3 ms smoothing for edits */
            int32_t v=shift0(h->smooth,16);
            int64_t vl=shift0((int64_t)v*(32768-effective[k][2]),16),vr=shift0((int64_t)v*(32768+effective[k][2]),16);
            l+=vl;r+=vr;
            bypass_l+=shift0(vl*fx_bypass_gain[k],15);bypass_r+=shift0(vr*fx_bypass_gain[k],15);
            if (t->on&&!t->done) {
                int64_t p=(int64_t)h->phase+((compressed||head_source[k])?effective[k][0]/2:effective[k][0]);
                int64_t wrap=(int64_t)(gate?h->length:h->period)<<16;
                if(gate&&(p<0||p>=wrap)){if(!frag&&!t->sync){if(dl_complete(k,0))wander_turn(k);}t->done=1;p=p<0?0:wrap-1;}
                while(p<0||p>=wrap){
                    uint32_t reverse=p<0,before=wander[k].changes;int32_t old_pitch=wander[k].pitch;
                    if(!reverse)p-=wrap;
                    if(!frag&&!t->sync){if(dl_complete(k,0))wander_turn(k);}
                    if(wander[k].changes!=before){
                        if(wander[k].mode){p=shift0(p*flock_ratios[24+wander[k].pitch-old_pitch],16);wrap=(int64_t)h->period<<16;}
                        else{int64_t limit=(int64_t)head_count(k)-h->length;int64_t at=(int64_t)h->start+wander[k].offset+(target_mod[k][3]/65536)*limit/32768;h->read_start=(uint32_t)(at<0?0:at>limit?limit:at);effective[k][3]=(int32_t)h->read_start;}
                    }
                    if(reverse)p+=wrap;
                }
                h->phase=(uint64_t)p;
            }
                if(frag){
                    int32_t speed=effective[k][0];
                    if(f->action==9)speed/=2;else if(f->action==10)speed=clamp(speed*2,-524288,524288);
                    if(f->reverse)speed=-speed;
                    int32_t increment=(compressed||head_source[k])?speed/2:speed;
                    f->phase=fragment_wrap((int64_t)f->phase+increment,h->period);
                    if((f->action<8||f->action>=11)&&++f->elapsed>=f->period){f->elapsed=0;f->phase=fragment_wrap((int64_t)f->anchor,h->period);}
                }
        }
        formation_frame();
        /* ~20 Hz DC blocker: freeze must not send a held PCM offset to the output. */
        int64_t mix[2]={l*65536,r*65536},bypass[2]={bypass_l*65536,bypass_r*65536};
        for (uint32_t c=0;c<2;c++) {
            dc_y[c]=mix[c]-dc_x[c]+shift0(dc_y[c]*65350,16);
            dc_x[c]=mix[c];
            fx_bypass_y[c]=bypass[c]-fx_bypass_x[c]+shift0(fx_bypass_y[c]*65350,16);fx_bypass_x[c]=bypass[c];
            fx_bypass[2*i+c]=clamp((int32_t)shift0(fx_bypass_y[c],16),-65536,65536)/2;
        }
        l=shift0(dc_y[0],16); r=shift0(dc_y[1],16);
        /* 6 dB headroom for summing two full-scale playheads. */
        output[2*i]=clamp((int32_t)l,-65536,65536)/2;
        output[2*i+1]=clamp((int32_t)r,-65536,65536)/2;
    }

    for(uint32_t k=0;k<2;k++)for(uint32_t d=0;d<3;d++)mod_offset[k][d]=target_mod[k][d];
    decoder_last[0]=revo_ima_fills-fills_before;decoder_last[1]=revo_ima_decoded-decoded_before;for(uint32_t q=0;q<2;q++)if(decoder_last[q]>decoder_max[q])decoder_max[q]=decoder_last[q];
    return output;
}

/* Read-only display telemetry; synthesis is unchanged. */
uint32_t dl_phase(uint32_t k){return k<2?lfo[k].phase:0;}
uint32_t dl_seed(uint32_t k){return k<2?lfo[k].seed:1;}
int32_t dl_held(uint32_t k){return k<2?lfo[k].held:0;}

int16_t dl_head_sample_at(uint32_t k,uint32_t n){
 if(k>1||n>=head_count(k))return 0;
 if(head_source[k])return revo_ima_at(head_source[k],&ima_cache[k*2],n);
 return dl_sample_at(n);
}
