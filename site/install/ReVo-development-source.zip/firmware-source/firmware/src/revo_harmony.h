/* SPDX-License-Identifier: GPL-3.0-only
 * Bounded control-rate harmony mapping. No allocation, floats or extra voices. */
#pragma once
#include <stdint.h>
#define RH_SCALE_COUNT 9
static const uint8_t rh_scales[RH_SCALE_COUNT][7]={{0,2,4,5,7,9,11},{0,2,3,5,7,8,10},{0,2,3,5,7,9,10},{0,1,3,5,7,8,10},{0,2,4,6,7,9,11},{0,2,4,5,7,9,10},{0,1,3,5,6,8,10},{0,2,4,7,9,0,0},{0,3,5,7,10,0,0}};
static const uint8_t rh_scale_sizes[RH_SCALE_COUNT]={7,7,7,7,7,7,7,5,5};
static const char *rh_scale_names[RH_SCALE_COUNT]={"Major","Minor","Dorian","Phrygian","Lydian","Mixolydian","Locrian","Maj Penta","Min Penta"};
static int rh_in_scale(int note,int key,int scale){int pc=(note-key)%12;if(pc<0)pc+=12;scale=scale<0?0:scale>=RH_SCALE_COUNT?RH_SCALE_COUNT-1:scale;for(int i=0;i<rh_scale_sizes[scale];i++)if(pc==rh_scales[scale][i])return 1;return 0;}
static int rh_quantize(int note,int key,int scale){for(int d=0;d<=6;d++){if(note-d>=24&&rh_in_scale(note-d,key,scale))return note-d;if(note+d<=108&&rh_in_scale(note+d,key,scale))return note+d;}return 60;}
static int rh_degree_note(int root,int degree,int key,int scale){int at=root;while(degree){at++;if(rh_in_scale(at,key,scale))degree--;}return at;}
static uint32_t rh_chord(int root,int key,int scale,int type,uint8_t out[4]){
 root=rh_quantize(root,key,scale);int degrees[4]={0,2,4,6};if(type==2)degrees[1]=1;if(type==3)degrees[1]=3;
 int n=type==1?4:3,notes[4];for(int i=0;i<n;i++)notes[i]=rh_degree_note(root,degrees[i],key,scale);
 if(scale>=7){
  int intervals[4]={0,scale==8?3:4,7,scale==8?10:11};if(type==2)intervals[1]=2;if(type==3)intervals[1]=5;
  for(int i=0;i<n;i++){int desired=root+intervals[i];for(int d=0;d<=12;d++){int lo=desired-d,hi=desired+d;if(lo>=root&&(!i||lo>notes[i-1])&&rh_in_scale(lo,key,scale)){notes[i]=lo;break;}if((!i||hi>notes[i-1])&&rh_in_scale(hi,key,scale)){notes[i]=hi;break;}}}
 }
 while(notes[n-1]>108)for(int i=0;i<n;i++)notes[i]-=12;
 for(int i=0;i<n;i++)out[i]=(uint8_t)notes[i];return (uint32_t)n;
}
static void rh_name(const uint8_t notes[4],uint32_t n,int type,char out[16]){
 static const char *names[]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
 if(!n){out[0]=0;return;}const char *root=names[notes[0]%12],*quality="";
 int third=n>1?(notes[1]-notes[0])%12:0,fifth=n>2?(notes[2]-notes[0])%12:0;
 if(n==4){int seventh=(notes[3]-notes[0])%12;
  quality=fifth==6&&third==3&&seventh==10?"m7b5":fifth==7&&third==3&&seventh==10?"m7":fifth==7&&third==4&&seventh==11?"maj7":fifth==7&&third==4&&seventh==10?"7":fifth==7&&third==4&&seventh==9?"6":"(scale)";
 }else quality=fifth==7&&third==2?"sus2":fifth==7&&third==5?"sus4":fifth==7&&third==6?"sus#4":fifth==7&&third==1?"susb2":fifth==6&&third==3?"dim":fifth==8&&third==4?"aug":fifth==7&&third==3?"m":fifth==7&&third==4?"":"(scale)";
 uint32_t k=0;for(uint32_t i=0;root[i]&&k<15;i++)out[k++]=root[i];for(uint32_t i=0;quality[i]&&k<15;i++)out[k++]=quality[i];out[k]=0;
}
