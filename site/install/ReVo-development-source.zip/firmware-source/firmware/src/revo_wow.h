/* SPDX-License-Identifier: GPL-3.0-only. Bounded stereo modulated tape delay. */
#pragma once
#include <stdint.h>
/* Maximum read distance480 frames;512 retains the complete path plus margin.
 * Same4096 bytes as the previous1024-frame16-bit stereo history. */
#define REVO_WOW_N 512u
static const int16_t wow_sine[65]={0,3212,6393,9512,12539,15446,18204,20787,23170,25329,27245,28898,30273,31356,32137,32609,32767,32609,32137,31356,30273,28898,27245,25329,23170,20787,18204,15446,12539,9512,6393,3212,0,-3212,-6393,-9512,-12539,-15446,-18204,-20787,-23170,-25329,-27245,-28898,-30273,-31356,-32137,-32609,-32767,-32609,-32137,-31356,-30273,-28898,-27245,-25329,-23170,-20787,-18204,-15446,-12539,-9512,-6393,-3212,0};
#if defined(ILHA_FM1_TARGET)
#define REVO_WOW_SECTION __attribute__((section(".pool")))
#else
#define REVO_WOW_SECTION
#endif
static int32_t revo_wow_ring[REVO_WOW_N][2] REVO_WOW_SECTION;
static struct {uint32_t w,phase;int32_t depth,wet; } revo_wow;
static int32_t wow_value(uint32_t phase){uint32_t k=phase>>26,f=(phase>>10)&65535u;return wow_sine[k]+((wow_sine[k+1]-wow_sine[k])*(int32_t)f>>16);}
/* Exact signed Q16 interpolation without a64-bit sample multiply. Magnitude
 * subtraction/product are unsigned; each16x16 product fits uint32. Negative
 * slopes round down, matching the original arithmetic right shift. */
static int32_t wow_lerp(int32_t a,int32_t b,uint32_t f){
 if(f>=65536u)return b;
 uint32_t diff=b>=a?(uint32_t)b-(uint32_t)a:(uint32_t)a-(uint32_t)b;
 uint32_t low=(diff&65535u)*f,delta=(diff>>16)*f+(low>>16);
 if(b>=a)return (int32_t)((uint32_t)a+delta);
 delta+=(low&65535u)!=0;return (int32_t)((uint32_t)a-delta);
}
static void revo_wow_process(int32_t *l,int32_t *r,uint32_t n,int32_t depth,int32_t rate){
 depth=clamp(depth,0,100);rate=clamp(rate,20,5000);
 uint32_t increment=(uint32_t)((uint64_t)(uint32_t)rate*4294967296ULL/44100000u);
 if(!depth&&!revo_wow.depth&&!revo_wow.wet){
  for(uint32_t i=0;i<n;i++){revo_wow_ring[revo_wow.w][0]=l[i];revo_wow_ring[revo_wow.w][1]=r[i];revo_wow.w=(revo_wow.w+1)&(REVO_WOW_N-1u);}revo_wow.phase+=increment*n;return;
 }
 for(uint32_t i=0;i<n;i++){
  revo_wow.depth+=clamp(depth*256-revo_wow.depth,-8,8);
  revo_wow.wet+=clamp((depth?32768:0)-revo_wow.wet,-32,32);
  revo_wow.phase+=increment;
  int32_t sine=wow_value(revo_wow.phase),flutter=wow_value(revo_wow.phase*9u+0x40000000u);
  /* Stronger slow wow plus a small fast flutter; delay remains32..480 frames. */
  int32_t delay=(256<<16)+(int32_t)(((int64_t)sine*208+(int64_t)flutter*16)*revo_wow.depth/12800);
  uint32_t at=(revo_wow.w<<16)-(uint32_t)delay,idx=(at>>16)&(REVO_WOW_N-1u),f=at&65535u;
  int32_t *channels[2]={l,r};
  for(uint32_t ch=0;ch<2;ch++){
   int32_t dry=channels[ch][i],a=revo_wow_ring[idx][ch],b=revo_wow_ring[(idx+1)&(REVO_WOW_N-1u)][ch];
   revo_wow_ring[revo_wow.w][ch]=dry;
   int32_t wet=wow_lerp(a,b,f);
   channels[ch][i]=revo_wow.wet==32768?wet:wow_lerp(dry,wet,(uint32_t)revo_wow.wet*2u);
  }
  revo_wow.w=(revo_wow.w+1)&(REVO_WOW_N-1u);
 }
}
