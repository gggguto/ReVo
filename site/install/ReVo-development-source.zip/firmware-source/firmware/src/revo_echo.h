/* SPDX-License-Identifier: GPL-3.0-only. Independent mono dark echo, stereo dry.
 * 22.05kHz history, 44.1kHz I/O. Two one-pole AA stages before decimation;
 * linear upsampling and dark feedback; bounded gain, no source/Glitch sharing.
 */
#pragma once
#define REVO_ECHO_N 22050u
#if defined(ILHA_FM1_TARGET)
#define REVO_ECHO_SECTION __attribute__((section(".pool")))
#else
#define REVO_ECHO_SECTION
#endif
static int16_t revo_echo_ring[REVO_ECHO_N] REVO_ECHO_SECTION;
static struct {uint32_t write,odd,nonzero;int32_t aa1,aa2,tone,old,now,wet,feedback,time_q8;} revo_echo;
static int32_t echo_bound(int32_t x,int32_t a,int32_t b){return x<a?a:x>b?b:x;}
static void revo_echo_reset(void){memset(&revo_echo,0,sizeof revo_echo);memset(revo_echo_ring,0,sizeof revo_echo_ring);revo_echo.time_q8=250*256;}
/* Time10..1000ms, Feedback0..90%, Mix0..100%. Input at mixer4x scale.
 * Time slews (tape-like pitch during edits), no large copy in the audio path. */
static void revo_echo_process(int32_t *l,int32_t *r,uint32_t n,int32_t ms,int32_t feedback,int32_t mix){
 ms=echo_bound(ms,10,1000);feedback=echo_bound(feedback,0,90);mix=echo_bound(mix,0,100);
 if(!mix&&!revo_echo.wet&&!revo_echo.nonzero&&!revo_echo.aa1&&!revo_echo.aa2&&!revo_echo.tone&&!revo_echo.now&&!revo_echo.old){revo_echo.time_q8=ms*256;return;}
 int32_t mix_target=mix*32768/100,feedback_target=feedback*32768/100,time_target=ms*256;
 for(uint32_t i=0;i<n;i++){
  int32_t in=(!mix&&!revo_echo.wet)?0:echo_bound((l[i]/4+r[i]/4)/2,-32768,32767);
  revo_echo.aa1=in+(revo_echo.aa1-in)/2;revo_echo.aa2=revo_echo.aa1+(revo_echo.aa2-revo_echo.aa1)/2;
  revo_echo.wet+=echo_bound(mix_target-revo_echo.wet,-64,64);
  revo_echo.feedback+=echo_bound(feedback_target-revo_echo.feedback,-32,32);
  revo_echo.time_q8+=echo_bound(time_target-revo_echo.time_q8,-16,16);
  if(!revo_echo.odd){
   /* Read then write: N samples corresponds exactly to one second. */
   uint32_t delay=(uint32_t)((uint64_t)(uint32_t)revo_echo.time_q8*22050u/1000u);
   uint32_t integer=delay>>8,fraction=delay&255u;
   if(integer<1)integer=1;if(integer>REVO_ECHO_N)integer=REVO_ECHO_N;
   uint32_t at=(revo_echo.write+REVO_ECHO_N-integer)%REVO_ECHO_N,prev=at?at-1:REVO_ECHO_N-1;
   int32_t a=revo_echo_ring[at],b=revo_echo_ring[prev],read=a+(b-a)*(int32_t)fraction/256;
   revo_echo.old=revo_echo.now;revo_echo.tone=read+(revo_echo.tone-read)/2;revo_echo.now=revo_echo.tone;
   int32_t value=revo_echo.aa2+(int32_t)((int64_t)revo_echo.tone*revo_echo.feedback/32768);
   int16_t next=(int16_t)echo_bound(value,-32768,32767);if(revo_echo_ring[revo_echo.write])revo_echo.nonzero--;if(next)revo_echo.nonzero++;revo_echo_ring[revo_echo.write]=next;
   if(++revo_echo.write==REVO_ECHO_N)revo_echo.write=0;
  }
  int32_t wet=revo_echo.odd?revo_echo.now:(revo_echo.old+revo_echo.now)/2;
  int32_t add=(int32_t)((int64_t)wet*4*revo_echo.wet/32768);
  l[i]+=add;r[i]+=add;revo_echo.odd^=1u;
 }
}
