/* SPDX-License-Identifier: GPL-3.0-only
 * ECOSYSTEM WILD: portable fixed-point synthesis, no samples/HAL/storage/heap.
 * 44.1 kHz stereo. Seven reserved slots: 2 birds (one phrase), 1 insect, 1 aquatic, 3 WIND pads.
 * Host/browser prototype: target FM-1 timing and RAM integration remain unverified.
 */
#include <stdint.h>
#include "revo_motion.h"
#include "revo_harmony.h"
#define FS 44100u
#define BLOCK 128u
#define VOICES 4
#define WIND_VOICES 3
static const int16_t sine[257]={0,804,1608,2410,3212,4011,4808,5602,6393,7179,7962,8739,9512,10278,11039,11793,12539,13279,14010,14732,15446,16151,16846,17530,18204,18868,19519,20159,20787,21403,22005,22594,23170,23731,24279,24811,25329,25832,26319,26790,27245,27683,28105,28510,28898,29268,29621,29956,30273,30571,30852,31113,31356,31580,31785,31971,32137,32285,32412,32521,32609,32678,32728,32757,32767,32757,32728,32678,32609,32521,32412,32285,32137,31971,31785,31580,31356,31113,30852,30571,30273,29956,29621,29268,28898,28510,28105,27683,27245,26790,26319,25832,25329,24811,24279,23731,23170,22594,22005,21403,20787,20159,19519,18868,18204,17530,16846,16151,15446,14732,14010,13279,12539,11793,11039,10278,9512,8739,7962,7179,6393,5602,4808,4011,3212,2410,1608,804,0,-804,-1608,-2410,-3212,-4011,-4808,-5602,-6393,-7179,-7962,-8739,-9512,-10278,-11039,-11793,-12539,-13279,-14010,-14732,-15446,-16151,-16846,-17530,-18204,-18868,-19519,-20159,-20787,-21403,-22005,-22594,-23170,-23731,-24279,-24811,-25329,-25832,-26319,-26790,-27245,-27683,-28105,-28510,-28898,-29268,-29621,-29956,-30273,-30571,-30852,-31113,-31356,-31580,-31785,-31971,-32137,-32285,-32412,-32521,-32609,-32678,-32728,-32757,-32767,-32757,-32728,-32678,-32609,-32521,-32412,-32285,-32137,-31971,-31785,-31580,-31356,-31113,-30852,-30571,-30273,-29956,-29621,-29268,-28898,-28510,-28105,-27683,-27245,-26790,-26319,-25832,-25329,-24811,-24279,-23731,-23170,-22594,-22005,-21403,-20787,-20159,-19519,-18868,-18204,-17530,-16846,-16151,-15446,-14732,-14010,-13279,-12539,-11793,-11039,-10278,-9512,-8739,-7962,-7179,-6393,-5602,-4808,-4011,-3212,-2410,-1608,-804,0};
typedef struct {
 uint32_t age,length,p,mp,start,end,mod,depth,attack,pulse;
 int32_t pan,filter; uint8_t family,on,aquatic;
 uint32_t sub,throat,pitch_env,index_env,amp_env,amp_step;
} voice_t;
static voice_t voice[VOICES];
/* WIND uses three reserved, non-stealing voices. Short taps make small gusts;
 * held notes build over ~1.3 s, full release takes ~3.2 s. */
typedef struct {uint32_t p,q,inc,target,env,release_step,attack_frac,release_frac;int32_t gain_env,gain_step,gain_target,inc_step;uint32_t detune,formant_band,formant_mix;int32_t tone_old,tone_now,gl,gr,glt,grt,gld,grd,fm_index;uint8_t note,on,gate;int32_t drift_note;} wind_t;
static wind_t wind[WIND_VOICES];
#include "revo_wind_tables.inc"
#include "revo_wind_formants.inc"
/* Bounded controller: no allocation, clocks or USB from synthesis. */
static uint32_t engine_pressure,engine_guard_events,engine_wind_releases;
static int32_t send_target[6][2],send_gain[6][2],delay_output[BLOCK],verb_output[BLOCK],send_dc_x[2],send_dc_y[2];
static int32_t send_q15(int32_t x,int32_t gain){return gain==32768?x:gain?x*gain/32768:0;}

static int32_t wind_gain=70,wind_patch,wind_patch_pending,wind_patch_gain=32768,wind_smooth;
static uint32_t wind_strength,bed_phase,wind_colour_phase;
static uint32_t wind_attack_step=19660800,wind_release_ms=3170;
static int32_t bed_rate=200,bed_depth,eco_harmony_mode,eco_key,eco_scale,bed_gain=32768;
static int32_t bed_shape,bed_held,bed_drift_from,bed_last_wave;static uint32_t bed_seed=0x7a13b5u;
static const uint32_t note_inc[61]={3185015u,3374406u,3575058u,3787642u,4012867u,4251485u,4504291u,4772130u,5055896u,5356535u,5675051u,6012507u,6370030u,6748811u,7150117u,7575285u,8025735u,8502970u,9008582u,9544261u,10111792u,10713070u,11350103u,12025015u,12740059u,13497623u,14300233u,15150569u,16051469u,17005939u,18017165u,19088521u,20223584u,21426141u,22700205u,24050030u,25480119u,26995246u,28600467u,30301139u,32102938u,34011878u,36034330u,38177043u,40447168u,42852281u,45400411u,48100060u,50960238u,53990491u,57200933u,60602278u,64205876u,68023757u,72068660u,76354085u,80894335u,85704563u,90800821u,96200119u,101920476u};
static int32_t limit(int32_t,int32_t,int32_t);
static uint32_t random32(uint32_t*);
static uint32_t run;
static int32_t params[11],levels[4];
static int32_t weather_on,weather_intensity=50,weather_movement,weather_current=50,weather_density=50,weather_variety=65;
static uint32_t weather_phase,weather_seed=0x1ab93u;static int32_t weather_from,weather_to;
static uint32_t response_amount,response_spacing=50,response_left,response_next,response_wait,response_tick;
static void eco_living(int32_t intensity,int32_t movement,int32_t enabled,int32_t amount,int32_t spacing){
 weather_intensity=limit(intensity,0,100);weather_movement=limit(movement,0,100);if(enabled&&!weather_on){weather_phase=0;weather_from=0;weather_to=(int32_t)(random32(&weather_seed)>>16)-32768;}weather_on=!!enabled;
 response_amount=(uint32_t)limit(amount,0,100);response_spacing=(uint32_t)limit(spacing,0,100);if(!amount)response_left=0;
}
static int32_t eco_density_now(void){return weather_on?weather_density:params[0];}
static uint32_t density_den(uint32_t d){return 2000000u+2u*d*d*d*d;}
static int32_t eco_variety_now(void){int32_t v=weather_on?weather_variety:params[1];return v*v/100;}
static void weather_update(void){
 if(!weather_on){weather_current=weather_intensity;return;}
 uint32_t old=weather_phase;if(run)weather_phase+=623305u; /* ~20 s half-cosine target transitions */
 if(weather_phase<old){weather_from=weather_to;weather_to=(int32_t)(random32(&weather_seed)>>16)-32768;}
 weather_current=limit(weather_intensity+(int32_t)((int64_t)revo_drift(weather_phase,weather_from,weather_to)*weather_movement/81920),0,100);
 weather_density=limit(params[0]+(weather_current-50)*9/10,0,100);weather_variety=limit(params[1]+(weather_current-50)/2,0,100);
}

static uint32_t current_seed,pending_seed,seed_pending;
static uint32_t family_tame[3],family_cycle[3]={16,16,16},family_step[3];
static uint32_t family_activity[3]={100,100,100},family_credit[3],family_opportunities[3],family_status[3];
static uint32_t family_effective(uint32_t f){return family_activity[f]*(uint32_t)eco_density_now()/100u;}
static int32_t insect_register=50,bed_filter_state;
static uint32_t rng,noise_rng,waiting[3],events[3],active,fade;
static uint32_t clock_phase,clock_due,clock_next,clock_step,clock_ticks;
static int32_t low,slow,dc_x[2],dc_y[2];
static int32_t output[BLOCK*2],wind_output[BLOCK*2],ocean_output[BLOCK],ocean_dc_x,ocean_dc_y,wind_dc_x[2],wind_dc_y[2];
static int32_t wind_norm=32768,wind_pan[3]={32768,32768,32768};
static int32_t limit(int32_t v,int32_t a,int32_t b){return v<a?a:v>b?b:v;}
static uint32_t random32(uint32_t *s){uint32_t x=*s;x^=x<<13;x^=x>>17;x^=x<<5;return *s=x;}
static uint32_t choose(uint32_t a,uint32_t b){return a+random32(&rng)%(b-a+1);}
static uint32_t hz(uint32_t f){return f*(4294967296ULL/FS)+(f*(4294967296ULL%FS))/FS;}
/* Exact signed Q16 multiply with truncation toward zero; bounded 32-bit limbs. */
static int32_t eco_q16(int32_t x,uint32_t gain){uint32_t a=x<0?0u-(uint32_t)x:(uint32_t)x,y=(a>>16)*gain+((a&65535u)*gain>>16);return x<0?-(int32_t)y:(int32_t)y;}
static int32_t osc(uint32_t p){uint32_t i=p>>24,f=(p>>8)&65535;return sine[i]+(sine[i+1]-sine[i])*(int32_t)f/65536;}
#include "eco_layers.inc"
static uint32_t tonal_increment(uint32_t value);
#include "eco_birds.inc"
void eco_seed(uint32_t seed){
 current_seed=seed;pending_seed=seed_pending=0;rng=seed?seed:0x9e3779b9u;noise_rng=rng^0xa511e9b3u;if(!noise_rng)noise_rng=1;
 run=fade=active=wind_strength=0;ocean_dc_x=ocean_dc_y=0;clock_phase=clock_next=clock_step=clock_ticks=0;clock_due=1;low=slow=0;
 for(uint32_t k=0;k<WIND_VOICES;k++)wind[k]=(wind_t){0};wind_smooth=wind_gain*32768/100;
 for(uint32_t i=0;i<VOICES;i++)voice[i]=(voice_t){0};for(uint32_t i=0;i<2;i++)birds[i]=(bird_t){0};
 for(uint32_t k=0;k<3;k++){family_step[k]=0;family_credit[k]=100u-family_effective(k);family_opportunities[k]=family_status[k]=0;events[k]=0;waiting[k]=FS*(k+1)/5;}
 for(uint32_t k=0;k<2;k++)dc_x[k]=dc_y[k]=wind_dc_x[k]=wind_dc_y[k]=0;wind_norm=32768;for(uint32_t k=0;k<3;k++)wind_pan[k]=32768;
 for(uint32_t k=0;k<4;k++)levels[k]=params[k+2]*32768/100;levels[3]=levels[3]*259/1000;bed_gain=levels[3];
}
void eco_init(uint32_t seed){for(uint32_t f=0;f<3;f++){family_tame[f]=0;family_activity[f]=100;family_cycle[f]=16;family_step[f]=0;}weather_on=weather_movement=0;weather_intensity=weather_current=50;weather_phase=0;weather_from=weather_to=0;weather_seed=0x1ab93u;response_amount=response_left=0;response_spacing=50;params[0]=50;params[1]=65;params[2]=75;params[3]=45;params[4]=70;params[5]=20;params[6]=35;params[7]=20;params[8]=0;params[9]=100;params[10]=16;insect_register=50;bed_filter_state=0;wind_gain=70;wind_colour_phase=0;wind_patch=wind_patch_pending=0;wind_patch_gain=32768;wind_attack_step=19660800;wind_release_ms=3170;bed_phase=0;bed_gain=32768;bed_rate=200;bed_shape=bed_held=bed_drift_from=bed_last_wave=0;bed_seed=0x7a13b5u;bed_depth=eco_harmony_mode=eco_key=eco_scale=0;eco_seed(seed);layers_init(seed);}
static void apply_live_seed(void){if(seed_pending){current_seed=pending_seed;rng=current_seed?current_seed:0x9e3779b9u;drift_rng=current_seed^0xbb67ae85u;layer_rng=current_seed^0x3c6ef372u;pending_seed=seed_pending=0;}}
void eco_seed_live(uint32_t seed){pending_seed=seed;seed_pending=1;apply_live_seed();}
uint32_t eco_seed_current(void){return current_seed;}
uint32_t eco_seed_pending(void){return seed_pending?pending_seed:0;}
void eco_param(uint32_t k,int32_t v){
 if(k<8){v=limit(v,0,100);uint32_t density_changed=k==0&&v!=params[0];if(density_changed)for(uint32_t f=0;f<3;f++)waiting[f]=(uint32_t)((uint64_t)waiting[f]*density_den((uint32_t)params[0])/density_den((uint32_t)v));params[k]=v;if(density_changed)for(uint32_t f=0;f<3;f++)family_credit[f]=100u-family_effective(f);}
 else if(k==8){uint32_t mode=!!v;if(mode!=(uint32_t)params[8]){response_left=0;clock_phase=clock_next=clock_step=clock_ticks=0;clock_due=1;}params[8]=(int32_t)mode;for(uint32_t f=0;f<3;f++){family_tame[f]=mode;family_step[f]=0;}if(!mode)apply_live_seed();}
 else if(k==9)params[k]=limit(v,40,240);
 else if(k==10){params[k]=limit(v,1,64);for(uint32_t f=0;f<3;f++){family_cycle[f]=(uint32_t)params[k];family_step[f]%=family_cycle[f];}clock_next%=params[k];clock_step%=params[k];}
 else if(k==11)insect_register=limit(v,0,100);
}
static uint32_t wind_div(uint64_t n,uint32_t d);
void eco_activity_param(uint32_t f,uint32_t activity){
 if(f>=3)return;if(activity>100)activity=100;if(activity==family_activity[f])return;
 uint32_t old=family_activity[f]?family_activity[f]:1,new_activity=activity?activity:1;
 waiting[f]=wind_div((uint64_t)waiting[f]*old,new_activity);family_activity[f]=activity;family_credit[f]=100u-family_effective(f);
}
/* Shared sixteenth clock, independent family periods. Editing one family never
 * resets another family, the Wind envelopes, or the global transport phase. */
void eco_family_param(uint32_t f,uint32_t tame,uint32_t cycle){
 if(f>=3)return;cycle=(uint32_t)limit((int32_t)cycle,1,64);tame=!!tame;
 if(family_tame[f]!=tame){family_tame[f]=tame;family_step[f]=0;family_credit[f]=100u-family_effective(f);waiting[f]=FS/5;if(response_left&&response_next==f)response_left=0;}
 if(family_cycle[f]!=cycle){family_cycle[f]=cycle;family_step[f]%=cycle;}
}
uint32_t eco_step(void){return clock_step;}
uint32_t eco_ticks(void){return clock_ticks;}
void eco_play(uint32_t on){run=!!on;if(!run){response_left=0;apply_live_seed();}}
uint32_t eco_frames(void){return BLOCK;}
uint32_t eco_rate(void){return FS;}
uint32_t eco_events(uint32_t k){return k<3?events[k]:0;}
uint32_t eco_wind_voices(void){uint32_t count=0;for(uint32_t k=0;k<WIND_VOICES;k++)count+=wind[k].on;return count;}
uint32_t eco_wind_level(void){return wind_strength;}
uint32_t eco_active(void){return active+eco_wind_voices();}
static uint32_t wind_div(uint64_t n,uint32_t d){
 uint32_t quotient=0,remainder=0;
 for(int bit=63;bit>=0;bit--){remainder=(remainder<<1)|(uint32_t)((n>>bit)&1u);quotient<<=1;if(remainder>=d){remainder-=d;quotient|=1u;}}
 return quotient;
}
void eco_wind_param(uint32_t id,int32_t value){if(id==0)wind_gain=limit(value,0,100);else if(id==1)wind_patch_pending=limit(value,0,7);else if(id==10)bed_rate=limit(value,20,10000);else if(id==11)bed_depth=limit(value,0,100);else if(id==12)eco_harmony_mode=limit(value,0,2);else if(id==13)eco_key=limit(value,0,11);else if(id==14)eco_scale=limit(value,0,8);else if(id==16){if(value==5&&bed_shape!=5){bed_drift_from=bed_last_wave;bed_held=(int32_t)(random32(&bed_seed)>>16)-32768;bed_phase=0;}bed_shape=limit(value,0,5);}
 else if(id==17){uint32_t ms=(uint32_t)limit(value,10,10000);wind_attack_step=wind_div(16777216ULL*1000*65536,FS*ms);}
 else if(id==18)wind_release_ms=(uint32_t)limit(value,20,20000);}
static uint32_t wind_release_step(uint32_t env){uint32_t frames=(uint32_t)((uint64_t)FS*wind_release_ms/1000);return env?wind_div((uint64_t)env*65536+frames-1,frames):65536;}
static uint32_t wind_note_inc(uint32_t note){
 uint32_t shifts=0;while(note>84){note-=12;shifts++;}
 return note_inc[note-24]<<shifts;
}
uint32_t eco_note(uint32_t note,uint32_t on){
 if(note<24||note>108)return 0;
 for(uint32_t k=0;k<WIND_VOICES;k++)if(wind[k].on&&wind[k].note==note){wind[k].gate=!!on;if(on){wind[k].release_step=0;}else {wind[k].release_step=wind_release_step(wind[k].env);wind[k].release_frac=0;}return 1;}
 if(!on)return 1;
 for(uint32_t k=0;k<WIND_VOICES;k++)if(!wind[k].on){wind[k]=(wind_t){.note=(uint8_t)note,.on=1,.gate=1,.inc=wind_note_inc(note),.target=wind_note_inc(note),.drift_note=(int32_t)note};return 1;}
 for(uint32_t k=0;k<WIND_VOICES;k++)if(!wind[k].gate){
  /* Legato reuse: keep current amplitude, oscillator phases and frequency.
   * Attack rises from this level; the existing frequency slew reaches the new
   * pitch. Three reserved voices, no 1.45 ms tail truncation or extra reader. */
  wind_t *v=&wind[k];v->note=(uint8_t)note;v->drift_note=(int32_t)note;
  v->target=wind_note_inc(note);v->gate=1;v->release_step=0;
  v->release_frac=v->attack_frac=0;return 1;
 }

 return 0;
}
static uint32_t spread(uint32_t base,uint32_t lo,uint32_t hi){int32_t variety=eco_variety_now();return (base*(100-variety)+choose(lo,hi)*variety)/100;}
static uint32_t tonal_increment(uint32_t value){
 if(!eco_harmony_mode)return value;
 uint32_t best=0,distance=0xffffffffu;
 for(int note=24;note<=132;note++)if(rh_in_scale(note,eco_key,eco_scale)){
  uint32_t inc=wind_note_inc((uint32_t)note),d=value>inc?value-inc:inc-value;if(d<distance){distance=d;best=inc;}
 }return best;
}
static void spawn(uint32_t family){
 if(family==0&&(voice[0].on||voice[1].on))return; /* finish a coherent phrase, never stack canaries */
 const uint32_t first[3]={0,2,3},last[3]={2,3,4};
 uint32_t aquatic=family==2?(choose(0,99)<40?1u:2u):0;
 voice_t *v=0;
 for(uint32_t i=first[family];i<last[family];i++)if(!voice[i].on){v=&voice[i];break;}
 if(!v)return; /* Saturation drops the new event, never steals a voice mid-envelope. */
 *v=(voice_t){.on=1,.family=(uint8_t)family,.aquatic=(uint8_t)aquatic,.pan=(int32_t)choose(0,46000)-23000};
 if(family==0){
  bird_begin(v); }else if(family==1){
  v->length=FS*spread(650,300,1100)/1000;v->start=v->end=hz(spread(5300,3000,8200));
  v->mod=hz(spread(42,20,85));v->depth=hz(60);
 }else{
  /* AQUATIC_02 recipe: resonant FM frogs and short swept FM bubbles.
   * Envelope recurrences replace exp/pow; no sample or event sequence stored. */
  if(aquatic==1){
   v->length=FS*spread(550,320,850)/1000;v->start=hz(spread(175,125,225));v->end=v->start;
   v->mod=hz(spread(31,23,39));v->attack=FS*14/1000;v->amp_step=65536u/(v->length*38/100);v->pulse=45;
  }else{
   v->length=FS*spread(120,65,190)/1000;v->start=hz(spread(400,240,650));
   v->aquatic=choose(0,99)<65?2:3;v->attack=FS*18/10000;v->amp_step=65536u/(FS*spread(30,18,45)/1000);v->pulse=v->aquatic==2?18:9;
  }
  v->pitch_env=v->index_env=v->amp_env=16777216u;

 }
 if(family==2){
  uint32_t scale=8192+(uint32_t)params[family==0?6:7]*40960u/100;
  v->start=(uint64_t)v->start*scale/32768;v->end=(uint64_t)v->end*scale/32768;
  v->depth=(uint64_t)v->depth*scale/32768;
 }
 if(family==1){uint32_t scale=insect_register<=50?8192+(uint32_t)insect_register*24576/50:32768+(uint32_t)(insect_register-50)*32768/50;v->start=(uint64_t)v->start*scale/32768;v->end=(uint64_t)v->end*scale/32768;v->depth=(uint64_t)v->depth*scale/32768;}
 if(family!=0){v->start=tonal_increment(v->start);v->end=tonal_increment(v->end);}
 if(family==1)v->attack=FS*choose(family==0?4:family==1?18:1,family==0?16:family==1?45:4)/1000;
 if(family==1)v->pulse=spread(70,45,110);
 events[family]++;resonance_excite(v);
}
static uint32_t response_family_after(uint32_t family){
 for(uint32_t i=1;i<=3;i++){uint32_t next=(family+i)%3;if(params[next+2]&&family_activity[next])return next;}return family;
}
static void response_schedule(uint32_t family){
 response_next=response_family_after(family);response_wait=FS*(100u+response_spacing*12u)/1000u;
 response_tick=clock_ticks+1u+response_spacing*7u/100u;
}
static void request_spawn(uint32_t family){
 if(!family_activity[family])return;
 if(!response_amount){spawn(family);return;}
 if(response_left&&choose(0,99)<response_amount)return;
 uint32_t before=events[family];spawn(family);
 if(events[family]!=before&&!response_left&&choose(0,99)<response_amount){response_left=2;response_schedule(family);}
}
static void response_reply(void){
 uint32_t family=response_next;
 if(eco_density_now()&&params[family+2]&&choose(0,99)<family_activity[family])spawn(family);
 if(response_left)response_left--;if(response_left)response_schedule(family);
}
static uint32_t interval(uint32_t family){
 const uint32_t base[3]={28000,46000,15000};
 return wind_div((uint64_t)base[family]*choose(60,160)*100000000u,density_den((uint32_t)eco_density_now()))/(family_activity[family]?family_activity[family]:1u);
}
static void tame_tick(void){
 apply_live_seed();clock_step=clock_next;clock_next=(clock_next+1)%64u;clock_ticks++;
 uint32_t reply=response_left&&family_tame[response_next]&&family_step[response_next]==0&&(int32_t)(clock_ticks-response_tick)>=0;
 for(uint32_t k=0;k<3;k++){
  if(family_tame[k]&&family_step[k]==0){
   family_opportunities[k]++;family_status[k]=2; /* REST unless an eligible call succeeds. */
   uint32_t participation=family_effective(k);family_credit[k]+=participation;
   if(participation&&family_credit[k]>=100u){
    family_credit[k]-=100u;uint32_t before=events[k];if(params[k+2])spawn(k);
    family_status[k]=events[k]!=before?1u:params[k+2]?3u:2u; /* CALL/BUSY/REST */
    /* A scheduled Tame start has priority over a Response conversation. */
    if(events[k]!=before&&!response_left&&response_amount&&choose(0,99)<response_amount){response_left=2;response_schedule(k);}
   }
  }
  family_step[k]=(family_step[k]+1)%family_cycle[k];
 }
 /* Tame replies coincide with the receiver's own activity/grid; do not add a
  * second event, steal a phrase, or let a conversation suppress its own turn. */
 if(reply&&response_left){response_left--;if(response_left)response_schedule(response_next);}
 drift_tick();beam_tick();
}
static uint32_t external_mode,external_due,external_have,external_sub;
void eco_external_reset(void){drift_elapsed=0;external_due=external_have=external_sub=0;clock_next=clock_step=clock_ticks=clock_phase=0;clock_due=1;for(uint32_t f=0;f<3;f++)family_step[f]=0;}
void eco_external_mode(uint32_t on){on=!!on;if(on!=external_mode){external_mode=on;eco_external_reset();}}
void eco_external_pulse(void){if(!external_mode)return;if(!external_have){external_have=1;external_due=1;}else if(++external_sub==6){external_sub=0;if(external_due<64)external_due++;}}
static uint32_t eco_beat_mask[4];
int32_t *eco_render(void){
 for(uint32_t k=0;k<4;k++)eco_beat_mask[k]=0;
 weather_update();layers_block();
 int32_t level_target[4];for(uint32_t k=0;k<4;k++)level_target[k]=params[k+2]*32768/100;
 level_target[3]=level_target[3]*259/1000;if(weather_on)level_target[3]=limit(level_target[3]*(25+weather_current*3/2)/100,0,12124);
 for(uint32_t f=0;f<6;f++)for(uint32_t j=0;j<2;j++)send_gain[f][j]+=limit(send_target[f][j]-send_gain[f][j],-2048,2048);

 /* Normalize effective polyphony by relative envelope energy, including releases.
  * Control-rate reciprocal-square-root lookup; no audio-rate division/sqrt. */
 uint32_t energy_sum=0,energy_max=0,wind_count=0;for(uint32_t k=0;k<WIND_VOICES;k++)if(wind[k].on){uint32_t a=wind[k].env>>10,e=a*a;energy_sum+=e;if(e>energy_max)energy_max=e;wind_count++;}
 static const uint16_t normalization[9]={32768,29309,26755,24770,23170,21845,20724,19760,18919};
 int32_t wind_vowel=16384;if(wind_count&&wind_patch>=4){wind_colour_phase+=1558264u;wind_vowel+=osc(wind_colour_phase)/3;}
 uint32_t voices=energy_max?(uint32_t)((uint64_t)energy_sum*32768u/energy_max):32768u;if(voices<32768)voices=32768;if(voices>98304)voices=98304;
 uint32_t norm_at=(voices-32768u)/8192u,norm_frac=(voices-32768u)%8192u;int32_t norm_target=norm_at>=8?normalization[8]:normalization[norm_at]+((int32_t)normalization[norm_at+1]-normalization[norm_at])*(int32_t)norm_frac/8192;

 /* Ocean LFO modulates amplitude only. Depth zero freezes its oscillator. */
 int32_t bed_wave=0;
 if(bed_depth){
  if(run){uint32_t previous=bed_phase;bed_phase+=(uint32_t)((uint64_t)bed_rate*4294967296ULL*BLOCK/44100000ULL);if(bed_phase<previous){bed_drift_from=bed_held;bed_held=(int32_t)(random32(&bed_seed)>>16)-32768;}}
  int32_t bx=(int32_t)(bed_phase>>16);bed_wave=bed_shape==5?revo_drift(bed_phase,bed_drift_from,bed_held):bed_shape==0?osc(bed_phase):bed_shape==1?(bx<16384?bx*2:bx<49152?65536-bx*2:bx*2-131072):bed_shape==2?bed_held:bed_shape==3?bx-32768:32767-bx;
 }
 bed_last_wave=bed_wave;
 /* Unipolar tremolo never boosts above Level; fixed 600 Hz softening filter. */
 int32_t bed_amplitude=32768-(32768-bed_wave)*bed_depth/200;
 int32_t bed_gain_target=levels[3]*bed_amplitude/32768;
 for(uint32_t i=0;i<BLOCK;i++){
  if(run&&fade<882)fade++;else if(!run&&fade)fade--;
  if(run){
   {
    uint32_t before_tick=clock_ticks;
    if(external_mode){if(external_due){external_due--;tame_tick();}}
    else if(clock_due){clock_due=0;tame_tick();}
    else {clock_phase+=(uint32_t)params[9]*4u;if(clock_phase>=FS*60u){clock_phase-=FS*60u;tame_tick();}}
    if(clock_ticks!=before_tick&&clock_step%4u==0)eco_beat_mask[i>>5]|=1u<<(i&31u);
   }
   for(uint32_t k=0;k<3;k++){
    if(family_tame[k])continue;
    if(k==0&&(voice[0].on||voice[1].on))continue; /* Rest begins after the whole phrase. */
    if(waiting[k])waiting[k]--;else {if(eco_density_now()&&params[k+2])request_spawn(k);waiting[k]=interval(k);}
   }
  }
  if(run&&response_left&&!family_tame[response_next]){if(response_wait)response_wait--;else response_reply();}
  for(uint32_t k=0;k<4;k++){int32_t target=level_target[k];levels[k]+=(target-levels[k])/256;if(target-levels[k]<256&&target-levels[k]>-256)levels[k]=target;}
  for(uint32_t f=0;f<3;f++){spatial_t *s=&spatial[f];if(s->on&&s->mix<32768)s->mix+=64;else if(!s->on&&s->mix)s->mix-=64;}
  int32_t l=0,r=0;int32_t ds=0,vs=0;active=0;
  for(uint32_t n=0;n<VOICES;n++){
   voice_t *v=&voice[n];if(!v->on)continue;active++;
   if(!fade){v->on=0;continue;}
   uint32_t a=v->age,len=v->length;
   int32_t env,s;
   if(v->family==0){s=bird_sample(v,&env);}
   else if(v->family==2){
    uint32_t pitch_step=65536u/(FS*v->pulse/1000u);
    v->pitch_env-=(uint32_t)((uint64_t)v->pitch_env*pitch_step/65536u);
    v->index_env-=(uint32_t)((uint64_t)v->index_env*(v->aquatic==1?10u:165u)/65536u);
    v->amp_env-=(uint32_t)((uint64_t)v->amp_env*v->amp_step/65536u);
    int32_t e=(int32_t)(v->pitch_env>>9),idx;
    uint32_t inc;
    if(v->aquatic==1){
     inc=v->start+(uint32_t)((uint64_t)v->start*(uint32_t)e*32u/(32768ULL*100u));
     idx=4172+(int32_t)((uint64_t)v->index_env*13038u/16777216u);
    }else if(v->aquatic==2){
     inc=(uint32_t)((uint64_t)v->start*(49152u-(uint32_t)e*4u/5u)/32768u);
     idx=835+(int32_t)((uint64_t)v->index_env*9387u/16777216u);
    }else{
     inc=v->start+(uint32_t)((uint64_t)v->start*(uint32_t)e*18u/(32768ULL*10u));
     idx=835+(int32_t)((uint64_t)v->index_env*9387u/16777216u);
    }
    v->p+=inc;v->sub+=inc/2u;
    s=osc(v->p+(uint32_t)osc(v->p*2u)*(uint32_t)idx);
    if(v->aquatic==1){
     v->throat+=v->mod;int32_t throat=(osc(v->throat)+32768)/2;throat=(int32_t)(throat*throat/32768);
     s=(s*74+osc(v->sub+(uint32_t)osc(v->p)*4694u)*26)/100;
     s=(int32_t)(s*(6554+throat*4/5)/32768);
    }
    env=(int32_t)(v->amp_env>>9);
    if(a<v->attack)env=(int32_t)(env*(int32_t)a/(int32_t)v->attack);
    uint32_t tail=FS*(v->aquatic==1?45u:12u)/1000u;
    if(len-a<tail)env=(int32_t)(env*(int32_t)(len-a)/(int32_t)tail);
   }else{
   uint32_t attack=v->attack;

   if(a<attack){int32_t x=a*32768u/attack;env=(x*x/32768)*(98304-2*x)/32768;}
   else {int32_t tail=(len-a)*32768u/(len-attack);env=tail*tail/32768;}
   int32_t progress=a*32768u/len;
   int32_t curve=progress;
   if(v->family==0)curve=progress*progress/32768*(98304-2*progress)/32768;
   if(v->family==2){int32_t tail=32768-progress;curve=32768-tail*tail/32768*tail/32768;}
   int64_t increment=(int64_t)v->start+((int64_t)v->end-v->start)*curve/32768;
   int32_t modulation=osc(v->mp);
   /* Insect stridulation slows a little through each phrase. */
   uint32_t modstep=v->mod;
   if(v->family==1)modstep=(uint64_t)modstep*(32768-progress/6)/32768;
   v->mp+=modstep;
   int32_t timbre=32768;
   if(v->family==0)timbre=8192+env*24576/32768;
   if(v->family==2)timbre=env;
   increment+=(int64_t)modulation*v->depth/32768*timbre/32768;
   v->p+=(uint32_t)(increment<0?0:increment);
   s=osc(v->p);
   if(v->family==1){
    int32_t pulse=modulation>0?modulation:0;
    pulse=pulse*pulse/32768;
    /* A second slow envelope groups the pulses into chirp phrases. */
    uint32_t phrase=a*v->pulse/1000;
    int32_t group=osc((uint32_t)((phrase/(FS/10))*4294967296ULL+(phrase%(FS/10))*(4294967296ULL/(FS/10))+((phrase%(FS/10))*(4294967296ULL%(FS/10)))/(FS/10)));
    group=group>0?group:0;
    s=s*pulse/32768*(8192+group*24576/32768)/32768;
   }

   }
   int32_t gain=v->family==0?6062:v->family==1?4300:v->aquatic==1?16000:10500;
   int32_t pan=v->pan;s=distance_sample(v,s,&pan);
   int32_t value=s*env/32768*levels[v->family]/32768*gain/32768;if(v->family==0)value=value*3/4;
   l+=value*(32768-pan)/65536;r+=value*(32768+pan)/65536;
   int32_t mono=(int32_t)(value/2);ds+=send_q15(mono,send_gain[v->family][0]);vs+=send_q15(mono,send_gain[v->family][1]);
   if(++v->age>=len)v->on=0;
  }
  int32_t dry_gain=resonance_dry_gain();l=l*dry_gain/32768;r=r*dry_gain/32768;ds=send_q15(ds,dry_gain);vs=send_q15(vs,dry_gain);
  int32_t noise=(int32_t)(random32(&noise_rng)>>16)-32768;
  low+=(noise-low)/12;slow+=(noise-slow)/180;
  int32_t bed=0;
  if(levels[3]){
   /* Bounded noise/filter and gain products fit signed 32-bit. */
   bed_filter_state+=((noise-slow)-bed_filter_state)*2685/32768;
   bed_gain+=(bed_gain_target-bed_gain)/128;if(bed_gain_target-bed_gain<128&&bed_gain_target-bed_gain>-128)bed_gain=bed_gain_target;
   bed=bed_filter_state*bed_gain/32768/3;
  }else {bed_filter_state=0;bed_gain=0;}
  /* Keep the mono Ocean stem aligned with transport fade and output DC removal.
   * Bounds of the reduced bed keep this one-pole product inside signed32-bit. */
  int32_t ocean_x=bed*(int32_t)fade/882/2;
  ocean_dc_y=ocean_x-ocean_dc_x+eco_q16(ocean_dc_y,65350);ocean_dc_x=ocean_x;ocean_output[i]=ocean_dc_y;
  l+=bed;r+=bed;
  /* Transport affects the ecosystem bed/events, never the keyboard WIND. */
  l=l*(int32_t)fade/882;r=r*(int32_t)fade/882;
  ds=ds*(int32_t)fade/882;vs=vs*(int32_t)fade/882;
  int32_t resonant=resonance_sample();l+=resonant;r+=resonant;
  ds+=send_q15(resonant,send_gain[3][0]);vs+=send_q15(resonant,send_gain[3][1]);
  vs+=send_q15(bed*(int32_t)fade/882,send_gain[5][1]);
  int32_t wind_l=0,wind_r=0;wind_strength=0;if(!(i&7u)){wind_norm+=(norm_target-wind_norm)/32;if(norm_target-wind_norm<32&&norm_target-wind_norm> -32)wind_norm=norm_target;
  int32_t wind_target=wind_gain*32768/100;wind_smooth+=(wind_target-wind_smooth)/32;
  if(wind_target-wind_smooth<32&&wind_target-wind_smooth>-32)wind_smooth=wind_target;}
  if(wind_patch!=wind_patch_pending){wind_patch_gain-=74;if(wind_patch_gain<=0){wind_patch_gain=0;wind_patch=wind_patch_pending;if(wind_patch==4)for(uint32_t v=0;v<WIND_VOICES;v++)if(wind[v].on)wind_formant_control(&wind[v]);}}else if(wind_patch_gain<32768){wind_patch_gain+=74;if(wind_patch_gain>32768)wind_patch_gain=32768;}
  beam_sample();
  for(uint32_t k=0;k<WIND_VOICES;k++){
   wind_t *v=&wind[k];if(!v->on)continue;
   if(!i&&wind_patch==4)wind_formant_control(v);
   if(!(i&7u)){
    if(v->gate){if(v->env<16777216){uint64_t step=v->attack_frac+(uint64_t)wind_attack_step*8u;v->attack_frac=(uint32_t)step&65535u;v->env+=(uint32_t)(step>>16);if(v->env>16777216)v->env=16777216;}}
    else {if(!v->release_step)v->release_step=wind_release_step(v->env);uint64_t step=v->release_frac+(uint64_t)v->release_step*8u;v->release_frac=(uint32_t)step&65535u;uint32_t decrement=(uint32_t)(step>>16);if(v->env>decrement)v->env-=decrement;else {v->env=0;v->on=0;}}
   }
   /* Envelope and glide control at 8 samples; continuous ramps, two audio oscillators. */
   if(!(i&7u)){
    int32_t x=v->env>>9;v->gain_target=(x*x/32768)*(98304-2*x)/32768;
    v->gain_step=(v->gain_target-v->gain_env)/8;
    const int32_t left[3]={49152,32768,16384};int32_t pan_target=wind_count>1?left[k]:32768;wind_pan[k]+=(pan_target-wind_pan[k])/32;if(pan_target-wind_pan[k]<32&&pan_target-wind_pan[k]>-32)wind_pan[k]=pan_target;
    int32_t gain=v->gain_target*wind_smooth/32768*23170/32768/5*wind_norm/32768;if(wind_patch==7)gain=gain*(28672+wind_vowel/8)/32768;
    v->glt=gain*wind_pan[k]/65536;v->grt=gain*(65536-wind_pan[k])/65536;v->gld=(v->glt-v->gl)/8;v->grd=(v->grt-v->gr)/8;
    v->fm_index=9387+v->gain_target*3129/32768;
    int32_t d=(int32_t)v->target-(int32_t)v->inc;
    v->inc_step=(d> -2048&&d<2048)?d/8:d/2048;
   }
   v->gain_env+=v->gain_step;if((i&7u)==7)v->gain_env=v->gain_target;int32_t env=v->gain_env;
   if((uint32_t)env>wind_strength)wind_strength=(uint32_t)env;
   v->inc=(uint32_t)((int32_t)v->inc+v->inc_step);
   if(!(i&7u)){int32_t d=(int32_t)v->target-(int32_t)v->inc;if(d>-8&&d<8)v->inc=v->target;v->detune=(v->inc/1000)*1003+(v->inc%1000)*1003/1000;}
   v->p+=v->inc;v->q+=v->detune;
   int32_t tone;
   if(!(i&1u)){
   if(wind_patch==4){int32_t a=wind_formant(v->p,v,0),b=wind_formant(v->q,v,1);tone=(a*(32768-wind_vowel)+b*wind_vowel)/32768;}
   else {int32_t a=wind_wave(v->p,v->inc,(uint32_t)wind_patch),b=wind_wave(v->q,v->detune,(uint32_t)wind_patch);
    tone=wind_patch==1?a:(a*3+b)/4;
    if(wind_patch==2){int32_t bright=32768-(int32_t)(v->env>>9);tone=(tone*(16384+bright/2)+osc(v->p)*(16384-bright/2))/32768;}
    if(wind_patch==5)tone=tone*(28672+wind_vowel/8)/32768+(low-slow)/14;
    if(wind_patch==6)tone=(tone*7+(noise-slow)/6)/8;
   }
   v->tone_old=v->tone_now;v->tone_now=tone;
   }
   /* 22.05 kHz oscillator evaluation, linearly reconstructed at 44.1 kHz.
    * Pads trade ultrasonic detail for a fixed, smaller execution budget. */
   tone=(i&1u)?v->tone_now:(v->tone_old+v->tone_now)/2;
   v->gl+=v->gld;v->gr+=v->grd;if((i&7u)==7){v->gl=v->glt;v->gr=v->grt;}
   if(beam_gain[k]!=32768)tone=tone*beam_gain[k]/32768;if(wind_patch_gain!=32768)tone=tone*wind_patch_gain/32768;
   wind_l+=tone*v->gl/32768;wind_r+=tone*v->gr/32768;
  }

  l+=wind_l;r+=wind_r;
  vs+=send_q15((wind_l+wind_r)/2,send_gain[4][1]);
  int32_t stems[2]={ds/2,vs/2};for(uint32_t j=0;j<2;j++){int32_t y=stems[j]-send_dc_x[j]+eco_q16(send_dc_y[j],65350);send_dc_x[j]=stems[j];send_dc_y[j]=y;if(j)verb_output[i]=y;else delay_output[i]=y;}
  for(uint32_t c=0;c<2;c++){
   int32_t wx=(c?wind_r:wind_l)/2,wy=wx-wind_dc_x[c]+eco_q16(wind_dc_y[c],65350);
   wind_dc_x[c]=wx;wind_dc_y[c]=wy;wind_output[i*2+c]=wy;
   int32_t x=(int32_t)((c?r:l)/2),y=x-dc_x[c]+eco_q16(dc_y[c],65350);
   dc_x[c]=x;dc_y[c]=y;
   output[i*2+c]=limit(y,-32768,32767);
  }
 }
 return output;
}
