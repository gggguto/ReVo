/* SPDX-License-Identifier: GPL-3.0-only. One global 24 PPQN grid, 4/4 bars. */
#pragma once
#include <stdint.h>
#define REVO_SYNC_DIVISIONS 9u
static inline uint32_t revo_sync_ticks(uint32_t i){static const uint8_t n[]={96,48,24,12,6,3,8,4,2};return n[i<REVO_SYNC_DIVISIONS?i:2];}
static inline const char *revo_sync_label(uint32_t i){static const char *n[]={"1/1","1/2","1/4","1/8","1/16","1/32","1/8T","1/16T","1/32T"};return n[i<REVO_SYNC_DIVISIONS?i:2];}
