/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
#define ILHA_SAMPLE_HEADER 64u
#define ILHA_SAMPLE_CAP 65536u
#define ILHA_COMPRESSED_MAX_FRAMES 162816u
typedef struct {int16_t *pcm;uint32_t capacity,frames,expected,received,crc,bytes,encoding;uint8_t loading,valid;char name[32];} ilha_sample_t;
uint32_t ilha_sample_crc(const uint8_t *data,uint32_t n);
void ilha_sample_init(ilha_sample_t *s,int16_t *pcm,uint32_t capacity);
/* Caller must suspend audio and acknowledge quiescence for the entire transfer.
 * Invalid header preserves old sample. Accepted transfer reuses PCM, so abort
 * or bad payload leaves the sample unavailable (no rollback buffer). */
int ilha_sample_begin(ilha_sample_t *s,const uint8_t header[64],uint32_t size,uint32_t audio_suspended);
int ilha_sample_write(ilha_sample_t *s,uint32_t offset,const uint8_t *data,uint32_t n);
int ilha_sample_finish(ilha_sample_t *s);
void ilha_sample_abort(ilha_sample_t *s);
