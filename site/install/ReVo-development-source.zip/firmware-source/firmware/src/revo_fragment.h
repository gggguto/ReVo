/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
#define FRAGMENT_DIVIDER 13u
static inline uint32_t fragment_mask(uint32_t loop){return loop?0x7ffc000u:0x1fffu;}
static inline uint32_t fragment_action(uint32_t key){
 /* Left F3..F4, right G4..G5. Central F#4 is a silent illuminated divider. */
 static const uint8_t left[13]={0,8,1,9,2,10,3,4,11,5,12,6,7};
 static const uint8_t right[13]={0,8,1,9,2,3,10,4,11,5,6,12,7};
 return key<13?left[key]:key>13&&key<27?right[key-14]:13;
}
static inline const char *fragment_label(uint32_t action){
 static const char *names[]={"1/2","1/4","1/8","1/16","1/32","1/64","1/128","1/256","Reverse","Half","Double","1/8T","1/16T"};
 return action<13?names[action]:"Divider";
}
static inline uint32_t fragment_frames(uint32_t action,uint32_t bpm){
 if(bpm<40)bpm=40;if(bpm>240)bpm=240;
 uint32_t denominator=action<8?2u<<action:action==11?12u:24u;
 return (44100u*240u)/(bpm*denominator);
}
