/* SPDX-License-Identifier: GPL-3.0-only
 * SLOOP/Felucca FSMP layout and header-last commit; dedicated single-source adapter.
 * Copyright (C) 2026 Leo Kuroshita, Hügelton Instruments.
 */
#include "revo_sample_store.h"
#include "ilha_sample.h"
static uint32_t rs32(const uint8_t*p){return(uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void rsput(uint8_t*p,uint32_t n){for(uint32_t i=0;i<4;i++)p[i]=(uint8_t)(n>>(i*8));}
static uint32_t rscrc(uint32_t crc,const uint8_t*p,uint32_t n){for(uint32_t i=0;i<n;i++){crc^=p[i];for(uint32_t b=0;b<8;b++)crc=(crc>>1)^((crc&1)?0xedb88320u:0);}return crc;}
static int rsinfo(const uint8_t*h,uint32_t *frames,uint32_t *bytes){
 if(rs32(h)!=0x504d5346u||h[4]!=1||h[5]||h[6]!=1||h[7])return 0;
 *bytes=rs32(h+16);*frames=rs32(h+36);
 return *frames>=4&&*frames<=REVO_STORE_MAX_FRAMES&&*bytes==(*frames+1)/2&&rs32(h+32)==0&&rs32(h+40)==0&&rs32(h+44)==*frames-1&&rs32(h+48)==32768&&h[54]==0&&h[55]==0&&h[56]==0;
}
int revo_store_load(const revo_store_io*io,uint8_t out[64],uint8_t*pcm,uint32_t capacity){
 uint8_t h[480];uint32_t frames,bytes,crc=0xffffffffu;
 if(!io||!io->read||!out||!pcm||io->read(0,h,sizeof h))return -1;
 if(!rsinfo(h,&frames,&bytes))return 0;if(bytes>capacity)return -1;
 for(uint32_t off=0;off<bytes;off+=256){uint32_t n=bytes-off;if(n>256)n=256;if(io->read(512+off,pcm+off,n))return -1;crc=rscrc(crc,pcm+off,n);}
 if((crc^0xffffffffu)!=rs32(h+20))return -1;
 for(uint32_t i=0;i<64;i++)out[i]=0;
 const char *magic="ILHAWAV1";for(uint32_t i=0;i<8;i++)out[i]=(uint8_t)magic[i];
 rsput(out+8,2);rsput(out+12,22050);rsput(out+16,frames);rsput(out+20,rs32(h+20));
 for(uint32_t i=0;i<8;i++){uint8_t c=h[8+i];out[24+i]=(c>=32&&c<=126)?c:0;}
 rsput(out+60,ilha_sample_crc(out,60));return 1;
}
int revo_store_save(const revo_store_io*io,const uint8_t header[64],const uint8_t *pcm){
 if(!header||!pcm)return -1;
 const uint8_t magic[8]={'I','L','H','A','W','A','V','1'};for(uint32_t i=0;i<8;i++)if(header[i]!=magic[i])return -1;
 uint8_t h[480]={0},back[480],scratch[256];uint32_t frames=rs32(header+16),bytes=(frames+1)/2;
 if(!io||!io->read||!io->write||!io->erase||!pcm||rs32(header+8)!=2||rs32(header+12)!=22050||frames<4||frames>REVO_STORE_MAX_FRAMES||rs32(header+60)!=ilha_sample_crc(header,60)||rs32(header+20)!=ilha_sample_crc(pcm,bytes))return -1;
 rsput(h,0x504d5346u);h[4]=1;h[6]=1;for(uint32_t i=0;i<8;i++)h[8+i]=header[24+i];
 rsput(h+16,bytes);rsput(h+20,rs32(header+20));rsput(h+36,frames);rsput(h+44,frames-1);rsput(h+48,32768);h[52]=0xc0;h[53]=3;h[58]=127;
 if(io->erase(0))return -1;
 for(uint32_t off=0;off<bytes;off+=256){uint32_t n=bytes-off;if(n>256)n=256;uint32_t pos=512+off;if(!(pos&4095)&&io->erase(pos))return -1;if(io->write(pos,pcm+off,n))return -1;}
 /* Check actual flash content before publishing a valid header. */
 uint32_t crc=0xffffffffu;
 for(uint32_t off=0;off<bytes;off+=256){uint32_t n=bytes-off;if(n>256)n=256;if(io->read(512+off,scratch,n))return -1;crc=rscrc(crc,scratch,n);}
 if((crc^0xffffffffu)!=rs32(h+20))return -1;
 if(io->write(4,h+4,476)||io->write(0,h,4)||io->read(0,back,sizeof back))return -1;
 for(uint32_t i=0;i<480;i++)if(back[i]!=h[i])return -1;
 return 0;
}
int revo_store_clear(const revo_store_io*io){uint8_t h[4];if(!io||!io->erase||!io->read||io->erase(0)||io->read(0,h,4))return -1;for(uint32_t i=0;i<4;i++)if(h[i]!=255)return -1;return 0;}
