/* SPDX-License-Identifier: GPL-3.0-only
 * ReVo failure bus: one short stereo history, bounded repeats, tape and damage.
 * All integer; no grains, new source voices, allocation or sample-storage writes.
 * The recorder pauses during a skip to protect its slice from overwrite. The
 * source transport never pauses. No external Freeze: Fragments supplies the held-repeat gesture.
 */
#pragma once
#include <stdint.h>
#if !defined(ILHA_FM1_TARGET)
#include <string.h>
#endif
#define REVO_GLITCH_N 16384u
#define REVO_GLITCH_MASK (REVO_GLITCH_N-1u)
#if defined(ILHA_FM1_TARGET)
#define REVO_GLITCH_SECTION __attribute__((section(".pool")))
#else
#define REVO_GLITCH_SECTION
#endif
static int16_t revo_glitch_ring[REVO_GLITCH_N][2] REVO_GLITCH_SECTION;
typedef struct {
 uint32_t write,valid,rng,attempt,active,start,length,phase,remaining,events,turns;
 uint32_t wow,flutter,frames,damage_left,damage_kind,damage_events,damage_clock;
 int32_t wet,tape,damage,edge,previous[2];uint32_t sync;
} revo_glitch_t;
static revo_glitch_t revo_glitch;
static int32_t rg_bound(int32_t v,int32_t lo,int32_t hi){return v<lo?lo:v>hi?hi:v;}
/* Keep saturation out of caller range-folding: its folded numeric threshold
 * otherwise aliases the platform ROM-address audit range. */
static __attribute__((noinline)) int32_t rg_saturate(int32_t v){return rg_bound(v,-32768,32767);}
static uint32_t rg_random(void){uint32_t x=revo_glitch.rng;x^=x<<13;x^=x>>17;x^=x<<5;return revo_glitch.rng=x;}
static int32_t rg_triangle(uint32_t phase){int32_t p=(int32_t)(phase>>16);return p<16384?p*2:p<49152?65536-p*2:p*2-131072;}
static int32_t rg_lerp(int32_t a,int32_t b,uint32_t f){return a+(int32_t)(((int64_t)(b-a)*f)/65536);}
static void revo_glitch_reset(void){memset(&revo_glitch,0,sizeof revo_glitch);revo_glitch.rng=0x5245564fu;}
static void rg_start(uint32_t size,uint32_t repeats){
 revo_glitch_t *g=&revo_glitch;uint32_t len=size*441u/10u;
 if(len>g->valid)len=g->valid;if(len<2)return;
 uint32_t spare=g->valid-len,back=spare?rg_random()%(spare+1u):0;
 g->start=(g->write-len-back)&REVO_GLITCH_MASK;g->length=len;g->phase=0;
 g->remaining=repeats;g->active=1;g->events++;g->turns=0;
}
/* UI units: Chance/Mix/Tape/Damage 0..100, Size 10..300ms, Repeats1..16.
 * Idle opportunities100..780ms: low Chance has more breathing room; actual draw remains Chance/100.
 */
static void revo_glitch_sync(uint32_t on){on=!!on;if(on!=revo_glitch.sync){revo_glitch.sync=on;revo_glitch.attempt=0;}}
static void revo_glitch_clocked(int32_t *stereo,uint32_t n,const int32_t glitch[4],uint32_t beats){
 revo_glitch_t *g=&revo_glitch;
 uint32_t chance=(uint32_t)rg_bound(glitch[0],0,100),size=(uint32_t)rg_bound(glitch[1],10,300),repeats=(uint32_t)rg_bound(glitch[2],1,16);
 uint32_t interval=4410u+(10000u-chance*chance)*3u;
 int32_t mix=rg_bound(glitch[3],0,100)*32768/100;
 if(!chance&&!g->active&&!g->edge){
  g->attempt=0;g->wet+=rg_bound(mix-g->wet,-(int32_t)n*64,(int32_t)n*64);g->frames+=n;g->wow+=38957u*n;g->flutter+=701166u*n;
  for(uint32_t i=0;i<n;i++){for(uint32_t c=0;c<2;c++){int32_t v=rg_saturate(stereo[2*i+c]);revo_glitch_ring[g->write][c]=(int16_t)v;stereo[2*i+c]=v;}g->write=(g->write+1)&REVO_GLITCH_MASK;if(g->valid<REVO_GLITCH_N)g->valid++;}return;
 }
 for(uint32_t i=0;i<n;i++){
  int32_t input[2]={rg_bound(stereo[2*i],-32768,32767),rg_bound(stereo[2*i+1],-32768,32767)};
  if(!g->active){for(uint32_t c=0;c<2;c++)revo_glitch_ring[g->write][c]=(int16_t)input[c];g->write=(g->write+1)&REVO_GLITCH_MASK;if(g->valid<REVO_GLITCH_N)g->valid++;}
  if(!chance||!mix)g->attempt=0;
  else if(!g->active&&(g->sync?(i<32u&&((beats>>i)&1u)):++g->attempt>=interval)){g->attempt=0;if(g->valid>=441u&&rg_random()%100u<chance)rg_start(size,repeats);}
  g->wet+=rg_bound(mix-g->wet,-64,64);
  g->wow+=38957u;g->flutter+=701166u;g->frames++;
  
  uint32_t active=g->active;
  int32_t target=active?32768:0;g->edge+=rg_bound(target-g->edge,-256,256);

  for(uint32_t c=0;c<2;c++){
   int32_t live=input[c],wet=live;
   if(g->length){uint32_t j=g->phase>>16;if(j>=g->length)j=g->length-1;uint32_t next=j+1<g->length?j+1:0;
    wet=rg_lerp(revo_glitch_ring[(g->start+j)&REVO_GLITCH_MASK][c],revo_glitch_ring[(g->start+next)&REVO_GLITCH_MASK][c],g->phase&65535u);
   }else wet=live;
   int32_t result=live+(int32_t)(((int64_t)(wet-live)*g->edge*g->wet)/1073741824LL);
   stereo[2*i+c]=rg_bound(result,-32768,32767);
  }

  if(active){g->phase+=65536u;uint32_t end=g->length<<16;
   if(g->phase>=end){g->phase-=end;g->turns++;if(--g->remaining==0)g->active=0;}
  }
 }
}

static void revo_glitch_only(int32_t *stereo,uint32_t n,const int32_t glitch[4]){revo_glitch_clocked(stereo,n,glitch,0);}

/* Separate insert permits one timestamp per block, rather than per sample. */
static void revo_damage_process(int32_t *stereo,uint32_t n,const int32_t character[4]){
 revo_glitch_t *g=&revo_glitch;int32_t target=rg_bound(character[1],0,100)*256;
 if(!target&&!g->damage){g->damage_clock=(g->damage_clock+n)%2206u;g->damage_left=g->damage_left>n?g->damage_left-n:0;for(uint32_t c=0;c<2;c++)g->previous[c]=stereo[(n-1)*2+c];return;}
 for(uint32_t i=0;i<n;i++){
  g->damage+=rg_bound(target-g->damage,-16,16);
  if(g->damage_clock++>=2205u){g->damage_clock=0;if(g->damage>0&&rg_random()%100u<(uint32_t)(g->damage/512)){g->damage_left=8u+rg_random()%(16u+(uint32_t)g->damage/128u);g->damage_kind=rg_random()%3u;g->damage_events++;}}
  for(uint32_t c=0;c<2;c++){int32_t result=stereo[2*i+c];if(g->damage){int32_t amount=g->damage/256,driven=rg_saturate(result*(100+amount*3)/100),step=1<<(amount/10),broken=(driven/step)*step;
   if(g->damage_left){int32_t burst=!g->damage_kind?0:g->damage_kind==1?g->previous[c]:rg_bound(broken+((g->damage_events&1u)?1:-1)*amount*75,-32768,32767);broken+=rg_bound(burst-broken,-7500,7500)*3/20;}
   result+=(broken-result)*amount/100;}
   g->previous[c]=result;stereo[2*i+c]=rg_bound(result,-32768,32767);
  }if(g->damage_left)g->damage_left--;
 }
}
static void revo_glitch_process(int32_t *stereo,uint32_t n,const int32_t glitch[4],const int32_t character[4]){revo_glitch_only(stereo,n,glitch);revo_damage_process(stereo,n,character);}
