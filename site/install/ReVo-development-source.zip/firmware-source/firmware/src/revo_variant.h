/* SPDX-License-Identifier: GPL-3.0-only. Shared-source build variants. */
#pragma once
#ifndef REVO_BIOMA_ONLY
#define REVO_BIOMA_ONLY 0
#endif

#ifndef REVO_ECO_PARALLEL
#define REVO_ECO_PARALLEL REVO_BIOMA_ONLY
#endif

/* Combined builds may enter Bioma without disabling the machine chooser. */
#ifndef REVO_START_BIOMA
#define REVO_START_BIOMA REVO_BIOMA_ONLY
#endif
