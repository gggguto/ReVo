/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* I2S output (ALNK0 -> external codec) and the audio ISR: each half buffer is
 * rendered in blocks of CTL samples by mix_block (fx.c: events -> each synth part
 * -> dist -> level / pan -> sends -> drums -> buses -> master), then scaled to 24-bit stereo. */
/* registers: hal/fm1_audio.h */
#define HALF_WORDS (HALF_FRAMES * 2u)
#define OUT_SHIFT 7               /* Q15 -> 24-bit, -6 dBFS ceiling */

static int32_t abuf[2u * HALF_WORDS] __attribute__((aligned(4)));

/* diagnostics, kept across resets and UBOOT entry: read with `fm1t memr` */
#define DBG_MAGIC 0x44424731u                       /* "DBG1" */
struct felucca_dbg {
    uint32_t magic, halves, max_us, nested;
    volatile uint32_t in_audio;           /* TIMER5 reads it to decide what may nest in the render */
    uint32_t late, timer_irqs, ui_frames;
    uint32_t last_us, cpu_q8, boots;
    uint32_t stage, page, home;           /* where the main loop is (breadcrumbs) */
    uint32_t prev_stage, prev_page, prev_home, prev_rst, prev_frames;   /* as found at boot */
} felucca_dbg __attribute__((section(".noinit")));
static volatile uint32_t audio_halves, audio_max_us;
static volatile uint32_t t5_nested_ticks;              /* TIMER4 ticks TIMER5 spent nested in this ISR (main.c) */
#define SCOPE_N 512u
static int16_t scope_buf[SCOPE_N], scope_bufr[SCOPE_N];   /* left, right (the visualiser): the mix at full level */
static uint32_t scope_w;

#include "revo_profile.inc"
static void audio_block(int32_t *out, uint32_t n)       /* mix (fx.c), then Q15 -> 24 bit */
{
    uint32_t i;
    uint32_t nested_start;uint32_t profile_start=revo_profile_stamp(&t5_nested_ticks,&nested_start);
    mix_block(out, n);
    uint32_t nested_end;uint32_t profile_end=revo_profile_stamp(&t5_nested_ticks,&nested_end);
    uint32_t wall=profile_end-profile_start,elapsed=wall-(nested_end-nested_start);
    uint32_t machine=ilha_audio_control.machine==ILHA_ECO?1u:0u;
    revo_profile.version=1;revo_profile.blocks[machine]++;revo_profile.last_ticks[machine]=elapsed;
    if(elapsed>revo_profile.max_ticks[machine])revo_profile.max_ticks[machine]=elapsed;
    if(wall>revo_profile.max_wall_ticks[machine])revo_profile.max_wall_ticks[machine]=wall;
    if(wall>n*FM1_TICKS_PER_US*1000000u/FS)revo_profile.over_nominal[machine]++;

#if FELUCCA_UAC
    uac_tap(usb_full_now ? usb_out : out, n);           /* the USB audio input: the master output, or at full level */
#endif
    for (i = 0; i < n; i++) {
        if (i & 1u)
        {
            scope_bufr[scope_w & (SCOPE_N - 1u)] = vis_tap[2u * i + 1u];   /* (fx.c: MASTER all the way up) */
            scope_buf[scope_w++ & (SCOPE_N - 1u)] = vis_tap[2u * i];
        }
        out[2u * i] <<= OUT_SHIFT;
        out[2u * i + 1u] <<= OUT_SHIFT;
    }
}

/* overload: shed_voice (voice.c) */
static volatile uint8_t shed_req;
static uint8_t shed_over;                      /* bit k: the half k halves ago was over 85 % */

void fm1_alnk0_irq(void)                       /* via isr_alnk0 (hal/fm1_isr.S) */
{
    uint8_t p;
    uint32_t t0;
    felucca_dbg.in_audio = 1;                   /* first: TIMER5 nests from here on (main.c) */
    p = fm1_audio_pending();
    t0 = fm1_ticks();
    t5_nested_ticks = 0;
    fm1_audio_ack_aux(p);
    if (p & FM1_AUDIO_HALF) {
        uint32_t half = fm1_audio_free_half(), b, us;
        int32_t *o = &abuf[half * HALF_WORDS];
        if (shed_req) {
            shed_req = 0;
            /* Dedicated engines: no legacy voice shedding. */
        }
#if FELUCCA_UAC
        uac_render_start();
        usb_full_now = (uint8_t)(usb_full && uac.feed);  /* menu USB AUDIO = FULL, while the computer records */
#endif
        for(uint32_t q=0;q<7;q++)revo_profile.half[q]=0;
        for(uint32_t q=0;q<6;q++)revo_profile.effect_half[q]=0;revo_profile.parallel[10]=revo_profile.parallel[11]=0;
        for(uint32_t q=0;q<4;q++)revo_profile.peak[q]=0;
        for (b = 0; b < HALF_FRAMES; b += CTL)
            audio_block(o + 2u * b, CTL);
        fm1_audio_ack_half();
        audio_halves++;
#if FELUCCA_CPU1
        cpu1_load_half(HALF_FRAMES * 1000000u / FS);     /* core 1's load and core 0's wait for it (fx.c) */
#endif
        {   /* the deadline sees the render and TIMER5 nested in it (the USB audio stream); the load
             * figures the render alone (after Felucca 1.0) */
            uint32_t nested;uint32_t all = revo_profile_stamp(&t5_nested_ticks,&nested) - t0;
            for(uint32_t q=0;q<7;q++)revo_profile.last[q]=revo_profile.half[q];
            revo_profile.effect_halves++;
            for(uint32_t q=0;q<6;q++){uint32_t t=revo_profile.effect_half[q];revo_profile.effect_last[q]=t;if(t>revo_profile.effect_max[q])revo_profile.effect_max[q]=t;revo_profile.effect_total_us[q]+=t/FM1_TICKS_PER_US;}
            for(uint32_t q=0;q<4;q++)revo_profile.last_peak[q]=revo_profile.peak[q];
            uint32_t work=(all-nested)/FM1_TICKS_PER_US;
            uint32_t new_worst=work>revo_profile.worst_us;
            if(new_worst){
             revo_profile.worst_us=work;revo_profile.worst_ms=fm1_ms;revo_profile.worst_frame=revo_profile.frames;
             for(uint32_t q=0;q<7;q++)revo_profile.worst[q]=revo_profile.half[q];
             for(uint32_t q=0;q<4;q++)revo_profile.worst_peak[q]=revo_profile.peak[q];
             revo_profile.worst_visual=revo_profile.visual_mode;for(uint32_t q=0;q<20;q++)revo_profile.parallel_worst[q]=revo_profile.parallel[q];revo_profile.parallel_worst[14]=ilha_audio_control.wind_env[0];revo_profile.parallel_worst[15]=ilha_audio_control.wind_env[1];
             for(uint32_t q=0;q<6;q++)revo_profile.effect_worst[q]=revo_profile.effect_half[q];
             revo_profile.worst_effect_state=revo_profile.effect_state;
             for(uint32_t q=0;q<12;q++)revo_profile.worst_sends[q]=(uint32_t)ilha_audio_control.eco_sends[q/2][q%2];
             uint32_t engine[8];ilha_eco_engine_diagnostics(engine);for(uint32_t q=0;q<8;q++)revo_profile.worst_engine[q]=engine[q];
             revo_profile.glitch_sync_worst=ilha_audio_control.glitch_sync;for(uint32_t q=0;q<2;q++)revo_profile.sync_worst[q]=revo_sync_config(q);
             uint32_t dual[40],decoder[8];revo_dual_config(dual);ilha_dual_diagnostics(decoder);for(uint32_t q=0;q<40;q++)revo_profile.dual_worst[q]=dual[q];for(uint32_t q=0;q<8;q++)revo_profile.decoder_worst[q]=decoder[q];
             uint32_t config[40];revo_profile_config(config);for(uint32_t q=0;q<40;q++)revo_profile.worst_config[q]=config[q];
            }
            all=revo_profile_stamp(&t5_nested_ticks,&nested)-t0;revo_profile.ui_audio_ticks+=all;
            if(new_worst)revo_profile.worst_us=(all-nested)/FM1_TICKS_PER_US;
            revo_half_wall_last=all/FM1_TICKS_PER_US;if(revo_half_wall_last>revo_half_wall_max)revo_half_wall_max=revo_half_wall_last;
            us = (all - nested) / FM1_TICKS_PER_US;
            if(ilha_audio_control.machine==ILHA_ECO){
             static uint32_t pressure,hot,cool;
             uint32_t wall_us=all/FM1_TICKS_PER_US;
             if(wall_us>4900u){cool=0;if(++hot>=2u){hot=0;if(pressure<2)pressure++;}}
             else if(wall_us<4100u){hot=0;if(++cool>=172u){cool=0;if(pressure)pressure--;}}
             else {hot=0;cool=0;}
             ilha_eco_pressure(pressure);
            }

            shed_over = (uint8_t)(shed_over << 1 | (all / FM1_TICKS_PER_US * 100u > (HALF_FRAMES * 1000000u / FS) * 85u));
        }
        if (us > audio_max_us)
            audio_max_us = us;
        if ((shed_over & 3u) == 3u)
            shed_req = 1;                               /* two in a row */
        song.cpu_q8 = (song.cpu_q8 * 15u + (us * 256u) / (HALF_FRAMES * 1000000u / FS)) / 16u;
        if (fm1_audio_free_half() != half)
            felucca_dbg.late++;                         /* the DMA moved on while we rendered */
        felucca_dbg.halves++;
        felucca_dbg.last_us = us;
        if (us > felucca_dbg.max_us)
            felucca_dbg.max_us = us;
        felucca_dbg.cpu_q8 = song.cpu_q8;
    }
    felucca_dbg.in_audio = 0;
}
extern void isr_alnk0(void);

static void audio_init(void)                   /* hal/fm1_audio.h */
{
    uint32_t i;
    for (i = 0; i < 2u * HALF_WORDS; i++)
        abuf[i] = 0;
    fm1_audio_init(abuf, HALF_WORDS, isr_alnk0, 3);
}
