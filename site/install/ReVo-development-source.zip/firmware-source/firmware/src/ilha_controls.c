/* SPDX-License-Identifier: GPL-3.0-only; dedicated UI model, no SLOOP core.h. */
#include "ilha_controls.h"
#include "revo_sync.h"
static int32_t bounded(int32_t old,int64_t delta,int32_t lo,int32_t hi){int64_t n=(int64_t)old+delta;return n<lo?lo:n>hi?hi:(int32_t)n;}
int ilha_landing_bind(ilha_controls_t *c,uint32_t q,uint32_t slot,uint32_t crc,uint32_t frames,uint32_t bytes){
 if(q>1||slot>3)return 0;ilha_landing_bank_t *b=&c->landing[q][slot];if(b->crc==crc&&b->frames==frames&&b->bytes==bytes)return 0;
 uint32_t had=b->mask;*b=(ilha_landing_bank_t){.crc=crc,.frames=frames,.bytes=bytes};if(had){c->landing_revision++;c->landing_pending=1;}return 1;
}
void ilha_controls_init(ilha_controls_t *c){*c=(ilha_controls_t){
#if REVO_START_BIOMA
.machine=ILHA_ECO,
#endif
.beam={0,4,2,0},.resonance_sources=7,.eco_parallel=1,.eco_sends={{100,100},{100,100},{100,100},{0,100},{0,100},{0,100}},.heads={{20,23,100,100,-50},{70,20,75,100,50}},.eco_level={75,45,70,20},.fx={0,50,0,0},.fx_extra={0,0,0,300},.glitch={0,80,3,50},.character={0,0,0,50},.echo={0,250,35,0},.space={0,0,50,0},.ice=1,.fx_route=2,.dual_bpm=100,.sync={{0,2,0,0},{0,2,0,0}},.wander={{0,50,1,0,3},{0,50,1,0,3}},.vformation={{0,4,0,100},{0,4,0,100}},.weather={50,0,0},.response={0,50},.distance={{20,0,70,0},{60,0,70,0},{40,0,70,0}},.drift={0,3,3,0},.resonance={0,35,50,1},.resonance_balance={50,0,3},.eco_global={0,100,16,65},.wind_env={1270,3170},.bed_lfo={200,0},.wind={70,0},.eco_density=50,.eco_register={35,20,50},.eco_seed=42,.eco_cycle=2,.family_cycle={2,2,2},.family_activity={100,100,100},.listen=100,.lfos={{350,35,0,1,0,0},{200,50,2,2,0,0}}};}
int ilha_controls_page(ilha_controls_t *c,uint32_t page){
#if REVO_BIOMA_ONLY
 if(page==ILHA_MACHINE)return 0;c->machine=ILHA_ECO;
#endif
if(page>=ILHA_PAGES||page==ILHA_SAVE||page==ILHA_PRESETS)return 0;if(c->machine==ILHA_DUAL&&(page==ILHA_WEATHER||page==ILHA_RESPONSE||page==ILHA_DISTANCE||page==ILHA_DRIFT||page==ILHA_RESONANCE))return 0;if(c->machine==ILHA_ECO&&(page==ILHA_WANDER||page==ILHA_LANDING||page==ILHA_VFORMATION||page==ILHA_MOTION))return 0;if(c->machine==ILHA_DUAL&&page==ILHA_EDIT)page=ILHA_WAVE;if(c->machine==ILHA_ECO&&(page==ILHA_WAVE||page==ILHA_SAMPLE||page==ILHA_FRAGMENT||page==ILHA_FRAGMENT_ENV||page==ILHA_LOOP_SHAPE))return 0;if(c->machine==ILHA_DUAL&&(page==ILHA_WIND||page==ILHA_SAVE||page==ILHA_PRESETS))return 0;if(page!=ILHA_WAVE||c->page!=ILHA_WAVE)c->sync_panel=0;if(c->machine==ILHA_ECO&&page==ILHA_EDIT&&c->page!=ILHA_EDIT)c->eco_activity_page=0;c->page=(uint8_t)page;return 1;}
void ilha_controls_home(ilha_controls_t *c,uint32_t held){c->sync_panel=0;c->page=held?ILHA_MENU:ILHA_HOME;}
void ilha_controls_select_loop(ilha_controls_t *c,uint32_t loop){if(c->machine==ILHA_DUAL&&loop<2)c->loop=(uint8_t)loop;}
const char *ilha_controls_label(const ilha_controls_t *c,uint32_t k){
 static const char *loop[4]={"START","SIZE","SPEED","LEVEL"},*eco[4]={"BIRDS","INSECTS","WATER","WATER BED"};
 if(k>3)return "";
 if(c->machine==ILHA_ECO&&c->page==ILHA_HOME&&k==3)return "Density";
 if(c->page==ILHA_LOOP_SHAPE){static const char *v[]={"Fade In","Fade Out","Filter",""};return v[k];}
 if(c->machine==ILHA_DUAL&&c->page==ILHA_WAVE&&c->sync_panel){static const char *s[]={"Sync","Division","Between","Launch"};return s[k];}
 if(c->page==ILHA_DISTANCE){static const char *v[]={"Distance","Motion","Width","Enabled"};return v[k];}
 if(c->machine==ILHA_ECO&&c->page==ILHA_WEATHER){static const char *v[]={"Depth","Length","Space","Mode"};return v[k];}
 if(c->page==ILHA_DRIFT){static const char *v[]={"Amount","Period","Range","Hold"};return v[k];}
 if(c->page==ILHA_RESONANCE){static const char *v[]={"Level","Material","Decay","Tuning"},*b[]={"Mix","Object","",""};return c->resonance_page==2?(k==0?"Source":k==1?"Delay":k==2?"Reverb":""):c->resonance_page?b[k]:v[k];}
 if(c->page==ILHA_FRAGMENT_ENV)return k==0?"Attack":k==1?"Release":"";
 if(c->page==ILHA_VFORMATION){static const char *v[]={"Action","Chance","Every","Link"};return v[k];}
 if(c->page==ILHA_LANDING)return k==0?"Position":k==1?"Point":k==3?"Mode":"";
 if(c->page==ILHA_WANDER)return k==0?"Flight":k==1?"Chance":k==2?"Repeats":"Mode";
 if(c->page==ILHA_WEATHER)return k==0?"Intensity":k==1?"Movement":"";
 if(c->page==ILHA_RESPONSE)return k==0?"Amount":k==1?"Spacing":"";
 if(c->page==ILHA_MOTION)return loop[k];
 if(c->machine==ILHA_ECO&&c->page==ILHA_EDIT){if(c->eco_activity_page)return k==0?"Activity":k==1?"Delay":k==2?"Reverb":"";return k==0?"Level":k==1?"Species":k==2?"Cycle":"Mode";}
if(c->machine==ILHA_DUAL&&c->page==ILHA_GLO){static const char *mix[4]={"Gain","Pan A","Pan B","BPM"};return mix[k];}if(c->machine==ILHA_ECO&&c->page==ILHA_LFO){static const char *o[4]={"Level","Depth","Speed","Shape"};return o[k];}if(c->machine==ILHA_DUAL&&c->page==ILHA_LFO){static const char *l[4]={"DEPTH","SPEED","Route","Target"};return l[k];}if(c->page==ILHA_SETTINGS)return k==0?"MIDI CLOCK":k==1?"MIDI CONTROL":"";if(c->machine==ILHA_ECO&&c->page==ILHA_GLO){static const char *g[4]={"Density","Variety","Seed","BPM"};return g[k];}if(c->machine==ILHA_ECO&&c->page==ILHA_WIND){static const char *w[4]={"Level","Preset","","FX"};return w[k];}if(c->page==ILHA_FX){static const char *labels[3][4]={{"Chance","Size","Repeats","Mix"},{"Damage","Time","Feedback","Delay Mix"},{"Filter","Reverb","Decay","Tape"}};return labels[c->fx_page%3][k];}if(c->page==ILHA_HOME||c->page==ILHA_WAVE||c->page==ILHA_EDIT)return c->machine==ILHA_DUAL?loop[k]:eco[k];return "";
}
int ilha_controls_knob(ilha_controls_t *c,uint32_t k,int32_t delta){
 if(k>3)return 0;
 if(c->machine==ILHA_DUAL&&c->page==ILHA_LOOP_SHAPE){if(k>2)return 0;c->loop_shape[c->loop][k]=bounded(c->loop_shape[c->loop][k],k==1?-(int64_t)delta:delta,k==2?-100:0,k==2?100:50);return 1;}
 if(c->machine==ILHA_DUAL&&c->page==ILHA_WAVE&&c->sync_panel){c->sync[c->loop][k]=(uint32_t)bounded((int32_t)c->sync[c->loop][k],delta,0,k==1?REVO_SYNC_DIVISIONS-1:k==3?2:1);return 1;}
 if(c->machine==ILHA_ECO&&c->page==ILHA_DISTANCE){int32_t *v=c->distance[c->eco_family%3];v[k]=bounded(v[k],delta,0,k==3?1:100);return 1;}
 if(c->machine==ILHA_ECO&&c->page==ILHA_WEATHER){c->beam[k]=bounded(c->beam[k],delta,k==1?1:0,k==0?100:k==1?16:k==2?5:1);return 1;}
 if(c->machine==ILHA_ECO&&c->page==ILHA_DRIFT){c->drift[k]=bounded(c->drift[k],delta,0,k==0?100:k==1?6:k==2?12:1);return 1;}
 if(c->machine==ILHA_ECO&&c->page==ILHA_RESONANCE){if(c->resonance_page==2){if(k==0){c->resonance_source_cursor=(uint32_t)bounded(c->resonance_source_cursor,delta,0,2);return 1;}if(k>2)return 0;c->eco_sends[3][k-1]=bounded(c->eco_sends[3][k-1],delta,0,100);return 1;}if(c->resonance_page){if(k>=2)return 0;c->resonance_balance[k]=bounded(c->resonance_balance[k],delta,0,k==0?100:3);}else c->resonance[k]=bounded(c->resonance[k],delta,0,k==3?1:100);return 1;}
 if(c->page==ILHA_FRAGMENT_ENV){if(k>1)return 0;c->fragment_env[c->loop][k]=bounded(c->fragment_env[c->loop][k],(int64_t)delta*(k?20:10),0,k?5000:2000);return 1;}
 if(c->page==ILHA_VFORMATION){uint32_t *v=c->vformation[c->loop];static const uint8_t map[4]={2,3,1,0};uint32_t at=map[k];if(k==0){int action=bounded(v[2]==2?1:0,delta,0,1);v[2]=action?2:0;return 1;}v[at]=(uint32_t)bounded((int32_t)v[at],delta,at==1?1:0,at==0?1:at==1?32:at==2?2:100);if(v[0])c->wander[c->loop][3]=0;return 1;}
 if(c->page==ILHA_LANDING){uint32_t q=c->loop;if(k==2)return 0;if(k==0)c->landing_position[q]=(uint32_t)bounded((int32_t)c->landing_position[q],(int64_t)delta*64,0,(100-c->heads[q].size)*65536/100);else if(k==1)c->landing_point[q]=(uint32_t)bounded((int32_t)c->landing_point[q],delta,0,7);else {c->landing_mode[q]=(uint32_t)bounded((int32_t)c->landing_mode[q],delta,0,2);if(c->landing_mode[q])c->wander[q][3]=0;}return 1;}
 if(c->page==ILHA_WANDER){if(c->vformation[c->loop][0]&&(k!=0||c->landing_mode[c->loop]))return 0;if(!k&&c->landing_mode[c->loop])return 0;int32_t *v=c->wander[c->loop];if(k==0&&v[3])v[4]=bounded(v[4],delta,0,12);else v[k]=bounded(v[k],delta,k==2?1:0,k==2?32:k==3?1:100);if(k==3&&v[3])c->landing_mode[c->loop]=0;return 1;}
 if(c->page==ILHA_WEATHER||c->page==ILHA_RESPONSE){if(k>1)return 0;int32_t *v=c->page==ILHA_WANDER?c->wander[c->loop]:c->page==ILHA_WEATHER?c->weather:c->response;v[k]=bounded(v[k],delta,0,100);return 1;}
 if(c->machine==ILHA_ECO&&c->harmony_page==2&&(c->page==ILHA_WIND||(c->page==ILHA_EDIT&&c->eco_family==4))){if(k>1)return 0;c->wind_env[k]=bounded(c->wind_env[k],(int64_t)delta*(k?50:20),k?20:10,k?20000:10000);return 1;}
 if(c->machine==ILHA_ECO&&c->harmony_page==1&&(c->page==ILHA_WIND||(c->page==ILHA_EDIT&&c->eco_family==4))){c->harmony[k]=bounded(c->harmony[k],delta,0,k==0?2:k==1?11:k==2?8:3);return 1;}
 if(c->machine==ILHA_ECO&&c->page==ILHA_LFO){if(k==0)c->eco_level[3]=bounded(c->eco_level[3],delta,0,100);else if(k==1)c->bed_lfo[1]=bounded(c->bed_lfo[1],delta,0,100);else if(k==2)c->bed_lfo[0]=bounded(c->bed_lfo[0],(int64_t)delta*20,20,10000);else if(k==3)c->bed_lfo[2]=bounded(c->bed_lfo[2],delta,0,5);else return 0;return 1;}

 if(c->machine==ILHA_DUAL&&c->page==ILHA_SAMPLE){if(k>1)return 0;c->sample_slot[k]=(uint32_t)bounded(c->sample_slot[k],delta,0,3);return 1;}
 if(c->machine==ILHA_DUAL&&c->page==ILHA_GLO){if(k==0)c->dual_gain=bounded(c->dual_gain,delta,0,12);else if(k<3)c->heads[k-1].pan=bounded(c->heads[k-1].pan,delta,-100,100);else if(!c->midi_source)c->dual_bpm=(uint32_t)bounded(c->dual_bpm,delta,40,240);else return 0;return 1;}

 if(c->machine==ILHA_DUAL&&c->page==ILHA_LFO){ilha_lfo_t *l=&c->lfos[c->lfo_selected&1u];if(k==0)l->depth=bounded(l->depth,delta,-100,100);else if(k==1)l->rate=bounded(l->rate,(int64_t)delta*10,20,10000);else if(k==2)l->route=bounded(l->route,delta,1,3);else l->dest=bounded(l->dest,delta,0,3);return 1;}if(c->page==ILHA_SETTINGS){if(!k)c->midi_source=(uint32_t)bounded((int32_t)c->midi_source,delta,0,2);else if(k==1)c->midi_control_source=(uint32_t)bounded((int32_t)c->midi_control_source,delta,0,3);else return 0;return 1;}
 if(c->machine==ILHA_ECO&&c->page==ILHA_EDIT){uint32_t f=c->eco_family%3;
  if(c->eco_activity_page){if(k==0)c->family_activity[f]=(uint32_t)bounded((int32_t)c->family_activity[f],delta,0,100);else if(k<3)c->eco_sends[f][k-1]=bounded(c->eco_sends[f][k-1],delta,0,100);else return 0;return 1;}
  if(k==0)c->eco_level[f]=bounded(c->eco_level[f],delta,0,100);
  else if(k==1){uint32_t i=f==1?2:f==2?1:0;c->eco_register[i]=bounded(c->eco_register[i],delta,0,100);}
  else if(k==2){if(!c->family_tame[f])return 0;c->family_cycle[f]=(uint32_t)bounded(c->family_cycle[f],delta,0,(int32_t)ilha_eco_cycle_count()-1);}
  else c->family_tame[f]=(uint32_t)bounded(c->family_tame[f],delta,0,1);return 1;
 }
 if(c->machine==ILHA_ECO&&c->page==ILHA_GLO){
  if(k==0)c->eco_density=bounded(c->eco_density,delta,0,100);
  else if(k==1)c->eco_global[3]=bounded(c->eco_global[3],delta,0,100);
  else if(k==2)c->eco_seed=(uint32_t)bounded((int32_t)c->eco_seed,delta,0,999);
  else if(!c->midi_source)c->eco_global[1]=bounded(c->eco_global[1],delta,40,240);else return 0;return 1;
 }
 if(c->machine==ILHA_ECO&&c->page==ILHA_WIND){if(k==3){c->wind_fx=(uint32_t)bounded(c->wind_fx,delta,0,1);return 1;}if(k>1)return 0;c->wind[k]=bounded(c->wind[k],delta,0,k==0?100:7);return 1;}
 if(c->page==ILHA_FX){int32_t *v=c->fx_page==1?c->echo:c->fx_page==2?c->space:c->glitch;
 if(c->fx_page==1&&k==1)v[k]=bounded(v[k],(int64_t)delta*10,10,1000);
 else if(!c->fx_page&&k==1)v[k]=bounded(v[k],(int64_t)delta*5,10,300);
 else v[k]=bounded(v[k],delta,c->fx_page==2&&k==0?-100:!c->fx_page&&k==2?1:0,!c->fx_page&&k==2?16:c->fx_page==1&&k==2?90:100);return 1;}

 if(c->machine==ILHA_ECO&&c->page==ILHA_HOME&&k==3){c->eco_density=bounded(c->eco_density,delta,0,100);return 1;}
 if(c->page!=ILHA_HOME&&c->page!=ILHA_WAVE&&c->page!=ILHA_EDIT&&c->page!=ILHA_MOTION)return 0;
 if(c->machine==ILHA_ECO){c->eco_level[k]=bounded(c->eco_level[k],delta,0,100);return 1;}
 ilha_loop_t *h=&c->heads[c->loop];
 if(k==0)h->start=bounded(h->start,delta,0,99);if(k==1){int32_t size=h->size;if(h->speed<0&&size>100-h->start)size=100-h->start;ilha_loop_size(h,bounded(size,delta,1,100));}if(k==2)h->speed=bounded(h->speed,delta,-200,200);if(k==3)h->level=bounded(h->level,delta,0,100);return 1;
}

static const char *cycles[]={"2/4","3/4","4/4","5/4","6/4","7/4","3/8","5/8","7/8","9/8","11/8","13/8","7/16","9/16","11/16","13/16","15/16","17/16","19/16"};
static const int32_t cycle_steps[]={8,12,16,20,24,28,6,10,14,18,22,26,7,9,11,13,15,17,19};
uint32_t ilha_eco_cycle_count(void){return sizeof cycle_steps/sizeof cycle_steps[0];}
const char *ilha_eco_cycle_label(uint32_t i){return cycles[i%ilha_eco_cycle_count()];}
int32_t ilha_eco_cycle_steps(uint32_t i){return cycle_steps[i%ilha_eco_cycle_count()];}

uint32_t ilha_drift_ticks(uint32_t index){return 4u<<(index>6?6:index);}
const char *ilha_drift_period_label(uint32_t index){static const char *s[]={"1 beat","2 beats","4 beats","8 beats","16 beats","32 beats","64 beats"};return s[index>6?6:index];}
