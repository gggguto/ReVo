/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
#include "revo_variant.h"
enum {ILHA_DUAL,ILHA_ECO};
enum {ILHA_HOME,ILHA_WAVE,ILHA_SAMPLE,ILHA_EDIT,ILHA_FX,ILHA_LFO,ILHA_WIND,ILHA_GLO,ILHA_SAVE,ILHA_PRESETS,ILHA_SETTINGS,ILHA_MENU,ILHA_MACHINE,ILHA_INFO,ILHA_FRAGMENT,ILHA_WANDER,ILHA_MOTION,ILHA_WEATHER,ILHA_RESPONSE,ILHA_FRAGMENT_ENV,ILHA_DISTANCE,ILHA_DRIFT,ILHA_RESONANCE,ILHA_LANDING,ILHA_VFORMATION,ILHA_LOOP_SHAPE,ILHA_PAGES};
typedef struct {int32_t start,size,speed,level,pan;} ilha_loop_t;
/* Positions are normalized sample coordinates, not copied audio. Separate A/B per sample slot. */
/* Size edits share one geometric rule for panel and MIDI. */
static inline void ilha_loop_size(ilha_loop_t *h,int32_t size){
 if(size<1)size=1;if(size>100)size=100;
 if(h->speed<0){int32_t right=h->start+h->size;if(right>100)right=100;if(size>right)size=right;h->start=right-size;}
 h->size=size;
}
typedef struct {uint32_t crc,frames,bytes,mask;uint16_t point[8];} ilha_landing_bank_t;
typedef struct {int32_t rate,depth,dest,route,shape,enabled;} ilha_lfo_t;
typedef struct {uint8_t machine,page,loop,playing;uint32_t dual_run[2],sync_panel,sync[2][4];ilha_loop_t heads[2];int32_t eco_level[4],fx[4],eco_global[4],wind[2];int32_t eco_density,eco_register[3];uint32_t eco_seed,eco_family,eco_glo_page,eco_cycle;uint32_t family_tame[3],family_cycle[3],family_activity[3],eco_activity_page;int32_t distance[3][4],drift[4],resonance[4],resonance_balance[3];uint32_t resonance_page;uint32_t wind_fx;int32_t eco_sends[6][2];uint32_t ocean_setup;int32_t listen,wind_octave;int32_t harmony[4],bed_lfo[3],wind_env[2];uint32_t harmony_page;uint32_t sample_slot[2];ilha_landing_bank_t landing[2][4];uint32_t vformation[2][4];uint32_t landing_mode[2],landing_position[2],landing_point[2],landing_revision,landing_pending;uint32_t fx_page,dual_glo_page,ice,fx_route;int32_t glitch[4],character[4],echo[4],space[4];int32_t fx_extra[4];uint32_t dual_bpm;int32_t dual_gain;int32_t wander[2][5],weather[3],response[2];uint32_t latched[2],motion_command,motion_revision;int32_t fragment_env[2][2];uint32_t notes,local_notes,midi_notes,midi_source,midi_control_source,lfo_selected;ilha_lfo_t lfos[2];uint32_t eco_parallel;int32_t beam[4];uint32_t resonance_sources,resonance_source_cursor;int32_t loop_shape[2][3];uint32_t glitch_sync;} ilha_controls_t;
int ilha_landing_bind(ilha_controls_t*,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t);
void ilha_controls_init(ilha_controls_t *c);
int ilha_controls_page(ilha_controls_t *c,uint32_t page);
void ilha_controls_home(ilha_controls_t *c,uint32_t held);
void ilha_controls_select_loop(ilha_controls_t *c,uint32_t loop);
/* Knob index 0..3, relative detents; values are UI units, no track/seq structures.
 * Physical adapter must queue changes for the audio thread; never mutate live PCM. */
int ilha_controls_knob(ilha_controls_t *c,uint32_t knob,int32_t delta);
const char *ilha_controls_label(const ilha_controls_t *c,uint32_t knob);

const char *ilha_eco_cycle_label(uint32_t index);
uint32_t ilha_eco_cycle_count(void);
int32_t ilha_eco_cycle_steps(uint32_t index);

uint32_t ilha_drift_ticks(uint32_t index);
const char *ilha_drift_period_label(uint32_t index);
