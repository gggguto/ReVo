/* SPDX-License-Identifier: GPL-3.0-only
 * ReVo boot identity. Existing SLOOP/Felucca attribution is retained.
 */
UI_SMALL static void sloop_splash(void)
{
 /* Same global text positions as the former120/36-row canvases. */
 for(uint32_t y=0;y<240;y+=30){
  cv_begin(240,30,C_BLACK);cv_oy=-(int32_t)y;
  cv_text(120-text_w(&FONT_S,"ReVo 1.0")/2,96,&FONT_S,"ReVo 1.0",C_WHITE);
  cv_text(120-text_w(&FONT_S,"based on SLOOP / Felucca")/2,202,&FONT_S,"based on SLOOP / Felucca",RGB(96,96,104));
  cv_blit(0,y);
 }
 cv_oy=0;lcd_sync();
}
