/* SPDX-License-Identifier: GPL-3.0-only
 * IMA tables/decoding derived from SLOOP/Felucca eng_sample.c.
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments.
 * ReVo indexed access adapter: no allocation, HAL, external service or flash writes.
 * Build checkpoints while audio is held, then keep compressed source immutable.
 */
#pragma once
#include <stdint.h>
#define REVO_IMA_RATE 22050u
#define REVO_IMA_MAX_FRAMES 162816u
#define REVO_IMA_STRIDE 256u
#define REVO_IMA_CHECKPOINTS ((REVO_IMA_MAX_FRAMES+255u)/256u)
typedef struct { int16_t pred; uint8_t idx, reserved; } revo_ima_state;
typedef struct { const uint8_t *data; uint32_t frames; revo_ima_state *states; } revo_ima_source;
/* One cache per head/read region. Last PCM entry is an interpolation guard:
 * the following block's first sample, without evicting this block. */
typedef struct { uint32_t block; uint8_t valid; int16_t pcm[257]; } revo_ima_cache;
int revo_ima_index(revo_ima_source *,const uint8_t *,uint32_t,uint32_t,revo_ima_state *,uint32_t);
int16_t revo_ima_at(const revo_ima_source *,revo_ima_cache *,uint32_t);

void revo_ima_pair(const revo_ima_source *,revo_ima_cache *,uint32_t,uint32_t,int32_t *,int32_t *);
