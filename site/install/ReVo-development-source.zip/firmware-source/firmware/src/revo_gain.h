/* SPDX-License-Identifier: GPL-3.0-only. Dual GLO makeup gain, before Master/limiter. */
#pragma once
static int32_t revo_gain_current=4096;
static const int32_t revo_gain_q12[13]={4096,4596,5157,5786,6492,7284,8173,9170,10289,11544,12953,14533,16306};
static void revo_gain_process(int32_t *l,int32_t *r,uint32_t n,int32_t db){
 if(db<0)db=0;if(db>12)db=12;int32_t target=revo_gain_q12[db];
 for(uint32_t i=0;i<n;i++){
  int32_t difference=target-revo_gain_current;revo_gain_current+=difference>16?16:difference< -16?-16:difference;
  /* bounded input, wide multiply; cap before the existing Master arithmetic */
  int64_t a=(int64_t)l[i]*revo_gain_current/4096,b=(int64_t)r[i]*revo_gain_current/4096;
  l[i]=(int32_t)(a>1048575?1048575:a< -1048575?-1048575:a);r[i]=(int32_t)(b>1048575?1048575:b< -1048575?-1048575:b);
 }
}
