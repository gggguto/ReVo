/* SPDX-License-Identifier: GPL-3.0-only
 * Historical prototype, NOT included by the current firmware (replaced by Ice).
 * Experimental +octave, two-window mono feedback for the stereo reverb.
 * No dry pitch shift: the shifted return is diffused again by the existing FDN.
 */
#pragma once
#include <stdint.h>
#define REVO_SHIMMER_RING 16384u
#define REVO_SHIMMER_WINDOW 8192u
#if defined(ILHA_FM1_TARGET)
#define REVO_SHIMMER_SECTION __attribute__((section(".pool")))
#else
#define REVO_SHIMMER_SECTION
#endif
static struct {int16_t ring[REVO_SHIMMER_RING];uint32_t w,phase;int32_t wet,lp,feedback[32];int64_t dc;} revo_shimmer REVO_SHIMMER_SECTION;
static int32_t shimmer_bound(int32_t v,int32_t lo,int32_t hi){return v<lo?lo:v>hi?hi:v;}
static void revo_shimmer_process(const int32_t *l,const int32_t *r,uint32_t n,uint32_t enabled,int32_t send){
 if(n>32)n=32;send=shimmer_bound(send,0,32768);
 for(uint32_t i=0;i<n;i++){
  revo_shimmer.wet+=shimmer_bound((enabled?32768:0)-revo_shimmer.wet,-64,64);
  revo_shimmer.ring[revo_shimmer.w]=(int16_t)(enabled?shimmer_bound((l[i]+r[i])/4,-32768,32767):0);
  revo_shimmer.phase=(revo_shimmer.phase-1u)&(REVO_SHIMMER_WINDOW-1u);
  if(!revo_shimmer.wet){revo_shimmer.feedback[i]=0;revo_shimmer.lp=0;revo_shimmer.dc=0;}
  else{
   uint32_t p=revo_shimmer.phase,q=(p+REVO_SHIMMER_WINDOW/2)&(REVO_SHIMMER_WINDOW-1u);
   uint32_t a=(revo_shimmer.w-64u-p)&(REVO_SHIMMER_RING-1u),b=(revo_shimmer.w-64u-q)&(REVO_SHIMMER_RING-1u);
   int32_t weight=(int32_t)(p<REVO_SHIMMER_WINDOW/2?p:REVO_SHIMMER_WINDOW-p)*8;
   int32_t shifted=(int32_t)(((int64_t)revo_shimmer.ring[a]*weight+(int64_t)revo_shimmer.ring[b]*(32768-weight))/32768)*2;
   revo_shimmer.dc+=((int64_t)shifted*65536-revo_shimmer.dc)/1024;
   int32_t high=shifted-(int32_t)(revo_shimmer.dc/65536);revo_shimmer.lp+=(high-revo_shimmer.lp)/2;
   int32_t v=(int32_t)((int64_t)revo_shimmer.lp*revo_shimmer.wet/32768);
   revo_shimmer.feedback[i]=shimmer_bound((int32_t)((int64_t)v*send/131072),-32768,32767);
  }
  revo_shimmer.w=(revo_shimmer.w+1u)&(REVO_SHIMMER_RING-1u);
 }
}
