/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include "ilha_controls.h"
typedef struct {uint32_t knob_at[4],knob_context[4];int8_t knob_dir[4];uint8_t knob_seen[4];uint32_t glitch_events,glitch_active,glitch_turns,glitch_frames,glitch_wow,glitch_damage_events,glitch_pulse,glitch_damage_pulse,glitch_valid;uint32_t play_at,play_down,transport_open,transport_blocked,transport_keys,transport_state[2];uint32_t home_at,hud_at;uint8_t home_down,home_long,hud,menu,machine_choice;int32_t hud_value,bed_held;char message[32],chord_name[16];int8_t scope[96];uint32_t scope_phase[2],scope_seed[2],scope_valid;int32_t scope_held[2];uint32_t previous_notes,performance_key[2];uint32_t clock_bpm,clock_locked;char sample_names[2][12];uint32_t position[2],bed_phase,bed_seed,wind,motion_ms,tick_at;uint32_t eco_grid[3],eco_opportunities[3],eco_grid_seen[3],eco_grid_pulse[3],eco_status[3];uint32_t eco_events[3],eco_pulse[3],eco_ticks,eco_step,eco_beat;uint32_t raw_previous;uint8_t landing_action,sel_down,sel_used,sel_home,motion_action;uint32_t motion_state,motion_count,motion_cursor,motion_target;int16_t motion_trace[4][64],motion_values[4];uint32_t v_notice_at,v_notice_loop,v_notice;uint32_t v_turns[2],v_events[2],v_seen[2],v_pulse[2],v_status[2];uint32_t wander_pos[2],flock_turns[2],flock_previous[2];int32_t flock_pitch[2],flock_previous_pitch[2];uint32_t fragment_gain[2],fragment_stage[2],fragment_progress[2];int32_t distance_depth[3],distance_pan[3];uint8_t drift_trace[3][48];uint32_t drift_cursor,drift_changes,resonance_env,resonance_events,resonance_object,resonance_material,resonance_age;uint32_t beam_visual[8];uint32_t weather_intensity,response_family;uint8_t eco_valid;uint8_t tick_valid;} ilha_ui_t;
enum {IU_HOME,IU_EDIT,IU_FX,IU_SAMPLE,IU_LFO,IU_GLO,IU_SAVE,IU_PRESETS,IU_PLAY,IU_CONFIRM,IU_ARP,IU_SEQ,IU_REC,IU_ENV};
typedef struct {void *ctx;void (*rect)(void*,int,int,int,int,uint16_t);void (*line)(void*,int,int,int,int,uint16_t);void (*text)(void*,int,int,const char*,uint16_t);void (*large)(void*,int,int,const char*,uint16_t);void (*key)(void*,int,int,const char*,uint16_t);void (*vertical)(void*,int,int,const char*,uint16_t);int clip_y,clip_h;} ilha_draw_t;
void ilha_ui_init(ilha_ui_t *u);
int ilha_ui_keys(ilha_ui_t *u,ilha_controls_t *c,uint32_t notes,uint32_t select_down);
void ilha_ui_home(ilha_ui_t *u,ilha_controls_t *c,uint32_t down,uint32_t now);
void ilha_ui_tick(ilha_ui_t *u,ilha_controls_t *c,uint32_t now);
int ilha_ui_button(ilha_ui_t *u,ilha_controls_t *c,uint32_t button,uint32_t now);
void ilha_ui_select(ilha_ui_t *u,ilha_controls_t *c,int32_t steps);
void ilha_ui_knob(ilha_ui_t *u,ilha_controls_t *c,uint32_t knob,int32_t steps,uint32_t now);
void ilha_ui_render(const ilha_ui_t *u,const ilha_controls_t *c,const char *sample,uint32_t frames,const int16_t wave[120],uint32_t now,const ilha_draw_t *draw);

void ilha_ui_algorithm(ilha_ui_t *u,ilha_controls_t *c,int32_t steps);

/* Generate the display once per frame, outside audio IRQ and LCD strip loop. */
void ilha_ui_scope(ilha_ui_t *u,const ilha_controls_t *c,uint32_t phase,uint32_t seed,int32_t held);

void ilha_ui_preset(ilha_ui_t*,ilha_controls_t*,int32_t,uint32_t);

void ilha_ui_ecosystem(ilha_ui_t*,const ilha_controls_t*,const uint32_t events[3],uint32_t ticks,uint32_t step);

void ilha_ui_play(ilha_ui_t*,ilha_controls_t*,uint32_t,uint32_t);
