/* SPDX-License-Identifier: GPL-3.0-only. Half-cosine random glide, Q15. */
#pragma once
#include <stdint.h>
static inline int32_t revo_drift(uint32_t phase,int32_t from,int32_t to){
 static const uint16_t ease[33]={0,79,315,705,1247,1935,2761,3719,4799,5990,7282,8661,10114,11628,13188,14778,16384,17990,19580,21140,22654,24107,25486,26778,27969,29049,30007,30833,31521,32063,32453,32689,32768};
 uint32_t i=phase>>27,f=(phase>>11)&65535u;
 int32_t a=ease[i]+(int32_t)((uint32_t)(ease[i+1]-ease[i])*f/65536u);
 return from+(int32_t)((int64_t)(to-from)*a/32768);
}
