/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
void ilha_dual_init(void);
/* Call only while audio rendering is suspended to replace PCM. */
int16_t *ilha_dual_pcm(void);
void ilha_dual_commit(uint32_t frames);
void ilha_dual_play(uint32_t on);
void ilha_dual_wander(uint32_t k,int32_t amount,int32_t chance);
void ilha_dual_flock(uint32_t k,uint32_t repeats);
void ilha_dual_vformation(uint32_t,uint32_t,uint32_t,uint32_t,uint32_t);
void ilha_dual_vformation_motion(uint32_t,uint32_t);
void ilha_dual_vformation_visual(uint32_t,uint32_t*,uint32_t*,uint32_t*);
void ilha_dual_landing(uint32_t,uint32_t,uint32_t,const uint16_t*);
void ilha_dual_flock_mode(uint32_t k,uint32_t mode,uint32_t range);
void ilha_dual_flock_pitch(uint32_t k,int32_t *pitch,int32_t *previous);
void ilha_dual_flock_visual(uint32_t k,uint32_t *turns,uint32_t *previous);
void ilha_dual_fragment(uint32_t notes,uint32_t loop,uint32_t bpm);
void ilha_dual_head(uint32_t k,int32_t start,int32_t span,int32_t speed,int32_t gain,int32_t pan);
void ilha_dual_lfo(uint32_t k,int32_t shape,int32_t rate_mhz,int32_t amount,int32_t mask,int32_t dest);
/* n=1..32 stereo frames, interleaved signed Q15 in int32 slots; returns 0 if invalid. */
void ilha_dual_fx_route(uint32_t route);
uint32_t ilha_dual_render_fx(int32_t *out,int32_t *bypass,uint32_t n);
uint32_t ilha_dual_render(int32_t *out,uint32_t n);

/* Read only with audio IRQ excluded; no DSP mutation. */
uint32_t ilha_dual_phase(uint32_t k);
uint32_t ilha_dual_seed(uint32_t k);
int32_t ilha_dual_held(uint32_t k);
uint32_t ilha_dual_position(uint32_t k);

/* Held-audio only. IMA source at 22050 Hz, max 7.38 seconds. */
int ilha_dual_commit_ima(uint32_t frames);
int16_t ilha_dual_sample_at(uint32_t frame);

int ilha_dual_second_source(const uint8_t*,uint32_t,uint32_t);

int16_t ilha_dual_head_sample_at(uint32_t,uint32_t);

uint32_t ilha_dual_window(uint32_t);

int ilha_dual_replace_sources(uint32_t,const uint8_t*,uint32_t,uint32_t,uint32_t);

void ilha_dual_fragment_env(uint32_t,uint32_t,uint32_t);
void ilha_dual_fragment_clear(void);
void ilha_dual_env_visual(uint32_t,uint32_t*,uint32_t*,uint32_t*);

void ilha_dual_play_head(uint32_t,uint32_t);
void ilha_dual_sync(uint32_t,uint32_t,uint32_t,uint32_t,uint32_t);
void ilha_dual_clock(uint32_t,uint32_t);
void ilha_dual_clock_reset(void);
void ilha_dual_clock_pulse(void);
uint32_t ilha_dual_transport_state(uint32_t);

void ilha_dual_recover(void);
void ilha_dual_shape(uint32_t,int32_t,int32_t,int32_t);

void ilha_dual_diagnostics(uint32_t out[8]);

uint32_t ilha_dual_beat_mask(void);
