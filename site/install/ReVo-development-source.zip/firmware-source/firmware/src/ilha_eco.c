/* SPDX-License-Identifier: GPL-3.0-only
 * 128-frame synthesis blocks consumed by 32-frame FM-1 callbacks.
 * Audio-thread only. Physical key 0 is MIDI F3 (53). No heap or storage.
 */
#include "ilha_eco.h"
#include "ecosystem_q15.c"
static uint32_t offset=128,keys,play_on,ilha_eco_beats;
uint32_t ilha_eco_beat_mask(void){return ilha_eco_beats;}
static int32_t *block;
static int32_t wind_octave,wind_send;
static int32_t harmony_mode,harmony_key,harmony_scale,harmony_type;
static uint8_t generated[4];static uint32_t generated_n,chord_root;
static char generated_name[16];
void ilha_eco_init(void){engine_pressure=engine_guard_events=engine_wind_releases=0;for(uint32_t f=0;f<6;f++)for(uint32_t j=0;j<2;j++)send_gain[f][j]=send_target[f][j]=0;for(uint32_t j=0;j<2;j++)send_dc_x[j]=send_dc_y[j]=0;eco_init(42);external_mode=0;eco_external_reset();offset=128;wind_send=0;keys=play_on=0;wind_octave=0;harmony_mode=harmony_key=harmony_scale=harmony_type=0;generated_n=0;generated_name[0]=0;block=output;}
void ilha_eco_beam(const int32_t p[4]){beam_depth=limit(p[0],0,100);beam_length=(uint32_t)limit(p[1],1,16);beam_space=(uint32_t)limit(p[2],0,5);beam_wild=!!p[3];}
void ilha_eco_beam_visual(uint32_t out[8]){out[5]=beam_history[0];out[6]=beam_history[1];out[7]=beam_history[2];out[0]=beam_events;out[1]=beam_index;out[2]=beam_mask;out[3]=beam_gain[0];out[4]=beam_remaining;}
void ilha_eco_resonance_sources(uint32_t mask){resonance_source_mask=mask&7u;}
void ilha_eco_play(uint32_t on){on=!!on;if(on!=play_on){beam_remaining=beam_index=beam_elapsed=beam_clock_frames=beam_clock_started=beam_wait_frames=0;beam_mask=0;}if(external_mode&&on!=play_on)eco_external_reset();play_on=on;eco_play(on);}
void ilha_eco_living(int32_t i,int32_t m,int32_t on,int32_t a,int32_t s){eco_living(i,m,on,a,s);}
uint32_t ilha_eco_weather(void){return (uint32_t)weather_current;}
void ilha_eco_param(uint32_t id,int32_t value){if(id==8&&!!value!=params[8])eco_external_reset();eco_param(id,value);}
void ilha_eco_wind(uint32_t id,int32_t value){
 if(id==2){
  value=value < -2 ? -2 : value > 2 ? 2 : value;
  if(value!=wind_octave){ilha_eco_keys(0);wind_octave=value;}
 }else if(id>=12&&id<=15){
  int32_t *field=id==12?&harmony_mode:id==13?&harmony_key:id==14?&harmony_scale:&harmony_type;
  if(*field!=value){ilha_eco_keys(0);*field=value;}
  eco_wind_param(id,value);
 }else eco_wind_param(id,value);
}
void ilha_eco_keys(uint32_t mask){
 mask&=0x7ffffffu;
 /* In HOLD, note-off edges update physical state but retain the last complete
  * voicing. New note-on edges replace/rebuild it, including chord-key mode. */
 if(drift_hold&&!(mask&~keys)){keys=mask;return;}
 uint8_t next[4];uint32_t n=0;
 if(harmony_mode==2&&mask){
  uint32_t newly=mask&~keys;if(newly){for(uint32_t k=0;k<27;k++)if(newly&(1u<<k))chord_root=k;}
  else if(!(mask&(1u<<chord_root)))for(uint32_t k=0;k<27;k++)if(mask&(1u<<k))chord_root=k;
  n=rh_chord(53+(int)chord_root+12*wind_octave,harmony_key,harmony_scale,harmony_type,next);
  rh_name(next,n,harmony_type,generated_name);
  /* Three-note seventh voicing keeps root, third and seventh. */
  if(n>WIND_VOICES){next[2]=next[3];n=WIND_VOICES;}
 }else for(uint32_t k=0;k<27&&n<WIND_VOICES;k++)if(mask&(1u<<k)){
  int note=53+(int)k+12*wind_octave;if(harmony_mode==1)note=rh_quantize(note,harmony_key,harmony_scale);
  uint32_t found=0;for(uint32_t i=0;i<n;i++)found|=next[i]==note;if(!found)next[n++]=(uint8_t)note;
 }
 for(uint32_t i=0;i<generated_n;i++){uint32_t keep=0;for(uint32_t j=0;j<n;j++)keep|=generated[i]==next[j];if(!keep)eco_note(generated[i],0);}
 for(uint32_t j=0;j<n;j++){uint32_t keep=0;for(uint32_t i=0;i<generated_n;i++)keep|=generated[i]==next[j];if(!keep)eco_note(next[j],1);}
 if(harmony_mode==1&&n){static const char *names[]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};const char *note=names[harmony_key],*scale=rh_scale_names[harmony_scale];uint32_t k=0;for(uint32_t i=0;note[i]&&k<15;i++)generated_name[k++]=note[i];generated_name[k++]=' ';for(uint32_t i=0;scale[i]&&k<15;i++)generated_name[k++]=scale[i];generated_name[k]=0;}
 for(uint32_t j=0;j<n;j++)generated[j]=next[j];generated_n=n;keys=mask;
}
uint32_t ilha_eco_note_lights(void){
 uint32_t mask=0;for(uint32_t i=0;i<WIND_VOICES;i++)if(wind[i].on){int k=wind[i].drift_note-53-12*wind_octave;if(k>=0&&k<27)mask|=1u<<k;}return mask;
}
void ilha_eco_chord_name(char out[16]){uint32_t sounding=0;for(uint32_t i=0;i<WIND_VOICES;i++)sounding|=wind[i].on;for(uint32_t i=0;i<16;i++)out[i]=harmony_mode&&sounding?generated_name[i]:0;}

uint32_t ilha_eco_render_split(int32_t *out,int32_t *bypass,int32_t *send_bus,uint32_t n,uint32_t send){
 if(!out||!bypass||!send_bus||!n||n>32)return 0;int32_t target=send?32768:0;
 for(uint32_t i=0;i<n;i++){
  if(offset==128){block=eco_render();offset=0;}wind_send+=limit(target-wind_send,-128,128);
  for(uint32_t c=0;c<2;c++){uint32_t at=offset*2+c;int32_t wet=(int32_t)((int64_t)wind_output[at]*wind_send/32768);out[i*2+c]=block[at]-wind_output[at]-ocean_output[offset];send_bus[i*2+c]=wet+ocean_output[offset];bypass[i*2+c]=wind_output[at]-wet;}offset++;
 }return 1;
}
/* Compatibility full-bus render for native tools, without a second synthesis. */
uint32_t ilha_eco_render_fx(int32_t *out,int32_t *bypass,uint32_t n,uint32_t send){int32_t wind_bus[64];if(!ilha_eco_render_split(out,bypass,wind_bus,n,send))return 0;for(uint32_t i=0;i<n*2;i++)out[i]+=wind_bus[i];return 1;}
uint32_t ilha_eco_render(int32_t *out,uint32_t n){
 if(!out||!n||n>32)return 0;
 for(uint32_t i=0;i<n;i++){
  if(offset==128){block=eco_render();offset=0;}
  out[i*2]=block[offset*2];out[i*2+1]=block[offset*2+1];offset++;
 }return 1;
}

void ilha_eco_clock(uint32_t on){eco_external_mode(on);}
void ilha_eco_clock_reset(void){eco_external_reset();}
void ilha_eco_clock_pulse(void){eco_external_pulse();}

uint32_t ilha_eco_wind_level(void){return eco_wind_level();}

void ilha_eco_seed_live(uint32_t seed){eco_seed_live(seed);}

void ilha_eco_visual(uint32_t events[3],uint32_t *ticks,uint32_t *step){for(uint32_t k=0;k<3;k++)events[k]=eco_events(k);*ticks=eco_ticks();*step=eco_step();}

uint32_t ilha_eco_bed_phase(void){return bed_phase;}

uint32_t ilha_eco_bed_seed(void){return bed_seed;}
int32_t ilha_eco_bed_held(void){return bed_shape==5?bed_drift_from:bed_held;}
uint32_t ilha_eco_sounding(void){return eco_wind_voices();}

void ilha_eco_activity(uint32_t f,uint32_t a){eco_activity_param(f,a);}
void ilha_eco_family_visual(uint32_t *s,uint32_t *o,uint32_t *status){for(uint32_t f=0;f<3;f++){s[f]=family_step[f];o[f]=family_opportunities[f];status[f]=family_status[f];}}
void ilha_eco_family(uint32_t family,uint32_t tame,uint32_t cycle){eco_family_param(family,tame,cycle);}

void ilha_eco_distance(uint32_t f,int32_t d,int32_t m,int32_t w,int32_t on){eco_distance_param(f,d,m,w,on);}
void ilha_eco_drift(int32_t a,uint32_t p,int32_t r,int32_t h){uint32_t was=(uint32_t)drift_hold;eco_drift_param(a,p,r,h);if(was&&!drift_hold)ilha_eco_keys(keys);}
void ilha_eco_resonance(int32_t l,int32_t m,int32_t d,int32_t t){eco_resonance_param(l,m,d,t);}
void ilha_eco_resonance_balance(int32_t m,int32_t o,int32_t s){eco_resonance_balance(m,o,s);}
void ilha_eco_resonance_visual(uint32_t *o,uint32_t *m,uint32_t *a){*o=resonance.active_object;*m=resonance.active_material;*a=resonance.age;}
void ilha_eco_layers_visual(int32_t depth[3],int32_t pan[3],uint8_t trace[3][48],uint32_t *cursor,uint32_t *changes,uint32_t *env,uint32_t *events){
 for(uint32_t f=0;f<3;f++){depth[f]=spatial[f].depth;pan[f]=spatial[f].pan;for(uint32_t i=0;i<48;i++)trace[f][i]=drift_history[f][i];}
 *cursor=drift_cursor;*changes=drift_changes;*env=(uint32_t)resonance.env;*events=resonance.events;
}

void ilha_eco_sends(const int32_t sends[6][2],uint32_t wind_fx){for(uint32_t f=0;f<6;f++)for(uint32_t j=0;j<2;j++)send_target[f][j]=limit(sends[f][j],0,100)*32768/100;send_target[4][0]=send_target[5][0]=0;if(!wind_fx)send_target[4][1]=0;}
uint32_t ilha_eco_render_sends(int32_t *out,int32_t *bypass,int32_t *late,int32_t *delay,int32_t *verb,uint32_t n,uint32_t send){
 if(!out||!bypass||!late||!delay||!verb||!n||n>32)return 0;ilha_eco_beats=0;
 for(uint32_t i=0;i<n;i++){if(offset==128){block=eco_render();offset=0;}if(eco_beat_mask[offset>>5]&(1u<<(offset&31u)))ilha_eco_beats|=1u<<i;wind_send+=limit((send?32768:0)-wind_send,-128,128);
  for(uint32_t c=0;c<2;c++){uint32_t at=offset*2+c;int32_t wet=(int32_t)((int64_t)wind_output[at]*wind_send/32768);out[i*2+c]=block[at]-wind_output[at]-ocean_output[offset];late[i*2+c]=wet+ocean_output[offset];bypass[i*2+c]=wind_output[at]-wet;}
  delay[i]=delay_output[offset];verb[i]=verb_output[offset];offset++;
 }return 1;
}
void ilha_eco_pressure(uint32_t pressure){if(pressure>2)pressure=2;if(pressure!=engine_pressure){engine_pressure=pressure;engine_guard_events++;}
 if(pressure>=2)for(uint32_t k=0;k<WIND_VOICES;k++)if(wind[k].on&&!wind[k].gate){uint32_t step=(wind[k].env/1764u+1u)*65536u;if(wind[k].release_step<step){wind[k].release_step=step;engine_wind_releases++;}}
}
void ilha_eco_engine_diagnostics(uint32_t out[8]){out[0]=engine_pressure;out[1]=engine_guard_events;out[2]=engine_wind_releases;out[3]=2;out[4]=engine_pressure>=2?1:2;out[5]=eco_wind_voices();out[6]=resonance.energy;out[7]=resonance.events;}
