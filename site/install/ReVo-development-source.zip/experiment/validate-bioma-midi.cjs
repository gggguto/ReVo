// Actual pi32v2 package in upstream fm1-emu WASM. No physical MIDI/USB/network.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const base=path.resolve(__dirname,'../../..'),dir=path.join(__dirname,'bioma-midi-results');fs.mkdirSync(dir,{recursive:true});process.chdir(base);
let x,jit=0,fail=0;const wasm=fs.readFileSync('outputs/preview-local/fm1-emu/fm1_web.wasm');
x=new WebAssembly.Instance(new WebAssembly.Module(wasm),{env:{fm1_jit_compile(ptr,len){try{const bytes=new Uint8Array(x.memory.buffer,ptr,len).slice();const fn=new WebAssembly.Instance(new WebAssembly.Module(bytes),{env:{memory:x.memory,table:x.__indirect_function_table}}).exports.run;const slot=x.__indirect_function_table.grow(1);x.__indirect_function_table.set(slot,fn);jit++;return slot;}catch(e){console.error("JIT failure",String(e));fail++;return 0;}}}}).exports;
const pkg=fs.readFileSync('work/revo-revo-final-target/build/felucca-9.8-revo.fwsc'),ptr=x.fm1_alloc(pkg.length);new Uint8Array(x.memory.buffer,ptr,pkg.length).set(pkg);x.fm1_jit(1,16);x.fm1_ahead(1024);if(x.fm1_boot_fwsc(ptr,pkg.length,0,0,240)!==0)throw Error('Package rejected');
const states=[];function pump(ms,record){const end=x.fm1_ms()+ms;let rounds=0,peak=0,energy=0,have=0;while(x.fm1_ms()<end){if(++rounds>10000)throw Error('Emulated time stalled');have+=x.fm1_render(128,4800000);if(x.fm1_halted())throw Error('CPU halted '+x.fm1_halted()+' at '+x.fm1_ms()+' JIT failures '+fail);const a=new Float32Array(x.memory.buffer,x.fm1_out_l(),128),b=new Float32Array(x.memory.buffer,x.fm1_out_r(),128);for(let i=0;i<128;i++){if(!Number.isFinite(a[i])||!Number.isFinite(b[i]))throw Error('Non-finite audio');peak=Math.max(peak,Math.abs(a[i]),Math.abs(b[i]));energy+=a[i]*a[i]+b[i]*b[i];if(record)record.push(a[i],b[i]);}}return {ms:x.fm1_ms(),peak,energy,have};}
function tap(id){x.fm1_key(id,1);pump(90);x.fm1_key(id,0);pump(90);}
function enc(id,n){x.fm1_enc(id,n);pump(140);}
function slowEnv(id,n){for(let i=0;i<n;i++){enc(id,1);pump(120);}}
function capture(name,stats){const lcd=Buffer.from(new Uint8Array(x.memory.buffer,x.fm1_lcd(),115200));fs.writeFileSync(path.join(dir,name+'.rgb565'),lcd);states.push({name,...stats,lcdRevision:x.fm1_lcd_revision(),lcdSha256:crypto.createHash('sha256').update(lcd).digest('hex')});console.log(name,JSON.stringify(stats));}
function wav(name,samples){const data=Buffer.alloc(samples.length*2),h=Buffer.alloc(44);samples.forEach((v,i)=>data.writeInt16LE(Math.max(-32768,Math.min(32767,Math.round(v*32767))),i*2));h.write('RIFF');h.writeUInt32LE(data.length+36,4);h.write('WAVEfmt ',8);h.writeUInt32LE(16,16);h.writeUInt16LE(1,20);h.writeUInt16LE(2,22);h.writeUInt32LE(44100,24);h.writeUInt32LE(176400,28);h.writeUInt16LE(4,32);h.writeUInt16LE(16,34);h.write('data',36);h.writeUInt32LE(data.length,40);fs.writeFileSync(path.join(dir,name+'.wav'),Buffer.concat([h,data]));}




function message(status,n,v){x.fm1_midi(status);x.fm1_midi(n);x.fm1_midi(v);return pump(90);}
function on(ch,n){return message(0x90|ch,n,100);}function off(ch,n){return message(0x80|ch,n,0);}function cc(ch,n,v){return message(0xb0|ch,n,v);}
const sy=JSON.parse(fs.readFileSync('outputs/integracao-fm1/experiments/bioma-midi/engine-symbols.json')),offsets=JSON.parse(fs.readFileSync('outputs/integracao-fm1/experiments/bioma-midi/control-offsets.json'));let ramBase;
function read(field,index=0){const v=new DataView(x.memory.buffer);if(ramBase===undefined){for(let i=0;i<v.byteLength-100;i+=4)if(v.getUint32(i,true)===0x44424731){const b=i-sy.felucca_dbg.address+0x1c00000;if(b>=0&&b+sy.ilha_control.address-0x1c00000+200<v.byteLength){ramBase=b;break;}}if(ramBase===undefined)throw Error('RAM mapping missing');}const at=ramBase+sy.ilha_control.address-0x1c00000+offsets[field]+index*4;return field==='playing'?v.getUint8(at):v.getInt32(at,true);}
function expect(field,index,value){if(read(field,index)!==value)throw Error(field+'['+index+'] expected '+value+' got '+read(field,index));}
pump(3000);capture('boot-midi-off',pump(200));on(0,60);if(pump(300).energy>1e-6)throw Error('Disabled MIDI sounded');off(0,60);
// Native Home hold -> Settings -> control TRS, clock remains off.
x.fm1_key(8,1);pump(1000);x.fm1_key(8,0);pump(100);enc(0,1);tap(3);enc(3,2);capture('bioma-settings-trs',pump(300));
cc(0,24,0);cc(0,25,0);on(0,60);const sounding=pump(350);if(sounding.energy<0.001)throw Error('Wind did not sound');capture('wind-midi-note',sounding);off(0,60);pump(500);if(pump(200).energy>1e-6)throw Error('Wind stuck after NoteOff');
// Physical overlap: MIDI release must keep physical Wind key held.
x.fm1_key(21,1);pump(200);on(0,60);off(0,60);if(pump(200).energy<0.001)throw Error('MIDI released physical Wind');x.fm1_key(21,0);pump(500);if(pump(200).energy>1e-6)throw Error('Physical Wind stuck');
on(0,60);cc(0,123,0);pump(500);if(pump(200).energy>1e-6)throw Error('All notes off failed');
// Real seven-channel CC ingress, independent of current screen.
cc(0,20,32);cc(1,20,20);cc(2,20,50);cc(3,20,70);tap(8);capture('bioma-midi-home-levels',pump(200));
tap(6);capture('bioma-birds-level',pump(300));cc(1,24,127);cc(1,23,3);capture('bioma-birds-tame-cycle',pump(300));
tap(11);cc(6,20,48);cc(6,21,2);cc(6,22,5);cc(6,23,127);capture('bioma-drift-channel7',pump(400));expect('drift',0,38);expect('drift',1,2);expect('drift',2,5);expect('drift',3,1);
tap(11);cc(6,24,90);cc(6,25,8);cc(6,26,3);cc(6,27,127);capture('bioma-beam-channel7',pump(400));expect('beam',0,71);expect('beam',1,8);expect('beam',2,3);expect('beam',3,1);
on(0,36);off(0,36);on(0,60);pump(300);off(0,60);on(0,36);off(0,36);tap(11);capture('bioma-stop-clears-hold',pump(400));expect('drift',3,0);expect('playing',0,0);
// Switching machine via native menu leaves the old Bioma map behind.
x.fm1_key(8,1);pump(1000);x.fm1_key(8,0);pump(100);enc(0,-10);tap(3);enc(0,-1);tap(3);pump(500);on(0,59);off(0,59);tap(6);capture('atolls-midi-transport-preserved',pump(400));on(0,59);off(0,59);pump(500);
if(fail||x.fm1_halted())throw Error('Emulator failure');fs.writeFileSync(path.join(dir,'report.json'),JSON.stringify({packageSha256:crypto.createHash('sha256').update(pkg).digest('hex'),halted:x.fm1_halted(),jitFailures:fail,states},null,2));console.log('PASS actual package Bioma MIDI + Atolls transport');
