from pathlib import Path
import subprocess,os,json
root=Path.cwd();base=root/'outputs/integracao-fm1/experiments/bioma-midi';src=root/'work/revo-living-target/firmware/src'
cmd=['clang','-w','-std=c11','-O1','-g','-DREVO_BIOMA_ONLY=0','-DREVO_ECO_PARALLEL=1','-DREVO_START_BIOMA=1','-I'+str(src),'-Iwork/revo-living-target/build/gen','-Iwork/revo-living-target/build/genwav',str(base/'midi-test.c')]+[str(src/n) for n in ['ilha_controls.c','ilha_ui.c','ilha_dual.c','ilha_eco.c','ilha_sample.c']]+['-lm']
results={}
for sanitizer in ['address,undefined','thread']:
 exe='/tmp/revo-bioma-midi-'+sanitizer.replace(',','-');subprocess.run(cmd+['-fsanitize='+sanitizer,'-fno-sanitize-recover=undefined','-o',exe],check=True)
 for mode,env in [('inline',{'CORES':'1'}),('dual-core',{'CORES':'2','CHAOS':'19'})]:
  result=subprocess.run([exe],env={**os.environ,**env},capture_output=True,text=True);assert result.returncode==0,(result.stdout,result.stderr);results[sanitizer+'/'+mode]=result.stdout.strip()
(base/'native-results.json').write_text(json.dumps(results,indent=2)+'\n');print('PASS native MIDI sanitizer checks, inline + two cores')
