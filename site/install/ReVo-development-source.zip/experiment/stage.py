from pathlib import Path
import json,struct,hashlib,zipfile,shutil,runpy
root=Path.cwd();b=root/'outputs/integracao-fm1/experiments/bioma-midi';t=root/'work/revo-revo-final-target';site=root/'outputs/revo-github/site'
raw=(t/'build/felucca-9.8-revo.fwsc').read_bytes();sha=hashlib.sha256(raw).hexdigest();r=json.loads((root/'outputs/integracao-fm1/emulator/bioma-midi-results/report.json').read_text());assert r['packageSha256']==sha and not r['halted'] and not r['jitFailures']
# Read ELF32 symbols without external dependencies.
e=(t/'build/felucca.elf').read_bytes();off=struct.unpack_from('<I',e,32)[0];ents,num=struct.unpack_from('<HH',e,46);sections=[struct.unpack_from('<10I',e,off+i*ents) for i in range(num)];symbols={}
for h in sections:
 if h[1]!=2:continue
 strings=sections[h[6]];st=e[strings[4]:strings[4]+strings[5]]
 for at in range(h[4],h[4]+h[5],h[9]):
  n,value,size,info,other,idx=struct.unpack_from('<IIIBBH',e,at);name=st[n:st.find(b'\0',n)].decode(errors='replace')
  if name:symbols[name]={'address':value,'bytes':size,'section':idx}
(b/'engine-symbols.json').write_text(json.dumps(symbols))
memory={k:symbols[end]['address']-symbols[start]['address'] for k,start,end in [('ram','_data_start','_bss_end'),('pool','_pool_start','_pool_end'),('lowram','_lr_start','_lr_end')]};assert memory['ram']<=98304 and memory['lowram']<=29496 and memory['pool']<=344064
pkg=runpy.run_path(str(root/'work/sloop-fm1/tools/fm1_install.py'));assert pkg['product_of'](raw)=='FM-1_998';im=pkg['logical_image'](raw);h=pkg['_dec'](im[:64]);n=int.from_bytes(h[8:10],'little');assert pkg['_crc16'](h[2:])==int.from_bytes(h[:2],'little');assert pkg['_crc16'](im[64:64+80*n])==int.from_bytes(h[2:4],'little')
for i in range(n):
 entry=pkg['_dec'](im[64+80*i:144+80*i]);at=int.from_bytes(entry[8:12],'little');size=int.from_bytes(entry[12:16],'little');assert pkg['_crc16'](im[at:at+size])==int.from_bytes(entry[4:6],'little')
assert (t/'build/loader/ota.bin').read_bytes()==(root/'work/revo-bioma-home-density-target/build/loader/ota.bin').read_bytes()
(b/'README.md').write_text('# ReVo build2026110608 — Bioma MIDI\n\nBioma adds independent MIDI CONTROL port selection, Wind key notes 53–79 and transport toggle note36 on channel1, and CC groups on channels1–7 (Global/Wind, Birds, Insects, Water, Resonance, FX, Drift/Beam). Default input is OFF. Atolls mapping is unchanged. Existing Wind voices, harmony and dual-core audio pipeline remain in use; no added voices or audio buffers.\n\nTests: ASan/UBSan and TSan with both cores; all advertised CC values, held-note ownership, NoteOff/velocity-zero, source filtering, channel isolation, bounded queue overflow, and actual UART ingress to audio. Exact target-package emulator: Settings, Wind audio/release/physical overlap, channel7 display, Atolls transport. Physical FM-1 validation is pending.\n')
(b/'validation.json').write_text(json.dumps({'build':2026110608,'sha256':sha,'memory':memory,'exactPackage':r,'hardware_validated':False,'native':'ASan/UBSan + ThreadSanitizer; seven-channel CC sweep; notes/source ownership/overflow/live ingress; Atolls regression'},indent=2))
archive=b/'ReVo-development-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in t.rglob('*'):
  rel=p.relative_to(t)
  if p.is_file() and not any(v in ['build','.git','node_modules','__pycache__'] for v in rel.parts):z.write(p,'firmware-source/'+str(rel))
 for p in b.iterdir():
  if p.is_file() and p.suffix in ['.py','.c','.md','.json']:z.write(p,'experiment/'+p.name)
 z.write(root/'outputs/integracao-fm1/emulator/validate-bioma-midi.cjs','experiment/validate-bioma-midi.cjs')
 z.writestr('BUILD.md','REVO_BIOMA_ONLY=0 REVO_ECO_PARALLEL=1 REVO_START_BIOMA=1 FELUCCA_CPU1=1 python3 tools/build.py --release 9.8-revo\n');assert z.testzip() is None
m=json.loads((site/'install/release.json').read_text());m.update(name='ReVo — Bioma + Atolls / build2026110608 / Bioma MIDI',bytes=len(raw),sha256=sha,source_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),diagnostics_build=2026110608,variant='bioma-midi',memory=memory,hardware_validated=False)
for out in [site/'install',root/'outputs/preview-local/installer-bioma-midi']:
 if not out.exists():shutil.copytree(root/'outputs/preview-local/installer-revo-final',out)
 (out/'ReVo-development.fwsc').write_bytes(raw);shutil.copy2(archive,out/archive.name);(out/'release.json').write_text(json.dumps(m,indent=2)+'\n')
p=site/'install/index.html';s=p.read_text().replace('This build’s latest interface adjustments have passed local and emulator checks; they still await confirmation on hardware.','This build adds Bioma MIDI notes and CCs, including channel 7 for Drift and Beam. It has passed native and emulator checks; MIDI behaviour still awaits confirmation on hardware.');p.write_text(s)
shutil.copytree(site,root/'outputs/preview-local/revo',dirs_exist_ok=True)
print('PASS CRC / unchanged loader / exact tested package staged;',sha,'memory',memory)
