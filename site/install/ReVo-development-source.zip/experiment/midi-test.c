#include <assert.h>
#define main sloop_hostsim_main
#include "../../../../work/revo-living-target/tests/hostsim.c"
#undef main
#include "ilha_ui.h"
static uint32_t pkt(uint32_t src,uint32_t st,uint32_t n,uint32_t v){return (src==2?16u:0u)|(st>>4)|(st<<8)|(n<<16)|(v<<24);}
static void blocks(uint32_t n){int32_t out[64];while(n--)mix_block(out,32);}
int main(void){
 ilha_controls_t c;revo_midi_control_t s={0};ilha_controls_init(&c);c.machine=ILHA_ECO;
 assert(!revo_midi_control_apply(&s,&c,pkt(1,0x90,60,100)));c.midi_control_source=3;
 for(uint32_t n=53;n<=79;n++){assert(revo_midi_control_apply(&s,&c,pkt(1,0x90,n,100)));assert(c.midi_notes==(1u<<(n-53)));assert(revo_midi_control_apply(&s,&c,pkt(1,0x90,n,0))&&!c.midi_notes);}
 assert(!revo_midi_control_apply(&s,&c,pkt(1,0x90,80,100)));assert(!revo_midi_control_apply(&s,&c,pkt(1,0x91,60,100)));
 revo_midi_control_apply(&s,&c,pkt(1,0x90,60,100));revo_midi_control_apply(&s,&c,pkt(2,0x90,60,100));revo_midi_control_apply(&s,&c,pkt(1,0x80,60,0));assert(c.midi_notes==(1u<<7));revo_midi_control_apply(&s,&c,pkt(2,0xb0,123,0));assert(!c.midi_notes);
 c.playing=0;revo_midi_control_apply(&s,&c,pkt(1,0x90,36,100));assert(c.playing);c.drift[3]=1;assert(!revo_midi_control_apply(&s,&c,pkt(1,0x80,36,0))&&c.playing);revo_midi_control_apply(&s,&c,pkt(1,0x90,36,100));assert(!c.playing&&!c.drift[3]);
 // Exhaust every advertised CC and every input value; no out-of-range writes.
 for(uint32_t ch=0;ch<7;ch++)for(uint32_t n=20;n<34;n++)for(uint32_t v=0;v<128;v++)if(revo_midi_bioma_relevant(pkt(1,0xb0|ch,n,v)))assert(revo_midi_control_apply(&s,&c,pkt(1,0xb0|ch,n,v)));
 assert(c.eco_density==100&&c.wind[1]==7&&c.wind_env[0]==10000&&c.wind_env[1]==20000&&c.eco_global[1]==240);
 for(uint32_t f=0;f<3;f++){assert(c.family_cycle[f]==ilha_eco_cycle_count()-1&&c.family_tame[f]&&c.family_activity[f]==100);assert(c.distance[f][3]==1);}
 assert(c.resonance_sources==7&&c.resonance_balance[1]==3&&c.echo[2]==90&&c.space[0]==100&&c.beam[1]==16&&c.beam[2]==5&&c.drift[1]==6);
 revo_midi_control_apply(&s,&c,pkt(1,0xb5,29,64));assert(c.space[0]==0);revo_midi_control_apply(&s,&c,pkt(1,0xb5,29,0));assert(c.space[0]==-100);
 revo_midi_control_apply(&s,&c,pkt(1,0xb2,21,40));assert(c.eco_register[2]==revo_midi_scale(40,0,100));revo_midi_control_apply(&s,&c,pkt(1,0xb3,21,60));assert(c.eco_register[1]==revo_midi_scale(60,0,100));
 c.midi_source=1;int bpm=c.eco_global[1];assert(!revo_midi_control_apply(&s,&c,pkt(1,0xb0,32,0))&&c.eco_global[1]==bpm);c.midi_control_source=1;assert(!revo_midi_control_apply(&s,&c,pkt(2,0xb0,20,0)));
 c.page=ILHA_SETTINGS;assert(!strcmp(ilha_controls_label(&c,1),"MIDI CONTROL"));ilha_controls_knob(&c,1,100);assert(c.midi_control_source==3);
 // Existing Atolls notes/CC/transport still use their original map.
 c.machine=ILHA_DUAL;s=(revo_midi_control_t){0};for(uint32_t ch=0;ch<2;ch++)for(uint32_t n=60;n<=72;n++){revo_midi_control_apply(&s,&c,pkt(1,0x90|ch,n,100));uint32_t mask=c.midi_notes,key=0;assert(mask&&!(mask&(mask-1)));while(!(mask&(1u<<key)))key++;assert(fragment_action(key)==fragment_action(n-60));revo_midi_control_apply(&s,&c,pkt(1,0x80|ch,n,0));}
 // Actual MIDI UART ingress reaches Bioma audio before main consumes CC queue.
 host_tracks_init();ilha_audio_init();ilha_audio_control.machine=ILHA_ECO;ilha_audio_control.midi_control_source=2;ilha_audio_control.local_notes=0;mi_r=mi_w=0;revo_midi_control_r=revo_midi_control_w=0;revo_midi_control_lost=0;ilha_pending_control=ilha_audio_control;ilha_pending_revision++;blocks(4);
 um_byte(0x90);um_byte(60);um_byte(100);blocks(16);assert(revo_midi_audio_notes==(1u<<7));assert(ilha_eco_note_lights()&(1u<<7));
 ilha_audio_control.local_notes=1u<<7;um_byte(0x80);um_byte(60);um_byte(0);blocks(16);assert(!revo_midi_audio_notes&&(ilha_eco_note_lights()&(1u<<7)));
 ilha_audio_control.midi_control_source=0;blocks(4);assert(!revo_midi_audio_notes);
 // Overflow releases only MIDI ownership. No hanging keys or out-of-bounds queue.
 ilha_audio_control.local_notes=0;ilha_audio_control.midi_control_source=2;blocks(4);for(uint32_t i=0;i<=REVO_MIDI_CONTROL_Q;i++)revo_midi_control_enqueue(pkt(2,0xb0,20,1));assert(revo_midi_control_lost);blocks(4);assert(!revo_midi_audio_notes);
 puts("PASS Bioma MIDI: 27 keys, source ownership/NoteOff, channel isolation, 7-channel CC sweep, ranges, external BPM lock, Stop releases Hold, Settings, live ingress, overflow; Atolls map preserved");
}
