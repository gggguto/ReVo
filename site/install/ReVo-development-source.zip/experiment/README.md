# ReVo build2026110608 — Bioma MIDI

Bioma adds independent MIDI CONTROL port selection, Wind key notes 53–79 and transport toggle note36 on channel1, and CC groups on channels1–7 (Global/Wind, Birds, Insects, Water, Resonance, FX, Drift/Beam). Default input is OFF. Atolls mapping is unchanged. Existing Wind voices, harmony and dual-core audio pipeline remain in use; no added voices or audio buffers.

Tests: ASan/UBSan and TSan with both cores; all advertised CC values, held-note ownership, NoteOff/velocity-zero, source filtering, channel isolation, bounded queue overflow, and actual UART ingress to audio. Exact target-package emulator: Settings, Wind audio/release/physical overlap, channel7 display, Atolls transport. Physical FM-1 validation is pending.
